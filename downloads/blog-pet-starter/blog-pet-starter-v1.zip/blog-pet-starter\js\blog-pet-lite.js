/*
 * Shoka 博客宠物 · 最小可用版
 * 依赖：无。素材：assets/blog-pet/{idle,drag,wave}.webm + idle.webp
 * 说明：完整教程见博客文章；本文件可以直接放到
 * themes/shoka/source/js/blog-pet-lite.js。
 */
(function () {
  'use strict';
  if (window.ShokaPetLite) return;

  var KEY = 'shoka-pet-lite-v1';
  var PET = {
    name: '大肥鱼',
    defaultVisible: 'desktop',
    size: 300,
    minSize: 180,
    maxSize: 520,
    assetBase: (window.CONFIG && window.CONFIG.root ? String(window.CONFIG.root).replace(/\/?$/, '/') : '/') + 'assets/blog-pet/',
    assets: {
      idle: { video: 'idle.webm', poster: 'idle.webp' },
      drag: { video: 'drag.webm', poster: 'idle.webp' },
      wave: { video: 'wave.webm', poster: 'idle.webp' }
    }
  };
  var desktop = window.matchMedia('(min-width: 1024px) and (hover: hover) and (pointer: fine)');
  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  var safariNoAlpha = /AppleWebKit/i.test(navigator.userAgent) && !/Chrome|Chromium|Edg|OPR|Android/i.test(navigator.userAgent);
  var saved = read();
  var size = clamp(Number(saved.size) || PET.size, PET.minSize, PET.maxSize);
  var position = {
    x: Number.isFinite(saved.x) ? saved.x : null,
    y: Number.isFinite(saved.y) ? saved.y : null
  };
  var visible = initialVisible();
  var current = '';
  var menuOpen = false;
  var suppressClick = false;
  var suppressTimer = 0;
  var longPress = 0;
  var drag = null;
  var videos = {};

  var root = document.createElement('aside');
  root.className = 'pet-lite';
  root.hidden = !visible;
  root.setAttribute('aria-label', PET.name);
  root.innerHTML =
    '<div class="pet-lite__stage">' +
      '<video class="pet-lite__video" data-pet-video="idle" muted playsinline preload="none" aria-hidden="true" disablepictureinpicture></video>' +
      '<video class="pet-lite__video" data-pet-video="drag" muted playsinline preload="none" aria-hidden="true" disablepictureinpicture></video>' +
      '<video class="pet-lite__video" data-pet-video="wave" muted playsinline preload="none" aria-hidden="true" disablepictureinpicture></video>' +
    '</div>' +
    '<img class="pet-lite__poster" alt="" draggable="false">' +
    '<button class="pet-lite__body" type="button" aria-label="点击互动，右键打开宠物菜单，可拖动"></button>' +
    '<button class="pet-lite__menu-button" type="button" aria-label="宠物菜单" aria-haspopup="true" aria-expanded="false">···</button>' +
    '<div class="pet-lite__menu" role="dialog" aria-label="宠物菜单" hidden>' +
      '<strong class="pet-lite__title">宠物设置</strong>' +
      '<label class="pet-lite__row">大小<output>300</output>' +
        '<input class="pet-lite__range" type="range" min="' + PET.minSize + '" max="' + PET.maxSize + '" step="1" aria-label="宠物大小">' +
      '</label>' +
      '<button type="button" data-pet-action="corner">回到右下角</button>' +
      '<button type="button" data-pet-action="hide">隐藏宠物</button>' +
      '<p class="pet-lite__hint">拖动宠物可以换位置，设置保存在当前浏览器。</p>' +
    '</div>';
  document.body.appendChild(root);

  var body = root.querySelector('.pet-lite__body');
  var menu = root.querySelector('.pet-lite__menu');
  var menuButton = root.querySelector('.pet-lite__menu-button');
  var poster = root.querySelector('.pet-lite__poster');
  var range = root.querySelector('.pet-lite__range');
  var output = root.querySelector('.pet-lite__row output');
  root.querySelectorAll('[data-pet-video]').forEach(function (video) {
    videos[video.dataset.petVideo] = video;
    video.addEventListener('error', showPoster);
    video.addEventListener('playing', function () {
      if (video.classList.contains('is-active')) poster.hidden = true;
    });
    video.addEventListener('ended', function () {
      if (video.dataset.petVideo === 'wave' && root.classList.contains('is-active-wave')) {
        root.classList.remove('is-active-wave');
        playAction('idle');
      }
    });
  });
  poster.src = PET.assetBase + PET.assets.idle.poster;
  poster.onerror = function () { poster.hidden = true; };

  var toggle = document.createElement('button');
  toggle.type = 'button';
  toggle.className = 'item pet-lite-toggle';
  toggle.title = '显示宠物';
  toggle.setAttribute('aria-label', '显示宠物');
  toggle.setAttribute('aria-pressed', String(visible));
  toggle.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><ellipse cx="5" cy="8" rx="2.2" ry="2.9" transform="rotate(-25 5 8)"/><ellipse cx="10" cy="5.5" rx="2.2" ry="2.9"/><ellipse cx="15.5" cy="6" rx="2.2" ry="2.9" transform="rotate(12 15.5 6)"/><ellipse cx="20" cy="10" rx="2" ry="2.7" transform="rotate(30 20 10)"/><path d="M12 10.5c-2.2 0-3.4 2.3-4.9 3.8-1.5 1.4-2.4 2.5-1.6 4.2 1 2.2 3.8 1.1 6.1 1.1s5.2 1.2 6.4-.8c1.1-1.8-.1-3.2-1.5-4.6-1.6-1.6-2.4-3.7-4.5-3.7Z"/></svg>';
  ensureToggle();

  function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
  function read() {
    try {
      var value = JSON.parse(localStorage.getItem(KEY) || '{}');
      return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
    } catch (error) { return {}; }
  }
  function device() { return desktop.matches ? 'desktop' : 'compact'; }
  function initialVisible() {
    var data = read(), value = data.visibility && data.visibility[device()];
    if (typeof value === 'boolean') return value;
    return PET.defaultVisible === 'always' ? true : PET.defaultVisible === 'desktop' ? desktop.matches : false;
  }
  function save() {
    try {
      var value = read();
      value.version = 1;
      value.size = size;
      value.x = position.x;
      value.y = position.y;
      value.visibility = Object.assign({}, value.visibility, { [device()]: visible });
      localStorage.setItem(KEY, JSON.stringify(value));
    } catch (error) {}
  }
  function syncToggle() {
    toggle.setAttribute('aria-pressed', String(visible));
    toggle.setAttribute('aria-label', visible ? '隐藏宠物' : '显示宠物');
    toggle.title = visible ? '隐藏宠物' : '显示宠物';
    toggle.classList.toggle('is-active', visible);
  }
  function ensureToggle() {
    var tool = document.getElementById('tool');
    if (tool) {
      if (toggle.parentNode !== tool) tool.insertBefore(toggle, tool.querySelector('.player') || null);
      toggle.classList.remove('is-floating');
    } else {
      toggle.classList.add('is-floating');
      if (toggle.parentNode !== document.body) document.body.appendChild(toggle);
    }
  }
  function place() {
    var width = size, height = Math.round(size * 9 / 16);
    var bounds = {
      left: 8,
      right: Math.max(8, window.innerWidth - width - 8),
      top: 64,
      bottom: Math.max(64, window.innerHeight - height - 8)
    };
    if (position.x === null || position.y === null) {
      position.x = bounds.right;
      position.y = bounds.bottom;
    }
    position.x = clamp(position.x, bounds.left, bounds.right);
    position.y = clamp(position.y, bounds.top, bounds.bottom);
    root.style.width = width + 'px';
    root.style.height = height + 'px';
    root.style.transform = 'translate3d(' + Math.round(position.x) + 'px,' + Math.round(position.y) + 'px,0)';
    root.classList.toggle('is-menu-below', position.y < 250);
    range.value = String(size);
    output.textContent = String(Math.round(size / PET.size * 100)) + '%';
  }
  function ensureVideo(action) {
    var video = videos[action];
    if (!video) return null;
    if (!video.getAttribute('src')) {
      video.src = PET.assetBase + PET.assets[action].video;
      video.load();
    }
    return video;
  }
  function showPoster() {
    Object.keys(videos).forEach(function (name) {
      videos[name].pause();
      videos[name].classList.remove('is-active');
    });
    current = '';
    poster.hidden = false;
  }
  function playAction(action) {
    if (!visible) return;
    if (reduced.matches || safariNoAlpha) { showPoster(); return; }
    var video = ensureVideo(action);
    if (!video) { showPoster(); return; }
    current = action;
    Object.keys(videos).forEach(function (name) {
      if (videos[name] !== video) {
        videos[name].pause();
        videos[name].classList.remove('is-active');
      }
    });
    video.loop = action !== 'wave';
    video.classList.add('is-active');
    poster.hidden = false;
    root.classList.toggle('is-active-wave', action === 'wave');
    try { video.currentTime = 0; } catch (error) {}
    var playing = video.play();
    if (playing && playing.catch) playing.catch(showPoster);
  }
  function pauseAll() {
    Object.keys(videos).forEach(function (name) { videos[name].pause(); });
  }
  function setVisible(value, persist) {
    visible = !!value;
    root.hidden = !visible;
    syncToggle();
    if (visible) { place(); playAction('idle'); }
    else { pauseAll(); closeMenu(); }
    if (persist !== false) save();
  }
  function openMenu() {
    menuOpen = true;
    menu.hidden = false;
    root.classList.add('is-menu-open');
    menuButton.setAttribute('aria-expanded', 'true');
    body.setAttribute('aria-expanded', 'true');
    place();
  }
  function closeMenu(focus) {
    menuOpen = false;
    menu.hidden = true;
    root.classList.remove('is-menu-open');
    menuButton.setAttribute('aria-expanded', 'false');
    body.setAttribute('aria-expanded', 'false');
    if (focus) menuButton.focus({ preventScroll: true });
  }
  function toggleMenu() { if (menuOpen) closeMenu(true); else openMenu(); }
  function cancelDrag() {
    clearTimeout(longPress);
    longPress = 0;
    var previous = drag;
    drag = null;
    root.classList.remove('is-dragging');
    if (previous && body.hasPointerCapture(previous.id)) body.releasePointerCapture(previous.id);
  }

  toggle.addEventListener('click', function () { setVisible(!visible); });
  body.addEventListener('pointerdown', function (event) {
    if (event.button !== 0 || !event.isPrimary) return;
    drag = { id: event.pointerId, x: event.clientX, y: event.clientY, ox: position.x, oy: position.y, moved: false };
    body.setPointerCapture(event.pointerId);
    if (event.pointerType !== 'mouse') {
      longPress = setTimeout(function () {
        suppressClick = true;
        cancelDrag();
        openMenu();
      }, 550);
    }
  });
  body.addEventListener('pointermove', function (event) {
    if (!drag || event.pointerId !== drag.id) return;
    var dx = event.clientX - drag.x, dy = event.clientY - drag.y;
    if (!drag.moved && Math.hypot(dx, dy) < 5) return;
    if (!drag.moved) {
      drag.moved = true;
      clearTimeout(longPress);
      root.classList.add('is-dragging');
      playAction('drag');
    }
    suppressClick = true;
    position.x = drag.ox + dx;
    position.y = drag.oy + dy;
    place();
  });
  body.addEventListener('pointerup', function (event) {
    if (!drag || event.pointerId !== drag.id) return;
    var moved = drag.moved;
    cancelDrag();
    if (moved) {
      place();
      save();
      playAction('idle');
      clearTimeout(suppressTimer);
      suppressTimer = setTimeout(function () { suppressClick = false; }, 350);
    }
  });
  body.addEventListener('pointercancel', function () {
    if (!drag) return;
    cancelDrag();
    place();
    playAction('idle');
  });
  body.addEventListener('click', function () {
    if (suppressClick) { suppressClick = false; return; }
    if (menuOpen) { closeMenu(); return; }
    playAction('wave');
  });
  body.addEventListener('contextmenu', function (event) { event.preventDefault(); openMenu(); });
  body.addEventListener('keydown', function (event) {
    if (event.key === 'ContextMenu' || event.shiftKey && event.key === 'F10') {
      event.preventDefault();
      openMenu();
    }
  });
  menuButton.addEventListener('click', function (event) { event.stopPropagation(); toggleMenu(); });
  menu.addEventListener('click', function (event) {
    var button = event.target.closest('[data-pet-action]');
    if (!button) return;
    if (button.dataset.petAction === 'corner') {
      position.x = null;
      position.y = null;
      place();
      save();
      closeMenu(true);
    } else if (button.dataset.petAction === 'hide') {
      setVisible(false);
    }
  });
  range.addEventListener('input', function () {
    size = clamp(Number(range.value), PET.minSize, PET.maxSize);
    place();
  });
  range.addEventListener('change', save);
  document.addEventListener('pointerdown', function (event) {
    if (!menuOpen) return;
    if (menu.contains(event.target) || menuButton.contains(event.target) || body.contains(event.target)) return;
    closeMenu(false);
  });
  document.addEventListener('keydown', function (event) {
    if (event.key !== 'Escape' || !menuOpen) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    closeMenu(true);
  }, true);
  window.addEventListener('resize', place, { passive: true });
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) pauseAll();
    else if (visible) playAction(current || 'idle');
  });
  reduced.addEventListener('change', function () {
    if (reduced.matches) showPoster();
    else if (visible) playAction('idle');
  });
  window.addEventListener('pageshow', function () {
    if (visible) { place(); playAction('idle'); }
  });
  window.addEventListener('storage', function (event) {
    if (event.key !== KEY) return;
    var data = read();
    size = clamp(Number(data.size) || PET.size, PET.minSize, PET.maxSize);
    position.x = Number.isFinite(data.x) ? data.x : null;
    position.y = Number.isFinite(data.y) ? data.y : null;
    var value = data.visibility && data.visibility[device()];
    if (typeof value === 'boolean') visible = value;
    root.hidden = !visible;
    syncToggle();
    place();
    if (visible && !document.hidden) playAction('idle');
    else pauseAll();
  });
  window.addEventListener('pjax:send', function () { pauseAll(); closeMenu(false); });
  window.addEventListener('pjax:success', function () { ensureToggle(); place(); if (visible) playAction('idle'); });

  syncToggle();
  if (visible) playAction('idle');

  window.ShokaPetLite = {
    show: function () { setVisible(true); },
    hide: function () { setVisible(false); },
    toggle: function () { setVisible(!visible); },
    reset: function () { position.x = null; position.y = null; size = PET.size; place(); save(); }
  };
})();
