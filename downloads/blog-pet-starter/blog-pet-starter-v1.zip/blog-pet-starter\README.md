# Shoka 博客宠物 · 最小可用版

这是一个不依赖任何第三方库的博客宠物 starter：一只会呼吸、会挥手、能拖动、能记住位置和大小的桌面宠物。适合第一次给 Hexo + Shoka 博客加宠物的读者。

## 包含内容

```text
blog-pet-starter/
├─ assets/blog-pet/
│  ├─ idle.webm      待机动画（VP9 透明视频）
│  ├─ idle.webp      待机海报（视频不可用时的静图）
│  ├─ drag.webm      拖动时播放的动画
│  └─ wave.webm      点击回应动画
├─ js/blog-pet-lite.js
├─ css/blog-pet-lite.css
├─ README.md
└─ LICENSE.txt
```

## 安装

1. 备份博客根目录和 `themes/shoka/layout/_partials/layout.njk`。
2. 把 `assets/blog-pet` 复制到博客根目录的 `source/assets/blog-pet/`。
   最终路径应类似 `source/assets/blog-pet/idle.webm`。
3. 把 `js/blog-pet-lite.js` 复制到 `themes/shoka/source/js/blog-pet-lite.js`。
4. 把 `css/blog-pet-lite.css` 复制到 `themes/shoka/source/css/blog-pet-lite.css`。
5. 打开 `themes/shoka/layout/_partials/layout.njk`，在 `</head>` 前加入：

   ```njk
   <link rel="stylesheet" href="{{ url_for('/css/blog-pet-lite.css') }}?v=20261027">
   ```

   在 `</body>` 前加入：

   ```njk
   <script src="{{ url_for('/js/blog-pet-lite.js') }}?v=20261027" defer></script>
   ```

6. 在博客根目录执行：

   ```bash
   hexo clean
   hexo server
   ```

7. 打开首页，右下角工具栏会出现一个宠物图标。点击显示宠物，然后测试点击、拖动和菜单。

## 修改

打开 `js/blog-pet-lite.js`，文件顶部的 `PET` 是主要配置：

```js
var PET = {
  name: '大肥鱼',
  defaultVisible: 'desktop', // desktop：电脑默认显示、手机默认隐藏；always：都显示；false：都隐藏
  size: 300,                 // 初始宽度，单位像素
  minSize: 180,
  maxSize: 520
};
```

- 换名字：改 `name`，同时可改 `index.html`/模板中的按钮文字。
- 换素材：保持 `idle.webm`、`drag.webm`、`wave.webm`、`idle.webp` 文件名，直接替换文件；或修改 `PET.assets`。
- 换颜色：在 `css/blog-pet-lite.css` 里改 `--primary-color` 等变量，主题本身有这些变量时会自动适配。
- 默认只在电脑显示：保持 `defaultVisible: 'desktop'`；手机端点击工具栏图标即可显示，选择会保存在当前浏览器。

## 素材与许可

- 示例动画来自开源项目 **PC2005-cloud/dsh-pet**（MIT 代码；角色与动画素材禁止商用）。
- 大肥鱼形象为社区二创的 DeepSeek「大肥鱼」，形象授权为 **CC BY-NC-SA 4.0**，不可用于商业用途。
- 使用或再发布时请保留作者与来源链接：<https://github.com/PC2005-cloud/dsh-pet>。
- 如果你要商用，请自行替换为拥有商用授权的角色和动画；不要直接使用本包中的角色素材。
- `blog-pet-lite.js` 和 `blog-pet-lite.css` 是可自由修改的示例代码。

## 常见问题

- **页面 404**：确认文件真的在 `source/assets/blog-pet/`，并执行过 `hexo clean`。
- **没有出现按钮**：确认模板里引入了 JS，且浏览器控制台没有报错；主题没有 `#tool` 时脚本会使用右下角浮动按钮。
- **出现黑框**：视频不是透明 WebM，或浏览器不支持 VP9 alpha；请用 `-pix_fmt yuva420p` 重新导出，Safari 会自动使用 `idle.webp`。
- **手机默认没有**：这是 `defaultVisible: 'desktop'` 的设计；点工具栏宠物图标显示。
- **拖动没反应**：检查 `.pet-lite__body` 是否被其它元素盖住，以及是否误删了 `touch-action:none`。
- **想显示更多动作**：参考博客完整版宠物文章，或自行扩展 `PET.assets` 与 `playAction()`。

## 验证

本 starter 已在 Chromium/Edge 的桌面与手机尺寸下验证：默认显示规则、显示/隐藏、点击回应、拖动、菜单、大小保存、刷新恢复、隐藏后恢复，控制台无报错。
