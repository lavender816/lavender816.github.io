import { ServiceError } from './errors.mjs';

const fail = () => { throw new ServiceError(502, 'UPSTREAM_PROTOCOL'); };
const blocked = () => { throw new ServiceError(502, 'UPSTREAM_BLOCKED'); };
const object = v => v && typeof v === 'object' && !Array.isArray(v);

// Convert only text-generation events. Tool/function execution is never enabled.
export function createProtocolDecoder(protocol) {
  let finish = null, geminiFinished = false;
  const blocks = new Map();
  return chunk => {
    if (!object(chunk) || chunk.error || chunk.type === 'error') return fail();
    let text = '', done = false;
    if (protocol === 'responses') {
      if (typeof chunk.type !== 'string') return fail();
      if (chunk.type === 'response.output_item.added') {
        if (!['message','reasoning'].includes(chunk.item?.type)) return blocked();
      } else if (chunk.type === 'response.output_text.delta' || chunk.type === 'response.refusal.delta') {
        if (typeof chunk.delta !== 'string') return fail();
        text = chunk.delta;
      } else if (chunk.type === 'response.completed') {
        if (chunk.response?.status !== 'completed') return fail();
        finish = 'stop'; done = true;
      } else if (chunk.type === 'response.incomplete') {
        if (chunk.response?.incomplete_details?.reason !== 'max_output_tokens') return blocked();
        finish = 'length'; done = true;
      } else if (['response.failed','response.cancelled'].includes(chunk.type) || /(?:function_call|tool_call)/.test(chunk.type)) return blocked();
    } else if (protocol === 'anthropic') {
      if (typeof chunk.type !== 'string') return fail();
      if (chunk.type === 'content_block_start') {
        if (!Number.isSafeInteger(chunk.index) || chunk.index < 0 || chunk.index > 127 || blocks.has(chunk.index)
            || blocks.size >= 128 || !object(chunk.content_block)) return fail();
        const type = chunk.content_block.type;
        if (!['text','thinking','redacted_thinking'].includes(type)) return blocked();
        blocks.set(chunk.index, type);
        if (type === 'text') { text = chunk.content_block.text; if (typeof text !== 'string') return fail(); }
      } else if (chunk.type === 'content_block_delta') {
        const type = blocks.get(chunk.index);
        if (!type || !object(chunk.delta)) return fail();
        if (type === 'text') { if (chunk.delta.type !== 'text_delta' || typeof chunk.delta.text !== 'string') return fail(); text = chunk.delta.text; }
      } else if (chunk.type === 'message_delta') {
        const reason = chunk.delta?.stop_reason;
        if (reason !== undefined && reason !== null) {
          if (!['end_turn','stop_sequence','max_tokens'].includes(reason)) return blocked();
          finish = reason === 'max_tokens' ? 'length' : 'stop';
        }
      } else if (chunk.type === 'message_stop') { if (!finish) return fail(); done = true; }
    } else if (protocol === 'gemini') {
      if (chunk.promptFeedback?.blockReason) return blocked();
      if (!Array.isArray(chunk.candidates) || chunk.candidates.length > 1 || geminiFinished) return fail();
      const candidate = chunk.candidates[0];
      if (candidate) {
        if (!object(candidate) || candidate.index !== undefined && candidate.index !== 0) return fail();
        for (const part of candidate.content?.parts || []) {
          if (!object(part) || part.functionCall || part.executableCode || part.functionResponse) return blocked();
          if (part.text !== undefined && typeof part.text !== 'string') return fail();
          if (!part.thought && part.text) text += part.text;
        }
        if (candidate.finishReason) {
          if (!['STOP','MAX_TOKENS'].includes(candidate.finishReason)) return blocked();
          finish = candidate.finishReason === 'STOP' ? 'stop' : 'length';
          geminiFinished = true; done = true;
        }
      }
    } else {
      if (!Array.isArray(chunk.choices) || chunk.choices.length > 1) return fail();
      const choice = chunk.choices[0];
      if (choice) {
        if (!object(choice) || choice.index && choice.index !== 0 || choice.delta !== undefined && !object(choice.delta)) return fail();
        if (choice.delta?.tool_calls && (!Array.isArray(choice.delta.tool_calls) || choice.delta.tool_calls.length) || choice.delta?.function_call) return blocked();
        if (choice.finish_reason) {
          if (!['stop','length'].includes(choice.finish_reason)) return blocked();
          finish = choice.finish_reason;
        }
        const content = choice.delta?.content;
        if (content !== undefined && content !== null && typeof content !== 'string') return fail();
        text = content || '';
      }
    }
    return {text, finish, done};
  };
}

// Only leading reasoning blocks are filtered; literal tags later in an answer
// or code block remain text. Hold partial tags across arbitrary SSE boundaries.
export function createThinkingFilter(enabled = true) {
  let buffer = '', mode = enabled ? 'prefix' : 'text', tag = '';
  return (text, final = false) => {
    if (mode === 'text') return text;
    buffer += text;
    for (;;) {
      if (mode === 'prefix') {
        const trimmed = buffer.trimStart();
        const found = ['<think>', '<analysis>'].find(value => trimmed.startsWith(value));
        if (found) { tag = found; buffer = trimmed.slice(tag.length); mode = 'hidden'; continue; }
        if (!final && (!trimmed || ['<think>', '<analysis>'].some(value => value.startsWith(trimmed)))) {
          if (buffer.length > 64) buffer = buffer.slice(-16);
          return '';
        }
        // Do not expose an unfinished reasoning marker even at EOF.
        if (final && trimmed && ['<think>', '<analysis>'].some(value => value.startsWith(trimmed))) { buffer = ''; return ''; }
        mode = 'text'; const output = buffer; buffer = ''; return output;
      }
      const close = tag.replace('<', '</'), index = buffer.indexOf(close);
      if (index < 0) { buffer = buffer.slice(-(close.length - 1)); return ''; }
      buffer = buffer.slice(index + close.length); mode = 'prefix';
    }
  };
}
