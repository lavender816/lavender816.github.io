// Owner-configured text protocols. No SDK, proxy, fallback or redirects.
import https from 'node:https';
import { lookup as dnsLookup } from 'node:dns/promises';
import { isIP } from 'node:net';
import { Readable } from 'node:stream';

export const DEFAULT_API_BASE = 'https://api.deepseek.com';
export const PROVIDER_ID = /^[a-z][a-z0-9-]{0,31}$/;
export const MODEL_ID = /^(?!.*:\/\/)(?!.*\.\.)[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$/;
export const PROTOCOLS = ['chat-completions', 'responses', 'anthropic', 'gemini'];

export function normalizeApiBase(value) {
  if (typeof value !== 'string' || value.length > 2048 || !/^https:\/\//.test(value)
      || /[^\x21-\x7e]|[\\?#%]/.test(value) || /\/\.{1,2}(?:\/|$)/.test(value)) throw new Error('INVALID_API_BASE');
  const url = new URL(value);
  if (url.protocol !== 'https:' || url.username || url.password || url.port || isIP(url.hostname)
      || !/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(url.hostname)
      || /(?:^|\.)(?:localhost|local|internal|lan|home|onion)$/.test(url.hostname)
      || !/^\/(?:[A-Za-z0-9._~-]+\/)*[A-Za-z0-9._~-]*$/.test(url.pathname)
      || url.pathname.split('/').some(part => part === '.' || part === '..')) throw new Error('INVALID_API_BASE');
  let base = url.href.replace(/\/+$/, '');
  // Accept either the documented API base or the full completion endpoint.
  for (const suffix of ['/chat/completions', '/responses', '/messages']) {
    if (base.endsWith(suffix)) { base = base.slice(0, -suffix.length); break; }
  }
  return base;
}

export function validateProvider(config) {
  if (typeof config.provider !== 'string' || !PROVIDER_ID.test(config.provider)
      || !['max_tokens', 'max_completion_tokens'].includes(config.tokenParameter)
      || !['auto', 'on', 'off'].includes(config.jsonMode)
      || !PROTOCOLS.includes(config.apiProtocol)
      || !['auto', 'on', 'off'].includes(config.reasoningFilter)
      || typeof config.anthropicWorkspaceId !== 'string'
      || !/^(?:[A-Za-z0-9][A-Za-z0-9_-]{0,127})?$/.test(config.anthropicWorkspaceId)
      || config.anthropicWorkspaceId && !['anthropic', 'chat-completions'].includes(config.apiProtocol)
      || config.apiProtocol === 'gemini' && !/^(?:models\/)?[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/.test(config.model)) throw new Error('INVALID_PROVIDER');
  const base = normalizeApiBase(config.apiBaseUrl);
  // A DeepSeek-labelled configuration cannot silently send its key elsewhere.
  if (config.provider === 'deepseek' && ![DEFAULT_API_BASE, DEFAULT_API_BASE + '/v1'].includes(base)) throw new Error('INVALID_PROVIDER');
  if (config.provider === 'deepseek' && config.apiProtocol !== 'chat-completions') throw new Error('INVALID_PROVIDER');
  return base;
}

export function completionPayload(config, messages, workshop) {
  const native = config.provider === 'deepseek';
  return { model: config.model, stream: true, [config.tokenParameter]: config.maxOutputTokens,
    ...(config.provider === 'minimax' ? { reasoning_split: true } : {}),
    ...(native ? { thinking: { type: 'disabled' } } : {}),
    ...(workshop && (config.jsonMode === 'on' || config.jsonMode === 'auto' && native)
      ? { response_format: { type: 'json_object' } } : {}), messages };
}

export function upstreamRequest(config, messages, workshop) {
  const headers = { 'Content-Type':'application/json', Accept:'text/event-stream', 'Accept-Encoding':'identity' };
  const systems = messages.filter(m => m.role === 'system').map(m => m.content).join('\n\n');
  const dialogue = messages.filter(m => m.role !== 'system');
  let endpoint, payload;
  if (config.apiProtocol === 'anthropic') {
    endpoint = config.apiBaseUrl + '/messages';
    headers['x-api-key'] = config.apiKey;
    headers['anthropic-version'] = '2026-10-21';
    payload = {model:config.model, stream:true, max_tokens:config.maxOutputTokens, system:systems, messages:dialogue};
  } else if (config.apiProtocol === 'gemini') {
    endpoint = config.apiBaseUrl + '/models/' + config.model.replace(/^models\//, '') + ':streamGenerateContent?alt=sse';
    headers['x-goog-api-key'] = config.apiKey;
    payload = {systemInstruction:{parts:[{text:systems}]},
      contents:dialogue.map(m => ({role:m.role === 'assistant' ? 'model' : 'user', parts:[{text:m.content}]})),
      generationConfig:{maxOutputTokens:config.maxOutputTokens,
        ...(workshop && config.jsonMode === 'on' ? {responseMimeType:'application/json'} : {})}};
  } else {
    headers.Authorization = `Bearer ${config.apiKey}`;
    endpoint = config.apiBaseUrl + (config.apiProtocol === 'responses' ? '/responses' : '/chat/completions');
    payload = config.apiProtocol === 'responses'
      ? {model:config.model, stream:true, store:false, max_output_tokens:config.maxOutputTokens, input:messages,
        ...(workshop && config.jsonMode === 'on' ? {text:{format:{type:'json_object'}}} : {})}
      : completionPayload(config, messages, workshop);
  }
  if (config.anthropicWorkspaceId) headers['anthropic-workspace-id'] = config.anthropicWorkspaceId;
  return {endpoint, headers, payload};
}

export function publicAddress(address) {
  const family = isIP(address);
  if (family === 4) {
    const [a,b,c] = address.split('.').map(Number);
    return !(a === 0 || a === 10 || a === 127 || a >= 224
      || a === 100 && b >= 64 && b <= 127 || a === 169 && b === 254
      || a === 172 && b >= 16 && b <= 31 || a === 192 && (b === 168 || b === 0 || b === 88 && c === 99)
      || a === 198 && (b === 18 || b === 19 || b === 51 && c === 100)
      || a === 203 && b === 0 && c === 113);
  }
  if (family === 6) {
    // Only globally-routed unicast; excludes loopback, mapped IPv4, NAT64,
    // link-local, ULA, multicast, documentation and transition mechanisms.
    const groups = address.toLowerCase().split(':');
    const first = parseInt(groups[0],16), second = parseInt(groups[1] || '0',16);
    return first >= 0x2000 && first <= 0x3fff && first !== 0x2002
      && !(first === 0x2001 && (second < 0x200 || second === 0xdb8))
      && !(first === 0x3fff && second <= 0x0fff);
  }
  return false;
}

function untilAbort(pending, signal) {
  return new Promise((resolve,reject) => {
    const abort = () => { cleanup(); reject(new Error('UPSTREAM_ABORTED')); };
    const cleanup = () => signal.removeEventListener('abort',abort);
    Promise.resolve(pending).then(value => { cleanup(); resolve(value); },error => { cleanup(); reject(error); });
    if (signal.aborted) abort(); else signal.addEventListener('abort',abort,{once:true});
  });
}

export function createUpstreamFetch({ lookup = dnsLookup, request = https.request } = {}) {
  return async (value, init) => {
    // Only these fixed text endpoints may carry credentials. Gemini's sole
    // query parameter is constant; keys can never be placed in a URL.
    const match = typeof value === 'string' && value.match(/^(https:\/\/.+?)(\/chat\/completions|\/responses|\/messages|\/models\/[A-Za-z0-9][A-Za-z0-9._-]{0,127}:streamGenerateContent\?alt=sse)$/);
    if (!match || normalizeApiBase(match[1]) !== match[1] || init?.method !== 'POST' || init.redirect !== 'error') throw new Error('UPSTREAM_DESTINATION');
    const url = new URL(value), signal = AbortSignal.any([init.signal || new AbortController().signal, AbortSignal.timeout(10_000)]);
    const records = await untilAbort(lookup(url.hostname,{all:true,verbatim:true}),signal);
    signal.throwIfAborted();
    if (!Array.isArray(records) || !records.length || records.length > 64
        || records.some(item => !item || !publicAddress(item.address) || isIP(item.address) !== item.family)) throw new Error('UPSTREAM_PRIVATE_ADDRESS');
    // Prefer IPv4 when available: many mainland hosts have DNS AAAA records
    // without a usable IPv6 route. No second/billable HTTP attempt is made.
    const selected = records.find(item => item.family === 4) || records[0];
    return new Promise((resolve,reject) => {
      // Pin the already-validated DNS answer for this TLS connection. A second
      // resolution (DNS rebinding) cannot redirect the Authorization header.
      const req = request(url, { method:'POST', headers:init.headers, signal:init.signal,
        agent:false, family:selected.family, autoSelectFamily:false, servername:url.hostname,
        maxHeaderSize:16384, rejectUnauthorized:true,
        lookup:(_host, options, callback) => options?.all
          ? callback(null,[selected]) : callback(null,selected.address,selected.family)
      }, response => {
        const status = response.statusCode;
        if (!Number.isInteger(status) || status < 200 || status > 599 || status >= 300 && status < 400
            || response.headers['content-encoding'] && response.headers['content-encoding'] !== 'identity') {
          response.destroy(); reject(new Error('UPSTREAM_RESPONSE')); return;
        }
        try {
          const headers = {'content-type':response.headers['content-type'] || ''};
          if (typeof response.headers['retry-after'] === 'string' && /^\d{1,5}$/.test(response.headers['retry-after'])) headers['retry-after'] = response.headers['retry-after'];
          resolve(new Response(Readable.toWeb(response), {status, headers}));
        } catch { response.destroy(); reject(new Error('UPSTREAM_RESPONSE')); }
      });
      req.on('error',() => reject(new Error('UPSTREAM_CONNECTION')));
      req.end(init.body);
    });
  };
}

export const upstreamFetch = createUpstreamFetch();
