import * as fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { ServiceError } from './errors.mjs';

// One small atomic snapshot, owned by the service account. It contains bounded
// timestamps and keyed pseudonyms, never IPs, prompts, provider keys or tickets.
export function createAbuseStore(stateDir, now) {
  let initialized = false, fault = false;
  const fail = () => { fault = true; throw new ServiceError(503, 'STATE_UNAVAILABLE'); };
  const file = typeof stateDir === 'string' && path.isAbsolute(stateDir) ? path.join(stateDir, 'abuse.json') : null;
  function directory() {
    if (!file || fault) return fail();
    fs.mkdirSync(stateDir, {recursive:true, mode:0o700});
    const stat = fs.lstatSync(stateDir);
    if (!stat.isDirectory() || stat.isSymbolicLink() || process.platform !== 'win32' && (stat.mode & 0o022)) return fail();
  }
  const object = v => v && typeof v === 'object' && !Array.isArray(v);
  const stamps = (v, max) => Array.isArray(v) && v.length <= max && v.every(t => Number.isSafeInteger(t) && t >= 0 && t <= now());
  function load() {
    let fd;
    try {
      directory();
      fd = fs.openSync(file, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0));
      const stat = fs.fstatSync(fd);
      if (!stat.isFile() || stat.size > 8 * 1024 * 1024 || process.platform !== 'win32' && (stat.mode & 0o077)) return fail();
      const value = JSON.parse(fs.readFileSync(fd,'utf8'));
      if (!object(value) || Object.keys(value).sort().join() !== 'clients,consumed,global,version' || value.version !== 1
          || !stamps(value.global, 65536) || !Array.isArray(value.clients) || value.clients.length > 4096
          || !Array.isArray(value.consumed) || value.consumed.length > 4096) return fail();
      const keys = new Set(), proofs = new Set();
      for (const row of value.clients) {
        if (!Array.isArray(row) || row.length !== 4 || !/^[A-Za-z0-9_-]{43}$/.test(row[0]) || keys.has(row[0])
            || !stamps(row[1],65536) || !stamps(row[2],20) || !Number.isSafeInteger(row[3]) || row[3] < 0 || row[3] > now()) return fail();
        keys.add(row[0]);
      }
      for (const row of value.consumed) {
        if (!Array.isArray(row) || row.length !== 2 || !/^[a-f0-9]{64}$/.test(row[0]) || proofs.has(row[0])
            || !Number.isSafeInteger(row[1]) || row[1] < 0 || row[1] > now() + 600000) return fail();
        proofs.add(row[0]);
      }
      initialized = true; return value;
    } catch (error) {
      if (error.code === 'ENOENT' && !initialized && !fault) return null;
      return fail();
    } finally { if (fd !== undefined) fs.closeSync(fd); }
  }
  function save(value) {
    let temporary, fd;
    try {
      directory();
      if (initialized && !fs.existsSync(file)) return fail();
      // Replacing a symlink is safe, but detecting tampering must fail closed.
      if (fs.existsSync(file) && !fs.lstatSync(file).isFile()) return fail();
      const bytes = JSON.stringify(value);
      if (Buffer.byteLength(bytes) > 8 * 1024 * 1024) return fail();
      temporary = path.join(stateDir, '.abuse-' + randomUUID() + '.tmp');
      fd = fs.openSync(temporary, 'wx', 0o600);
      fs.writeFileSync(fd, bytes); fs.fsyncSync(fd); fs.closeSync(fd); fd = undefined;
      fs.renameSync(temporary, file); temporary = undefined;
      if (process.platform !== 'win32') {
        fd = fs.openSync(stateDir, fs.constants.O_RDONLY | fs.constants.O_DIRECTORY);
        fs.fsyncSync(fd); fs.closeSync(fd); fd = undefined;
      }
      initialized = true;
    } catch { return fail(); }
    finally {
      if (fd !== undefined) fs.closeSync(fd);
      if (temporary) { try { fs.unlinkSync(temporary); } catch {} }
    }
  }
  return {load, save};
}
