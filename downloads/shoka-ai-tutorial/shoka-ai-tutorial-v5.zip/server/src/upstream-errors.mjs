import { ServiceError } from './errors.mjs';

// Never forward provider messages: they can contain credentials, input snippets
// or account details. Read only a bounded error envelope, under the request's
// existing deadline, and classify allowlisted codes/statuses. Never retry here.
export async function upstreamError(response, provider) {
  const reader = response.body?.getReader();
  let bytes = 0, chunks = [], code = '';
  try {
    if (reader) while (true) {
      const item = await reader.read();
      if (item.done) break;
      bytes += item.value.byteLength;
      if (bytes > 32768) break;
      chunks.push(item.value);
    }
    if (bytes <= 32768 && chunks.length) {
      const data = JSON.parse(Buffer.concat(chunks).toString('utf8'));
      const value = data?.error?.code ?? data?.error?.type ?? data?.code;
      if ((typeof value === 'string' || typeof value === 'number') && /^[a-zA-Z0-9_-]{1,64}$/.test(String(value))) code = String(value);
    }
  } catch { /* A malformed error still has an HTTP status; no raw data escapes. */ }
  finally { await reader?.cancel().catch(() => {}); }
  let status = 503, name;
  const glm = provider === 'glm';
  if (response.status === 401 || glm && ['1000', '1001', '1003', '1005'].includes(code)) name = 'UPSTREAM_AUTH';
  else if (response.status === 402 || code === 'insufficient_quota' || glm && ['1113', '1309', '1314'].includes(code)) name = 'UPSTREAM_BILLING';
  else if (glm && ['1308', '1310', '1316', '1317', '1318', '1319', '1320', '1321'].includes(code)) name = 'UPSTREAM_QUOTA';
  else if (response.status === 403 || glm && ['1220', '1311', '1315'].includes(code)) name = 'UPSTREAM_PERMISSION';
  else if (response.status === 503 || glm && code === '1305' || code === 'overloaded_error') name = 'UPSTREAM_BUSY';
  else if (response.status === 429) { name = 'UPSTREAM_RATE_LIMIT'; status = 429; }
  else if (glm && code === '1301') { name = 'UPSTREAM_BLOCKED'; status = 422; }
  else if ([400, 404, 422].includes(response.status)) { name = 'UPSTREAM_PARAMETERS'; status = 502; }
  else if (response.status >= 500) name = 'UPSTREAM_UNAVAILABLE';
  else { name = 'UPSTREAM_REJECTED'; status = 502; }
  const retry = response.headers.get('retry-after');
  const retryAfter = ['UPSTREAM_BUSY', 'UPSTREAM_RATE_LIMIT'].includes(name)
    && typeof retry === 'string' && /^\d{1,5}$/.test(retry) && +retry >= 1 && +retry <= 86400 ? +retry : null;
  return new ServiceError(status, name, retryAfter ? {retryAfter} : {});
}
