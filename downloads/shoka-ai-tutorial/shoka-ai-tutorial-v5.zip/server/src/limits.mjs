// Owner controls. These are implementation ceilings, not recommended settings
// or guarantees about a provider's model/context/account limits.
export const MAX_INPUT_CHARS = 1_048_576;
export const MAX_OUTPUT_TOKENS = 1_048_576;
// Largest whole-second timer with headroom for browser/proxy deadlines.
export const MAX_TIMEOUT_MS = 2_147_483_000;
export const RUNTIME_LIMITS = Object.freeze({
  maxConcurrent: [1, Number.MAX_SAFE_INTEGER],
  publicPerIpConcurrentLimit: [1, Number.MAX_SAFE_INTEGER],
  maxInputChars: [1, MAX_INPUT_CHARS],
  publicPerIpMinuteLimit: [1, Number.MAX_SAFE_INTEGER],
  challengeAfterRequests: [1, Number.MAX_SAFE_INTEGER],
  publicGlobalMinuteLimit: [1, Number.MAX_SAFE_INTEGER],
  publicGlobalHourLimit: [1, Number.MAX_SAFE_INTEGER],
  requestTimeoutMs: [1000, MAX_TIMEOUT_MS]
});
