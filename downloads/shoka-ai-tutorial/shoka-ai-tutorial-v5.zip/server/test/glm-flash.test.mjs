// Exact GLM-4.7-Flash profile from the official docs. No real credentials/calls.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {createAiServer, validateConfig} from '../src/service.mjs';
import {upstreamRequest} from '../src/upstream.mjs';
import {WORKSHOP_KINDS} from '../src/workshop.mjs';
import {listenForFetch} from './listen-test.mjs';

const SITE='https://blog.example.com';
const config={adminToken:'glm-flash-owner-test-0123456789-abcdef',apiKey:'fake-glm-key-for-isolated-tests-only',
  provider:'glm',apiBaseUrl:'https://open.bigmodel.cn/api/paas/v4',model:'glm-4.7-flash',
  apiProtocol:'chat-completions',tokenParameter:'max_tokens',jsonMode:'auto',maxOutputTokens:16384,
  publicEnabled:true,publicContinuous:true,publicPerIpDailyLimit:30,publicPerIpMinuteLimit:60,challengeAfterRequests:29};
const frame=content=>'data: '+JSON.stringify(content)+'\n\n';
const catalog={version:1,site:SITE,generatedAt:'2026-10-22T00:00:00Z',articles:[{
  id:'42',title:'公开文章',path:'/posts/42/',url:SITE+'/posts/42/',excerpt:'导读用例',text:'这里是公开文章的内容。',tags:[],categories:[]}]};

test('GLM-4.7-Flash official profile produces exactly the documented streaming endpoint and token field',()=>{
  const c=validateConfig(config),r=upstreamRequest(c,[{role:'user',content:'你好'}],true);
  assert.equal(r.endpoint,'https://open.bigmodel.cn/api/paas/v4/chat/completions');
  assert.equal(r.headers.Authorization,'Bearer '+config.apiKey);
  assert.deepEqual(r.payload,{model:'glm-4.7-flash',stream:true,max_tokens:16384,messages:[{role:'user',content:'你好'}]});
  assert.equal(r.payload.max_completion_tokens,undefined);assert.equal(r.payload.thinking,undefined);
  const json=upstreamRequest(validateConfig({...config,jsonMode:'on'}),[],true);
  assert.deepEqual(json.payload.response_format,{type:'json_object'});
});

test('GLM Flash answer, guide, selection, control, tour and all workshops normalize without exposing reasoning',async t=>{
  const stateDir=await fs.mkdtemp(path.join(os.tmpdir(),'glm-flash-'));
  const calls=[];
  const server=createAiServer(config,{stateDir,knowledge:catalog,fetchImpl:async(url,init)=>{
    const payload=JSON.parse(init.body);calls.push({url,payload});
    const workshop=payload.messages[0].content.includes('中文文本工坊');
    const text=workshop?JSON.stringify({title:'标题',summary:'概要',cards:[{title:'内容',text:'一段完整的正文。',tag:'虚构',sourceIds:[],quotes:[]}],actions:[],memory:''}):'GLM 的完整 **回答**。';
    return new Response(frame({choices:[{index:0,delta:{role:'assistant',reasoning_content:'不应暴露的思考',content:null},finish_reason:null}]})
      +frame({choices:[{index:0,delta:{content:text.slice(0,3)},finish_reason:null}]})
      +frame({choices:[{index:0,delta:{content:text.slice(3)},finish_reason:null}]})
      +frame({choices:[{index:0,delta:{},finish_reason:'stop'}],usage:{completion_tokens:200}})+'data: [DONE]\n\n',
      {headers:{'Content-Type':'text/event-stream; charset=utf-8'}});
  }});
  await listenForFetch(server);t.after(async()=>{await server.shutdown();await fs.rm(stateDir,{recursive:true,force:true});});
  const requests=[['ask',{question:'你好'}],['chat',{question:'请介绍本站'}],['explain',{text:'选中文字',path:'/posts/42/'}],
    ['guide',{path:'/posts/42/'}],['chat',{question:'推荐文章',tour:true}],['chat',{question:'夜间模式',control:true}],
    ...WORKSHOP_KINDS.map(kind=>['workshop',{kind,input:'一段测试文字'}])];
  for(const [mode,body] of requests) {
    const response=await fetch('http://127.0.0.1:'+server.address().port+'/api/public/'+mode,{
      method:'POST',headers:{Origin:SITE,'X-Real-IP':'8.8.8.8','Content-Type':'application/json'},body:JSON.stringify(body)});
    assert.equal(response.status,200);
    const result=await response.text();assert.match(result,/event: done/);assert.doesNotMatch(result,/不应暴露的思考|event: error/);
    if(mode==='workshop')assert.match(result,/event: result/);
  }
  assert.equal(calls.length,13);
  for(const {url,payload} of calls) {assert.equal(url,config.apiBaseUrl+'/chat/completions');assert.equal(payload.model,'glm-4.7-flash');assert.equal(payload.max_tokens,16384);}
});
