import test from 'node:test';
import assert from 'node:assert/strict';
import * as fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { EventEmitter } from 'node:events';
import { createAiServer, validateConfig } from '../src/service.mjs';
import { MAX_OUTPUT_TOKENS, MAX_INPUT_CHARS, MAX_TIMEOUT_MS, RUNTIME_LIMITS } from '../src/limits.mjs';
import { createAbuseGuard } from '../src/abuse.mjs';
import { upstreamError } from '../src/upstream-errors.mjs';
import { validatePublicBody, publicPlan } from '../src/knowledge.mjs';
import { listenForFetch } from './listen-test.mjs';

const TOKEN = 'unit-admin-0123456789-abcdef-0123456789', KEY = 'unit-model-key-must-never-leak';
const ORIGIN = 'https://blog.example.com';
const baseConfig = {adminToken:TOKEN,apiKey:KEY,provider:'glm',apiBaseUrl:'https://models.example/v1',model:'test-model',
  publicEnabled:true,publicContinuous:true,challengeAfterRequests:10000,publicPerIpMinuteLimit:10000};

async function fixture(t, config = {}, fetchImpl = async () => new Response('not used', {status:500})) {
  const stateDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ai-wide-controls-'));
  let calls = 0;
  const server = createAiServer({...baseConfig,...config}, {stateDir,fetchImpl:async (...args) => {calls++;return fetchImpl(...args);}});
  await listenForFetch(server);
  t.after(async () => {await server.shutdown();await fs.rm(stateDir,{recursive:true,force:true});});
  const base = 'http://127.0.0.1:' + server.address().port;
  return {server, stateDir, get calls(){return calls;}, post:(body={question:'测试问题'}) => fetch(base+'/api/public/chat', {
    method:'POST',headers:{Origin:ORIGIN,'Content-Type':'application/json','X-Real-IP':'8.8.8.8'},body:JSON.stringify(body)}),
    status:() => fetch(base+'/api/public/status').then(r=>r.json())};
}

test('every runtime control accepts its actual upper/lower boundary and rejects overflow/types', () => {
  for (const [field, [min,max]] of Object.entries(RUNTIME_LIMITS)) {
    for (const value of [min,max]) assert.equal(validateConfig({...baseConfig,[field]:value})[field],value);
    for (const value of [min-1,max+1,1.5,true,'4',null]) assert.throws(()=>validateConfig({...baseConfig,[field]:value}),/INVALID_CONFIG/);
  }
  assert.equal(validateConfig(baseConfig).publicPerIpConcurrentLimit,1);
  assert.equal(validateConfig(baseConfig).maxConcurrent,2);
  assert.equal(validateConfig({...baseConfig,maxOutputTokens:MAX_OUTPUT_TOKENS}).maxOutputTokens,MAX_OUTPUT_TOKENS);
  assert.throws(()=>validateConfig({...baseConfig,maxOutputTokens:MAX_OUTPUT_TOKENS+1}));
  assert.equal(MAX_TIMEOUT_MS,2147483000);
  for(const [concurrency,connections] of [[2,64],[100,132],[Number.MAX_SAFE_INTEGER,4096]]) {
    assert.equal(createAiServer({...baseConfig,maxConcurrent:concurrency}).maxConnections,connections);
  }
});

test('test listeners skip Fetch-blocked 4190 and 6679 without ever retrying API calls',async()=>{
  class Listener extends EventEmitter {
    ports=[4190,6679,42001];closed=0;
    listen(){this.port=this.ports.shift();queueMicrotask(()=>this.emit('listening'));}
    address(){return {port:this.port};}
    close(done){this.closed++;done();}
  }
  const listener=new Listener();await listenForFetch(listener);
  assert.equal(listener.port,42001);assert.equal(listener.closed,2);
});

test('public input cap and prompt construction no longer conceal a 1000/4000-character cap', () => {
  const question = '较长的问题与资料'.repeat(1200);
  validatePublicBody('chat',{question},MAX_INPUT_CHARS);
  const plan = publicPlan('chat',{question},null);
  assert.equal(JSON.parse(plan.messages[1].content.slice('DATA_JSON\n'.length)).question,question);
  validatePublicBody('explain',{text:question},MAX_INPUT_CHARS);
  assert.ok(publicPlan('explain',{text:question},null).messages);
  assert.throws(()=>validatePublicBody('chat',{question},question.length-1));
});

test('large per-IP rate histories survive restart without resetting limits or rejecting valid state', async t => {
  const stateDir = await fs.mkdtemp(path.join(os.tmpdir(),'ai-wide-abuse-'));
  t.after(()=>fs.rm(stateDir,{recursive:true,force:true}));
  const config = validateConfig({...baseConfig,publicPerIpMinuteLimit:150,challengeAfterRequests:200,publicPerIpConcurrentLimit:4});
  let guard=createAbuseGuard(config,{stateDir});
  for(let i=0;i<100;i++) guard.enter('8.8.8.8').release();
  guard=createAbuseGuard(config,{stateDir});
  for(let i=0;i<50;i++) guard.enter('8.8.8.8').release();
  assert.throws(()=>guard.enter('8.8.8.8'),{code:'IP_RATE_LIMIT'});
});

test('owner-configured per-IP concurrency replaces the fixed one-request ceiling', () => {
  const guard=createAbuseGuard(validateConfig({...baseConfig,publicPerIpConcurrentLimit:4}));
  const slots=Array.from({length:4},()=>guard.enter('8.8.8.8'));
  assert.throws(()=>guard.enter('8.8.8.8'),{code:'IP_CONCURRENT_LIMIT'});
  slots[0].release();slots[0].release();guard.enter('8.8.8.8').release();
  slots.slice(1).forEach(slot=>slot.release());
});

const cases = [
  [401,'401',503,'UPSTREAM_AUTH'],[429,'1305',503,'UPSTREAM_BUSY'],[429,'1302',429,'UPSTREAM_RATE_LIMIT'],
  [429,'1113',503,'UPSTREAM_BILLING'],[429,'1308',503,'UPSTREAM_QUOTA'],[429,'1310',503,'UPSTREAM_QUOTA'],
  [429,'1311',503,'UPSTREAM_PERMISSION'],[429,'1315',503,'UPSTREAM_PERMISSION'],[403,'1220',503,'UPSTREAM_PERMISSION'],
  [400,'1211',502,'UPSTREAM_PARAMETERS'],[400,'1301',422,'UPSTREAM_BLOCKED'],[500,'1200',503,'UPSTREAM_UNAVAILABLE']
];
for(const [http, vendorCode, status, code] of cases) test('GLM '+vendorCode+' is sanitized as '+code, async () => {
  const response = new Response(JSON.stringify({error:{code:vendorCode,message:KEY+' private prompt'}}),{status:http,headers:{'Retry-After':'25'}});
  const error=await upstreamError(response,'glm');
  assert.equal(error.status,status);assert.equal(error.code,code);
  assert.equal(error.details.retryAfter,['UPSTREAM_BUSY','UPSTREAM_RATE_LIMIT'].includes(code)?25:undefined);
  assert.doesNotMatch(JSON.stringify(error),/unit-model-key|private prompt/);
});

for(const protocol of ['chat-completions','responses','anthropic','gemini']) {
  test(protocol+': errors are actionable without leaking credentials or auto-retrying',async t=>{
    const f=await fixture(t,{apiProtocol:protocol},async()=>new Response(JSON.stringify({error:{code:'1305',message:KEY+' '+TOKEN}}),
      {status:429,headers:{'Retry-After':'25'}}));
    const response=await f.post();assert.equal(response.status,503);assert.equal(response.headers.get('Retry-After'),'25');
    assert.deepEqual(await response.json(),{error:{code:'UPSTREAM_BUSY'}});assert.equal(f.calls,1);
    const ledger=JSON.parse(await fs.readFile(path.join(f.stateDir,'quota.json'),'utf8'));
    assert.equal(Object.values(ledger.days).reduce((a,b)=>a+b,0),1);
  });
}

test('malformed/oversized errors are bounded and their stream is cancelled',async()=>{
  let cancelled=false;
  const response=new Response(new ReadableStream({pull(c){c.enqueue(new Uint8Array(20000));},cancel(){cancelled=true;}}),{status:401});
  assert.equal((await upstreamError(response,'glm')).code,'UPSTREAM_AUTH');assert.equal(cancelled,true);
  for(const retry of ['999999999','-1','abc','https://private.example','0']) {
    assert.deepEqual((await upstreamError(new Response('invalid json',{status:429,headers:{'Retry-After':retry}}),'custom')).details,{});
  }
});

test('compatible chat providers can send empty tool_calls arrays without blocking normal text',async t=>{
  const f=await fixture(t,{},async()=>new Response('data: {"choices":[{"delta":{"content":"正常回答","tool_calls":[]},"finish_reason":null}]}\n\n'
    +'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',{headers:{'Content-Type':'text/event-stream'}}));
  const text=await(await f.post()).text();assert.match(text,/正常回答/);assert.match(text,/event: done/);assert.doesNotMatch(text,/event: error/);
});

test('maximum limits produce bounded public transport metadata without starting model requests',async t=>{
  const f=await fixture(t,{maxConcurrent:100,publicPerIpConcurrentLimit:20,maxInputChars:MAX_INPUT_CHARS,
    maxOutputTokens:MAX_OUTPUT_TOKENS,requestTimeoutMs:MAX_TIMEOUT_MS});
  const status=await f.status();
  assert.equal(status.transport.maxResponseBytes,67108864);assert.equal(status.transport.maxAnswerChars,8388608);
  assert.equal(status.transport.timeoutMs,MAX_TIMEOUT_MS);assert.equal(status.transport.userInputChars,MAX_INPUT_CHARS);assert.equal(f.calls,0);
});

test('HTTP admission permits three actual simultaneous generations and applies the selected fourth-request guard',async t=>{
  for(const [maxConcurrent,perIp,code] of [[3,4,'CONCURRENT_LIMIT'],[5,3,'IP_CONCURRENT_LIMIT']]) {
    let ready;const started=new Promise(resolve=>{ready=resolve;}),releases=[];
    const f=await fixture(t,{maxConcurrent,publicPerIpConcurrentLimit:perIp},()=>new Promise(resolve=>{
      releases.push(()=>resolve(new Response('data: {"choices":[{"delta":{"content":"完成"}}]}\n\ndata: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
        {headers:{'Content-Type':'text/event-stream'}})));
      if(releases.length===3)ready();
    }));
    const requests=Array.from({length:3},()=>f.post());
    let deadline;
    try {
      await Promise.race([started,new Promise((_,reject)=>{deadline=setTimeout(()=>reject(new Error('ADMISSION_TIMEOUT')),5000);})]);
      const fourth=await f.post();assert.equal(fourth.status,429);assert.equal((await fourth.json()).error.code,code);
      assert.equal(f.calls,3);
    } finally {clearTimeout(deadline);releases.forEach(release=>release());}
    for(const response of await Promise.all(requests))assert.match(await response.text(),/event: done/);
  }
});

test('expanded Unicode request reaches the chosen upstream intact, beyond the old proxy/body/field sizes',async t=>{
  const question='汉字资料'.repeat(6000);let received;
  const f=await fixture(t,{maxInputChars:65536},async(_url,init)=>{
    received=JSON.parse(JSON.parse(init.body).messages[1].content.slice('DATA_JSON\n'.length)).question;
    return new Response('data: {"choices":[{"delta":{"content":"完整"}}]}\n\ndata: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
      {headers:{'Content-Type':'text/event-stream'}});
  });
  const response=await f.post({question});assert.equal(response.status,200);assert.match(await response.text(),/event: done/);
  assert.equal(received,question);assert.equal(f.calls,1);
});
