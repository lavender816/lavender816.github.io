import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { EventEmitter } from 'node:events';
import { Readable } from 'node:stream';
import { createAiServer, validateConfig } from '../src/service.mjs';
import { normalizeApiBase, publicAddress, createUpstreamFetch, completionPayload } from '../src/upstream.mjs';
import { listenForFetch } from './listen-test.mjs';

const TOKEN='provider-admin-test-0123456789-abcdef', KEY='provider-key-private-test-0123456789';
const SITE='https://blog.example.com', BASE='https://api.vendor.example/compatible/v1';
const catalog={version:1,generatedAt:'2026-10-22T00:00:00Z',site:SITE,articles:[{
  id:'42',title:'公开文章',path:'/posts/42/',url:SITE+'/posts/42/',excerpt:'文章概要',text:'此公开文章用于解释代码和留声机。',tags:[],categories:[]}]};
const frame=text=>'data: '+JSON.stringify({choices:[{delta:{content:text}}]})+'\n\n';
const finish='data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n';
const stream=text=>new Response(frame(text.slice(0,3))+frame(text.slice(3))+finish,{headers:{'Content-Type':'text/event-stream'}});

test('legacy configurations keep DeepSeek defaults; compatible providers accept future and namespaced IDs',()=>{
  const old=validateConfig({adminToken:TOKEN,apiKey:KEY});
  assert.equal(old.provider,'deepseek');assert.equal(old.apiBaseUrl,'https://api.deepseek.com');
  assert.deepEqual(completionPayload(old,[],true).thinking,{type:'disabled'});
  for(const model of ['team/model-v7:latest','model-name-20261022','flash','vendor/model.name']) {
    const custom=validateConfig({adminToken:TOKEN,provider:'any-vendor',apiBaseUrl:BASE,model});
    assert.equal(custom.model,model);assert.equal(custom.apiBaseUrl,BASE);
  }
  for(const base of [BASE,BASE+'/',BASE+'/chat/completions',BASE+'/chat/completions/'])assert.equal(normalizeApiBase(base),BASE);
  assert.equal(normalizeApiBase('https://api.vendor.example:443/v1'),'https://api.vendor.example/v1');
});

test('owner URLs reject HTTP, credentials, query keys, private literals, invalid paths and unintended DeepSeek destinations',()=>{
  for(const apiBaseUrl of ['http://api.vendor.example/v1','https://user:key@api.vendor.example/v1',
    BASE+'?key=secret',BASE+'#secret',BASE+'?',BASE+'/../secret',BASE+'/%2e%2e',BASE+'\\evil',
    'https://127.0.0.1/v1','https://2130706433/v1','https://[::1]/v1',
    'https://metadata.google.internal/v1','https://host.local/v1','https://host.localhost/v1',
    'https://api.vendor.example:8443/v1','https://api.vendor.example/v1\n']) {
    assert.throws(()=>validateConfig({adminToken:TOKEN,provider:'custom',apiBaseUrl}),/^Error: INVALID_CONFIG$/);
  }
  assert.throws(()=>validateConfig({adminToken:TOKEN,provider:'custom'}),/INVALID_CONFIG/);
  assert.throws(()=>validateConfig({adminToken:TOKEN,provider:'deepseek',apiBaseUrl:BASE}),/INVALID_CONFIG/);
  for(const model of ['https://evil.example','../../file','bad\nmodel','bad model','x'.repeat(129)])
    assert.throws(()=>validateConfig({adminToken:TOKEN,provider:'custom',apiBaseUrl:BASE,model}),/INVALID_CONFIG/);
  for(const extra of [{tokenParameter:'tools'}, {jsonMode:'anything'}, {provider:'bad\nlabel'}, {apiKey:'secret\r\nheader-injection'}])
    assert.throws(()=>validateConfig({adminToken:TOKEN,...extra}),/INVALID_CONFIG/);
});

test('address policy denies loopback, cloud metadata, intranet, mapped IPv4 and IPv6 transition ranges',()=>{
  for(const ip of ['0.0.0.0','10.1.2.3','100.64.1.1','127.0.0.1','169.254.169.254','172.16.0.1','192.168.1.1',
    '192.0.2.1','198.18.1.1','198.51.100.1','203.0.113.1','224.0.0.1','255.255.255.255',
    '::','::1','::ffff:8.8.8.8','::ffff:127.0.0.1','64:ff9b::a00:1','fc00::1','fe80::1','ff02::1',
    '2001:db8::1','2001::1','2002:7f00:1::','3fff::1','not-an-ip'])assert.equal(publicAddress(ip),false,ip);
  for(const ip of ['8.8.8.8','1.1.1.1','104.18.1.1','2001:4860:4860::8888','2606:4700:4700::1111'])assert.equal(publicAddress(ip),true,ip);
});

function requestMock(status=200,headers={'content-type':'text/event-stream'},body=frame('安全测试')+finish) {
  const calls=[];
  const request=(url,options,callback)=>{
    const req=new EventEmitter();
    req.end=data=>{calls.push({url,options,body:data});queueMicrotask(()=>{
      const response=Readable.from([Buffer.from(body)]);response.statusCode=status;response.headers=headers;callback(response);
    });};
    return req;
  };
  return {calls,request};
}

test('HTTPS transport validates all DNS answers and pins the selected address without disabling TLS validation',async()=>{
  let dns=0;const mock=requestMock();
  const fetcher=createUpstreamFetch({lookup:async()=>{dns++;return [{address:'8.8.8.8',family:4}];},request:mock.request});
  const response=await fetcher(BASE+'/chat/completions',{method:'POST',redirect:'error',headers:{Authorization:'Bearer '+KEY},body:'{}',signal:new AbortController().signal});
  assert.match(await response.text(),/安全测试/);assert.equal(dns,1);
  const options=mock.calls[0].options;
  assert.equal(options.agent,false);assert.equal(options.rejectUnauthorized,true);assert.equal(options.servername,'api.vendor.example');
  options.lookup('api.vendor.example',{},(error,address,family)=>{assert.equal(error,null);assert.equal(address,'8.8.8.8');assert.equal(family,4);});
  options.lookup('api.vendor.example',{all:true},(error,addresses)=>{assert.equal(error,null);assert.deepEqual(addresses,[{address:'8.8.8.8',family:4}]);});
  assert.equal(dns,1,'connection must not re-resolve a rebinding hostname');
});

test('unsafe/mixed DNS and cancellation stop the connection before any Authorization header can be sent',async()=>{
  for(const answers of [[{address:'127.0.0.1',family:4}],[{address:'8.8.8.8',family:4},{address:'169.254.169.254',family:4}],
    [{address:'::ffff:10.0.0.1',family:6}],[],[{address:'8.8.8.8',family:6}]]) {
    const mock=requestMock();const fetcher=createUpstreamFetch({lookup:async()=>answers,request:mock.request});
    await assert.rejects(fetcher(BASE+'/chat/completions',{method:'POST',redirect:'error',headers:{Authorization:'Bearer '+KEY}}));
    assert.equal(mock.calls.length,0);
  }
  const mock=requestMock(),controller=new AbortController();let release;
  const fetcher=createUpstreamFetch({lookup:()=>new Promise(resolve=>{release=resolve;}),request:mock.request});
  const pending=fetcher(BASE+'/chat/completions',{method:'POST',redirect:'error',headers:{Authorization:'Bearer '+KEY},signal:controller.signal});
  controller.abort();await assert.rejects(pending);release([{address:'8.8.8.8',family:4}]);
  await new Promise(resolve=>setImmediate(resolve));assert.equal(mock.calls.length,0);
});

test('custom transport does not follow redirects or accept unsolicited content compression',async()=>{
  for(const [status,headers] of [[302,{'location':'https://elsewhere.example','content-type':'text/event-stream'}],
    [307,{'location':'http://169.254.169.254'}],[200,{'content-type':'text/event-stream','content-encoding':'gzip'}]]) {
    const mock=requestMock(status,headers);const fetcher=createUpstreamFetch({lookup:async()=>[{address:'8.8.8.8',family:4}],request:mock.request});
    await assert.rejects(fetcher(BASE+'/chat/completions',{method:'POST',redirect:'error',body:'{}'}));
    assert.equal(mock.calls.length,1,'no redirect or automatic model retry');
  }
});

async function fixture(t, patch={}, upstream) {
  const stateDir=await fs.mkdtemp(path.join(os.tmpdir(),'ai-provider-'));
  const calls=[];
  const config={adminToken:TOKEN,apiKey:KEY,provider:'custom',apiBaseUrl:BASE,model:'team/model:next',publicEnabled:true,
    publicContinuous:true,dailyRequestLimit:500,publicPerIpDailyLimit:30,publicPerIpMinuteLimit:60,challengeAfterRequests:29,...patch};
  const server=createAiServer(config,{stateDir,knowledge:catalog,fetchImpl:async(url,init)=>{
    calls.push({url,init});return upstream?upstream(url,init):stream('完整的 **Markdown** 回答。');
  }});
  await listenForFetch(server);const base='http://127.0.0.1:'+server.address().port;
  t.after(async()=>{await server.shutdown();await fs.rm(stateDir,{recursive:true,force:true});});
  const post=(mode,body)=>fetch(base+'/api/public/'+mode,{method:'POST',headers:{Origin:SITE,'Content-Type':'application/json','X-Real-IP':'8.8.8.8'},body:JSON.stringify(body)});
  return {base,calls,post,stateDir};
}

test('ask, explanation, guide, chat, tour and controls use the configured endpoint and never send DeepSeek-specific fields',async t=>{
  const f=await fixture(t);
  for(const [mode,body] of [['ask',{question:'解释公开文章'}],['explain',{text:'一段代码',path:'/posts/42/'}],
    ['guide',{path:'/posts/42/'}],['chat',{question:'你好'}],['chat',{question:'找一些文章',tour:true}],['chat',{question:'播放音乐',control:true}]]) {
    const response=await f.post(mode,body);assert.equal(response.status,200);
    assert.match(await response.text(),/event: done/);
    const call=f.calls.at(-1),payload=JSON.parse(call.init.body);
    assert.equal(call.url,BASE+'/chat/completions');assert.equal(call.init.headers.Authorization,'Bearer '+KEY);
    assert.equal(payload.model,'team/model:next');assert.equal(payload.max_tokens,1024);assert.equal(payload.stream,true);
    assert.equal('thinking' in payload,false);assert.equal('response_format' in payload,false);assert.equal('tools' in payload,false);
  }
});

test('all seven workshops render compatible streamed JSON without requiring a vendor JSON-mode extension',async t=>{
  const value={title:'完整标题',summary:'摘要',cards:[{title:'章节',text:'故事正文',tag:'虚构',sourceIds:[],quotes:[]}],actions:[],memory:''};
  const f=await fixture(t,{},()=>stream(JSON.stringify(value)));
  for(const kind of ['story','phrasing','roundtable','clues','memoir','world','archaeology']) {
    const response=await f.post('workshop',{kind,input:'一个小故事',materials:kind==='archaeology'?[{id:'m1',title:'片段',date:'2026-10-01',text:'门开了'}]:[]});
    assert.equal(response.status,200);const result=await response.text();
    assert.match(result,/event: result/);assert.match(result,/完整标题/);assert.match(result,/event: done/);
    const payload=JSON.parse(f.calls.at(-1).init.body);assert.equal('response_format' in payload,false);
  }
});

test('compatibility fields are explicit and retain workshop JSON mode when a provider supports it',async t=>{
  const f=await fixture(t,{tokenParameter:'max_completion_tokens',jsonMode:'on'},()=>stream('{"title":"标题","summary":"完整输出","cards":[],"actions":[],"memory":""}'));
  const response=await f.post('workshop',{kind:'story',input:'故事'});assert.equal(response.status,200);await response.text();
  const payload=JSON.parse(f.calls[0].init.body);assert.equal(payload.max_completion_tokens,1024);assert.equal(payload.max_tokens,undefined);
  assert.deepEqual(payload.response_format,{type:'json_object'});
});

test('public status cannot disclose provider configuration and request bodies cannot override the target or key',async t=>{
  const f=await fixture(t);
  const status=await (await fetch(f.base+'/api/public/status')).text();
  assert.doesNotMatch(status,/api\.vendor|team\/model|provider-key|apiBaseUrl|tokenParameter/);
  const owner=await (await fetch(f.base+'/api/status',{headers:{Authorization:'Bearer '+TOKEN}})).json();
  assert.equal(owner.controls.provider,'custom');assert.equal(owner.controls.apiBaseUrl,BASE);assert.doesNotMatch(JSON.stringify(owner),new RegExp(KEY));
  for(const extra of [{provider:'deepseek'},{apiBaseUrl:'https://evil.example'},{apiKey:KEY},{model:'other'},{tokenParameter:'other'}]) {
    const result=await f.post('chat',{question:'你好',...extra});assert.equal(result.status,400);
  }
  assert.equal(f.calls.length,0);
});

test('provider rejections are not retried, do not leak bodies, and still consume the reserved quota',async t=>{
  const f=await fixture(t,{},()=>new Response('private '+KEY+' '+TOKEN,{status:401}));
  const response=await f.post('chat',{question:'你好'});assert.equal(response.status,503);
  assert.equal((await response.json()).error.code,'UPSTREAM_AUTH');assert.equal(f.calls.length,1);
  const ledger=JSON.parse(await fs.readFile(path.join(f.stateDir,'quota.json'),'utf8'));
  assert.equal(Object.values(ledger.days).reduce((a,b)=>a+b,0),1);
});
