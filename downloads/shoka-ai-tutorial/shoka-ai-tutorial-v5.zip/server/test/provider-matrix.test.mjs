// Official endpoint/profile fixtures checked on 2026-10-22. No live provider
// requests: passing means local configuration/protocol/guardrails, not account access.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createAiServer, validateConfig } from '../src/service.mjs';
import { listenForFetch } from './listen-test.mjs';

const SITE='https://blog.example.com', TOKEN='matrix-owner-token-0123456789-abcdef';
const CLOCK=Date.UTC(2026,9,22,4), DAY='2026-10-22';
const profiles=[
  {provider:'openai',apiBaseUrl:'https://api.openai.com/v1',model:'gpt-6-astra',tokenParameter:'max_completion_tokens'},
  {provider:'claude',apiBaseUrl:'https://api.anthropic.com/v1',model:'claude-opus-5-5',tokenParameter:'max_tokens'},
  {provider:'gemini',apiBaseUrl:'https://generativelanguage.googleapis.com/v1beta/openai',model:'gemini-3.8-flash',tokenParameter:'max_tokens'},
  {provider:'glm',apiBaseUrl:'https://open.bigmodel.cn/api/paas/v4',model:'glm-5.3',tokenParameter:'max_tokens'},
  {provider:'minimax',apiBaseUrl:'https://api.minimax.cn/v1',model:'MiniMax-M3.1-Flash',tokenParameter:'max_completion_tokens'},
  {provider:'kimi',apiBaseUrl:'https://api.moonshot.cn/v1',model:'kimi-k3',tokenParameter:'max_completion_tokens'},
  {provider:'deepseek',apiBaseUrl:'https://api.deepseek.com',model:'deepseek-flash',tokenParameter:'max_tokens'}
];
const key=profile=>'fake-matrix-key-'+profile.provider+'-0123456789';
const catalog={version:1,generatedAt:'2026-10-22T00:00:00Z',site:SITE,articles:[{
  id:'42',title:'公开文章',path:'/posts/42/',url:SITE+'/posts/42/',excerpt:'测试文章',text:'这是用于接口回归的公开文章，介绍音乐组件。',tags:[],categories:[]}]};
const frame=value=>'data: '+JSON.stringify(value)+'\n\n';
const delta=content=>frame({choices:[{index:0,delta:{content},finish_reason:null}]});
const finish=reason=>frame({choices:[{index:0,delta:{},finish_reason:reason}]})+'data: [DONE]\n\n';
function stream(profile,text='回答正文',reason='stop') {
  let prefix=frame({id:'fake-completion',object:'chat.completion.chunk',model:profile.model,choices:[{index:0,delta:{role:'assistant',content:''},finish_reason:null}]});
  if(['glm','minimax','kimi'].includes(profile.provider)) prefix+=frame({choices:[{index:0,delta:{reasoning_content:'测试思考不应进入回答',content:null}}]});
  return new Response(prefix+delta(text.slice(0,2))+delta(text.slice(2))+frame({choices:[],usage:{completion_tokens:10}})+finish(reason),{headers:{'Content-Type':'text/event-stream; charset=utf-8'}});
}
function isWorkshop(payload) {
  try {return Boolean(JSON.parse(payload.messages.at(-1).content.replace(/^DATA_JSON\n/, '')).kind);}catch{return false;}
}
const workshop=JSON.stringify({title:'工坊标题',summary:'概要',cards:[{title:'正文',text:'完整内容',tag:'虚构',sourceIds:[],quotes:[]}],actions:[],memory:''});
const deltaText=sse=>sse.split('\n\n').filter(part=>part.startsWith('event: delta\n'))
  .map(part=>JSON.parse(part.split('\n')[1].slice(6)).text).join('');
async function fixture(t,profile,patch={},dependencies={}) {
  const stateDir=await fs.mkdtemp(path.join(os.tmpdir(),'provider-matrix-'));
  let clock=CLOCK,server,base;
  let config={adminToken:TOKEN,apiKey:key(profile),...profile,jsonMode:'auto',publicEnabled:true,publicContinuous:true,
    publicPerIpMinuteLimit:60,challengeAfterRequests:29,dailyRequestLimit:500,publicPerIpDailyLimit:30,
    maxOutputTokens:2048,...patch};
  const calls=[],alerts=[];
  async function restart(changes={}) {
    if(server)await server.shutdown();
    config={...config,...changes};
    server=createAiServer(config,{stateDir,now:()=>clock,knowledge:catalog,alertSink:event=>alerts.push(event),
      fetchImpl:async(url,init)=>{
        const payload=JSON.parse(init.body);calls.push({url,init,payload});
        return dependencies.fetchImpl ? dependencies.fetchImpl(url,init,payload) : stream(config,isWorkshop(payload)?workshop:'回答正文');
      }});
    await listenForFetch(server);base='http://127.0.0.1:'+server.address().port;
  }
  await restart();
  t.after(async()=>{if(server)await server.shutdown();await fs.rm(stateDir,{recursive:true,force:true});});
  return {calls,alerts,stateDir,restart,advance:ms=>{clock+=ms;},
    post:(body={question:'你好'},ip='8.8.8.8',mode='chat',options={})=>fetch(base+'/api/public/'+mode,{
      method:'POST',headers:{Origin:SITE,'X-Real-IP':ip,'Content-Type':'application/json'},body:JSON.stringify(body),...options}),
    status:async()=> (await fetch(base+'/api/public/status')).json(),
    ledger:async()=>JSON.parse(await fs.readFile(path.join(stateDir,'quota.json'),'utf8'))};
}
async function error(response,status,code) {
  assert.equal(response.status,status);assert.equal((await response.json()).error.code,code);
}

for(const p of profiles) {
  test(p.provider+': official base, complete endpoint, selected model/key and token field configure and stream locally',async t=>{
    const f=await fixture(t,p);
    const full=validateConfig({adminToken:TOKEN,apiKey:key(p),...p,apiBaseUrl:p.apiBaseUrl+'/chat/completions'});
    assert.equal(full.apiBaseUrl,p.apiBaseUrl);
    for(const [mode,body] of [['chat',{question:'你好'}],['guide',{path:'/posts/42/'}],['explain',{text:'一段文字'}],['workshop',{kind:'story',input:'一段故事'}]]) {
      const response=await f.post(body,'8.8.8.8',mode);assert.equal(response.status,200);
      const text=await response.text();assert.match(text,/event: done/);assert.doesNotMatch(text,/event: error|测试思考不应进入回答/);
      if(mode==='workshop')assert.match(text,/event: result/);else assert.equal(deltaText(text),'回答正文');
      const call=f.calls.at(-1);
      assert.equal(call.url,p.apiBaseUrl+'/chat/completions');assert.equal(call.init.headers.Authorization,'Bearer '+key(p));
      assert.equal(call.payload.model,p.model);assert.equal(call.payload[p.tokenParameter],2048);
      assert.equal(call.payload[p.tokenParameter==='max_tokens'?'max_completion_tokens':'max_tokens'],undefined);
      assert.equal(call.init.redirect,'error');assert.equal(call.payload.stream,true);
      assert.equal(call.payload.tools,undefined);assert.equal(call.payload.tool_choice,undefined);
      if(p.provider!=='deepseek'){assert.equal(call.payload.thinking,undefined);assert.equal(call.payload.response_format,undefined);}
    }
    const status=await f.status();assert.equal(status.limits.maxOutputTokens,2048);
    assert.doesNotMatch(JSON.stringify(status),/apiBaseUrl|fake-matrix-key|adminToken/);
  });

  test(p.provider+': disabled and empty-key settings block every model before quota/network',async t=>{
    const f=await fixture(t,p,{publicEnabled:false});await error(await f.post(),503,'PUBLIC_DISABLED');
    await f.restart({publicEnabled:true,apiKey:''});await error(await f.post(),503,'AI_NOT_CONFIGURED');
    assert.equal(f.calls.length,0);await assert.rejects(fs.stat(path.join(f.stateDir,'quota.json')),{code:'ENOENT'});
  });

  test(p.provider+': global daily and per-IP daily quotas stay enforced with exact persisted counts',async t=>{
    const f=await fixture(t,p,{dailyRequestLimit:2,publicPerIpDailyLimit:1});
    assert.match(await (await f.post()).text(),/event: done/);
    await error(await f.post(),429,'IP_DAILY_LIMIT');
    assert.match(await (await f.post(undefined,'1.1.1.1')).text(),/event: done/);
    await error(await f.post(undefined,'9.9.9.9'),429,'DAILY_LIMIT');
    assert.equal(f.calls.length,2);assert.equal((await f.ledger()).days[DAY],2);
    assert.deepEqual(Object.values((await f.ledger()).publicIps[DAY]),[1,1]);
    assert.ok(f.alerts.some(x=>x.threshold===100));
  });

  test(p.provider+': global minute/hour admission spans IPs without spending denied attempts',async t=>{
    const f=await fixture(t,p,{publicGlobalMinuteLimit:1,publicGlobalHourLimit:2});
    await (await f.post()).text();
    await error(await f.post(undefined,'1.1.1.1'),429,'GLOBAL_RATE_LIMIT');
    f.advance(60001);await (await f.post(undefined,'1.1.1.1')).text();
    f.advance(60001);await error(await f.post(undefined,'9.9.9.9'),429,'GLOBAL_RATE_LIMIT');
    assert.equal(f.calls.length,2);assert.equal((await f.ledger()).days[DAY],2);
  });

  test(p.provider+': minute/IP caps and invalid-request cooling isolate the abusive IP',async t=>{
    const f=await fixture(t,p,{publicPerIpMinuteLimit:4,challengeAfterRequests:2});
    await (await f.post()).text();
    for(let i=0;i<3;i++)await error(await f.post(),429,'ABUSE_COOLDOWN');
    await error(await f.post(),429,'IP_RATE_LIMIT');
    assert.match(await (await f.post(undefined,'1.1.1.1')).text(),/event: done/);assert.equal(f.calls.length,2);
    f.advance(60001);assert.match(await (await f.post()).text(),/event: done/);
  });

  test(p.provider+': per-IP concurrency and owner concurrency apply before additional upstream calls',async t=>{
    let entered,release;const started=new Promise(r=>{entered=r;}),held=new Promise(r=>{release=r;});
    const f=await fixture(t,p,{maxConcurrent:1},{fetchImpl:async()=>{entered();await held;return stream(p);}});
    const first=f.post();await started;
    try {await error(await f.post(),429,'IP_CONCURRENT_LIMIT');await error(await f.post(undefined,'1.1.1.1'),429,'CONCURRENT_LIMIT');}
    finally {release();await (await first).text();}
    assert.equal(f.calls.length,1);assert.equal((await f.ledger()).days[DAY],1);
  });

  test(p.provider+': input and request-supplied provider/model overrides are rejected before any upstream call',async t=>{
    const f=await fixture(t,p,{maxInputChars:32});
    for(const body of [{question:'x'.repeat(33)},{question:'hello',provider:'other'},{question:'hello',model:'different'},
      {question:'hello',apiKey:'attack'},{question:'hello',apiBaseUrl:'https://elsewhere.example'}])await error(await f.post(body),400,'INVALID_FIELDS');
    assert.equal(f.calls.length,0);
  });

  test(p.provider+': timeout aborts a stalled model, counts the attempt and never calls another provider',async t=>{
    let signal;const f=await fixture(t,p,{requestTimeoutMs:1000},{fetchImpl:async(_url,init)=>{signal=init.signal;return new Promise(()=>{});}});
    await error(await f.post(),504,'UPSTREAM_TIMEOUT');
    assert.equal(signal.aborted,true);assert.equal(f.calls.length,1);assert.equal((await f.ledger()).days[DAY],1);
  });

  test(p.provider+': output envelopes still stop a provider that ignores the requested token maximum',async t=>{
    const f=await fixture(t,p,{maxOutputTokens:1},{fetchImpl:async()=>new Response(
      Array.from({length:140},()=>delta('x'.repeat(512))).join('')+finish('stop'),{headers:{'Content-Type':'text/event-stream'}})});
    const text=await (await f.post()).text();assert.match(text,/event: error[\s\S]*OUTPUT_LIMIT/);assert.doesNotMatch(text,/event: done/);
    assert.equal(f.calls.length,1);
  });

  test(p.provider+': upstream rejection is sanitized and cannot trigger retries or fallback to old models',async t=>{
    const f=await fixture(t,p,{}, {fetchImpl:async()=>new Response(key(p)+' private-vendor-message',{status:400})});
    const response=await f.post();await error(response,502,'UPSTREAM_PARAMETERS');assert.equal(f.calls.length,1);
    assert.equal(f.calls[0].url,p.apiBaseUrl+'/chat/completions');assert.equal((await f.ledger()).days[DAY],1);
  });

  test(p.provider+': invalid runtime limits fail identically before the service starts',()=>{
    for(const patch of [{dailyRequestLimit:0},{publicPerIpDailyLimit:0},{maxOutputTokens:1048577},{requestTimeoutMs:2147483001},
      {maxConcurrent:0},{maxInputChars:1048577},{publicPerIpMinuteLimit:0},{challengeAfterRequests:0},
      {publicGlobalMinuteLimit:0},{publicGlobalHourLimit:0}])assert.throws(()=>validateConfig({adminToken:TOKEN,...p,...patch}),/INVALID_CONFIG/);
  });
}

test('switch through every provider/model: only the active pair receives requests and the same daily ledger survives restarts',async t=>{
  const f=await fixture(t,profiles[0]);
  for(let index=0;index<profiles.length;index++) {
    const p=profiles[index];await f.restart({...p,apiKey:key(p)});
    assert.match(await (await f.post()).text(),/event: done/);
    assert.equal(f.calls.length,index+1);assert.equal(f.calls.at(-1).url,p.apiBaseUrl+'/chat/completions');
    assert.equal(f.calls.at(-1).payload.model,p.model);assert.equal(f.calls.at(-1).init.headers.Authorization,'Bearer '+key(p));
    const ledger=await f.ledger();assert.equal(ledger.days[DAY],index+1);
    assert.deepEqual(Object.values(ledger.publicIps[DAY]),[index+1]);
  }
  await f.restart({...profiles[0],apiKey:key(profiles[0]),publicPerIpDailyLimit:profiles.length});
  await error(await f.post(),429,'IP_DAILY_LIMIT');assert.equal(f.calls.length,profiles.length);
});

test('switching shuts down an in-flight old model before the new service accepts work',async t=>{
  let entered,oldSignal,attempts=0;const started=new Promise(r=>{entered=r;});
  const f=await fixture(t,profiles[0],{}, {fetchImpl:async(_url,init)=>{
    if(attempts++===0){oldSignal=init.signal;entered();return new Promise(()=>{});}return stream(profiles[1]);
  }});
  const old=f.post().then(async r=>r.text()).catch(()=> 'closed');await started;
  await f.restart({...profiles[1],apiKey:key(profiles[1])});
  assert.equal(oldSignal.aborted,true);await old;
  assert.match(await (await f.post()).text(),/event: done/);assert.equal(f.calls.length,2);
  assert.equal(f.calls.at(-1).url,profiles[1].apiBaseUrl+'/chat/completions');assert.equal((await f.ledger()).days[DAY],2);
});

test('audit boundary: completion token caps are forwarded, not locally counted as provider tokens',async t=>{
  const f=await fixture(t,profiles[0],{maxOutputTokens:1});
  const text=await (await f.post()).text();assert.equal(deltaText(text),'回答正文');
  assert.equal(f.calls[0].payload.max_completion_tokens,1);
  // The site enforces a byte/character safety envelope, not vendor tokenization.
  assert.equal((await f.status()).transport.maxAnswerChars,65536);
});

test('chat history shares the owner-selected user input budget',async t=>{
  const f=await fixture(t,profiles[0],{maxInputChars:32});
  const response=await f.post({question:'你好',history:[{role:'user',content:'旧问题'.repeat(20)},{role:'assistant',content:'旧回答'.repeat(20)}]});
  await error(response,400,'INVALID_FIELDS');assert.equal(f.calls.length,0);
});

test('short-term windows survive provider changes and restarts alongside daily usage',async t=>{
  const f=await fixture(t,profiles[0],{publicGlobalMinuteLimit:1});await (await f.post()).text();
  await error(await f.post(undefined,'1.1.1.1'),429,'GLOBAL_RATE_LIMIT');
  await f.restart({...profiles[1],apiKey:key(profiles[1])});
  await error(await f.post(undefined,'1.1.1.1'),429,'GLOBAL_RATE_LIMIT');
  assert.equal((await f.ledger()).days[DAY],1);
  f.advance(60001);assert.match(await (await f.post(undefined,'1.1.1.1')).text(),/event: done/);
});

test('legacy MiniMax inline thinking is removed even across SSE frames',async t=>{
  const p={...profiles[4],model:'MiniMax-M2.7'};
  const f=await fixture(t,p,{}, {fetchImpl:async()=>stream(p,'<think>需要额外适配的思考文字</think>回答正文')});
  const text=await (await f.post()).text();assert.equal(deltaText(text),'回答正文');
  assert.doesNotMatch(text,/需要额外适配的思考文字|<think>/);
});

test('Claude account keys can use a validated owner-only workspace header',async t=>{
  const f=await fixture(t,profiles[1],{anthropicWorkspaceId:'workspace-example'});await (await f.post()).text();
  assert.equal(f.calls[0].init.headers['anthropic-workspace-id'],'workspace-example');
  assert.doesNotMatch(JSON.stringify(await f.status()),/workspace-example/);
  assert.throws(()=>validateConfig({adminToken:TOKEN,...profiles[1],anthropicWorkspaceId:'x\r\nHeader:y'}),/INVALID_CONFIG/);
});
