// Synthetic provider streams; no API keys, DNS or paid model requests.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createAiServer, validateConfig } from '../src/service.mjs';
import { upstreamRequest, createUpstreamFetch } from '../src/upstream.mjs';
import { createProtocolDecoder, createThinkingFilter } from '../src/protocols.mjs';
import { createAbuseGuard } from '../src/abuse.mjs';
import { WORKSHOP_KINDS } from '../src/workshop.mjs';
import { listenForFetch } from './listen-test.mjs';

const TOKEN='native-tests-owner-0123456789-abcdef', KEY='test-native-key-0123456789';
const SITE='https://blog.example.com', CLOCK=Date.UTC(2026,9,22,6);
const catalog={version:1,generatedAt:'2026-10-22T00:00:00Z',site:SITE,articles:[{
  id:'42',title:'公开文章',path:'/posts/42/',url:SITE+'/posts/42/',excerpt:'文章概要',text:'用于阅读导读的公开内容。',tags:[],categories:[]}]};
const frame=v=>'data: '+JSON.stringify(v)+'\n\n';
function wire(protocol,text='完整回答',reason='stop') {
  if(protocol==='responses')return frame({type:'response.output_item.added',item:{type:'message'}})
    +frame({type:'response.output_text.delta',delta:text})
    +frame(reason==='stop'?{type:'response.completed',response:{status:'completed'}}
      :{type:'response.incomplete',response:{status:'incomplete',incomplete_details:{reason:'max_output_tokens'}}});
  if(protocol==='anthropic')return frame({type:'message_start',message:{role:'assistant'}})
    +frame({type:'content_block_start',index:0,content_block:{type:'thinking',thinking:''}})
    +frame({type:'content_block_delta',index:0,delta:{type:'thinking_delta',thinking:'不可公开的思考'}})
    +frame({type:'content_block_start',index:1,content_block:{type:'text',text:''}})
    +frame({type:'content_block_delta',index:1,delta:{type:'text_delta',text}})
    +frame({type:'message_delta',delta:{stop_reason:reason==='stop'?'end_turn':'max_tokens'}})+frame({type:'message_stop'});
  if(protocol==='gemini')return frame({candidates:[{index:0,content:{parts:[{thought:true,text:'不可公开的思考'},{text}]}}]})
    +frame({candidates:[{index:0,finishReason:reason==='stop'?'STOP':'MAX_TOKENS'}]});
  return frame({choices:[{index:0,delta:{content:text}}]})+frame({choices:[{delta:{},finish_reason:reason}]})+'data: [DONE]\n\n';
}
const reply=(protocol,text,reason)=>new Response(wire(protocol,text,reason),{headers:{'Content-Type':'text/event-stream'}});
const visible=text=>text.split('\n\n').filter(s=>s.startsWith('event: delta\n')).map(s=>JSON.parse(s.split('\n')[1].slice(6)).text).join('');
async function fixture(t,protocol,patch={},mock) {
  const stateDir=await fs.mkdtemp(path.join(os.tmpdir(),'native-protocol-'));const calls=[];
  const config={adminToken:TOKEN,apiKey:KEY,provider:'custom',apiBaseUrl:'https://api.vendor.example/v1',model:'model-future',apiProtocol:protocol,
    publicEnabled:true,publicContinuous:true,publicPerIpDailyLimit:30,publicPerIpMinuteLimit:60,challengeAfterRequests:29,maxOutputTokens:4096,...patch};
  const server=createAiServer(config,{stateDir,knowledge:catalog,fetchImpl:async(url,init)=>{
    const payload=JSON.parse(init.body);calls.push({url,init,payload});return mock?mock(url,init,payload):reply(protocol,'完整回答');
  }});await listenForFetch(server);
  t.after(async()=>{await server.shutdown();await fs.rm(stateDir,{recursive:true,force:true});});
  const base='http://127.0.0.1:'+server.address().port;
  return {calls,stateDir,post:(body={question:'你好'},mode='chat',ip='8.8.8.8')=>fetch(base+'/api/public/'+mode,{method:'POST',
    headers:{Origin:SITE,'X-Real-IP':ip,'Content-Type':'application/json'},body:JSON.stringify(body)}),
    status:()=>fetch(base+'/api/public/status').then(r=>r.json())};
}

for(const protocol of ['chat-completions','responses','anthropic','gemini']) {
  test(protocol+': shared ask/chat/selection/guide/tour/control routes use exactly one configured model',async t=>{
    const f=await fixture(t,protocol);
    for(const [mode,body] of [['ask',{question:'博客'}],['chat',{question:'你好'}],['explain',{text:'一段文字'}],
      ['guide',{path:'/posts/42/'}],['chat',{question:'音乐',tour:true}],['chat',{question:'切换夜间',control:true}]]) {
      const response=await f.post(body,mode);assert.equal(response.status,200);
      const text=await response.text();assert.match(text,/event: done/);assert.doesNotMatch(text,/不可公开的思考/);
      assert.equal(visible(text),'完整回答');
    }
    assert.equal(f.calls.length,6);
    for(const {url,init,payload} of f.calls) {
      assert.equal(init.redirect,'error');assert.equal(init.signal.aborted,false);
      if(protocol!=='gemini')assert.equal(payload.model,'model-future');
      assert.doesNotMatch(url,/key=|token=/);
      if(protocol==='anthropic') {assert.equal(init.headers['x-api-key'],KEY);assert.equal(init.headers.Authorization,undefined);assert.equal(payload.max_tokens,4096);}
      else if(protocol==='gemini') {assert.equal(init.headers['x-goog-api-key'],KEY);assert.equal(init.headers.Authorization,undefined);assert.equal(payload.generationConfig.maxOutputTokens,4096);assert.ok(url.endsWith(':streamGenerateContent?alt=sse'));}
      else {assert.equal(init.headers.Authorization,'Bearer '+KEY);assert.equal(payload[protocol==='responses'?'max_output_tokens':'max_tokens'],4096);}
      if(protocol==='responses')assert.equal(payload.store,false);
    }
    assert.doesNotMatch(JSON.stringify(await f.status()),/apiProtocol|apiBaseUrl|test-native-key|api.vendor/);
  });
  test(protocol+': all seven workshops retain card rendering and JSON mode is optional',async t=>{
    const result={title:'标题',summary:'概要',cards:[{title:'卡片',text:'内容',tag:'虚构',sourceIds:[],quotes:[]}],actions:[],memory:''};
    const f=await fixture(t,protocol,{},async()=>reply(protocol,JSON.stringify(result)));
    for(const kind of WORKSHOP_KINDS) {
      const text=await (await f.post({kind,input:'一段文字'},'workshop')).text();
      assert.match(text,/event: result/);assert.match(text,/event: done/);assert.doesNotMatch(text,/event: error/);
    }
    assert.equal(f.calls.length,7);
  });
  test(protocol+': truncation is reported and private upstream errors are never relayed or retried',async t=>{
    const f=await fixture(t,protocol,{},async()=>reply(protocol,'未完回答','length'));
    const text=await (await f.post()).text();assert.equal(visible(text),'未完回答');assert.match(text,/"truncated":true/);
    const bad=await fixture(t,protocol,{},async()=>new Response(KEY,{status:401}));
    const rejected=await bad.post();assert.equal(rejected.status,503);assert.equal((await rejected.json()).error.code,'UPSTREAM_AUTH');
    assert.equal(bad.calls.length,1);
  });
  test(protocol+': disabled state, invalid input and malicious client target overrides never call a model',async t=>{
    const f=await fixture(t,protocol,{maxInputChars:32});
    for(const body of [{question:'x'.repeat(33)},{question:'好',apiProtocol:'responses'},{question:'好',anthropicWorkspaceId:'evil'},
      {question:'好',history:[{role:'user',content:'x'.repeat(32)},{role:'assistant',content:'old'}]},
      {question:'好',continueFrom:'x'.repeat(32)}])assert.equal((await f.post(body)).status,400);
    assert.equal(f.calls.length,0);
    const off=await fixture(t,protocol,{publicEnabled:false});assert.equal((await off.post()).status,503);assert.equal(off.calls.length,0);
  });
  test(protocol+': daily, per-IP and shared short admission limits apply before an extra upstream call',async t=>{
    const f=await fixture(t,protocol,{dailyRequestLimit:2,publicPerIpDailyLimit:1});
    assert.match(await (await f.post()).text(),/event: done/);
    assert.equal((await (await f.post()).json()).error.code,'IP_DAILY_LIMIT');
    assert.match(await (await f.post(undefined,'chat','1.1.1.1')).text(),/event: done/);
    assert.equal((await (await f.post(undefined,'chat','9.9.9.9')).json()).error.code,'DAILY_LIMIT');
    assert.equal(f.calls.length,2);
    const limited=await fixture(t,protocol,{publicGlobalMinuteLimit:1});await (await limited.post()).text();
    assert.equal((await (await limited.post(undefined,'chat','1.1.1.1')).json()).error.code,'GLOBAL_RATE_LIMIT');
    assert.equal(limited.calls.length,1);
  });
  test(protocol+': configured timeout aborts once; excessive visible output is bounded for every decoder',async t=>{
    let signal;
    const stalled=await fixture(t,protocol,{requestTimeoutMs:1000},async(_url,init)=>{signal=init.signal;return new Promise(()=>{});});
    assert.equal((await (await stalled.post()).json()).error.code,'UPSTREAM_TIMEOUT');
    assert.equal(signal.aborted,true);assert.equal(stalled.calls.length,1);
    const huge=await fixture(t,protocol,{maxOutputTokens:1},async()=>reply(protocol,'x'.repeat(70000)));
    // A single oversized SSE frame is independently bounded even when an API
    // ignores the requested token cap. No successful completion is reported.
    const text=await (await huge.post()).text();assert.match(text,/event: error/);assert.doesNotMatch(text,/event: done/);
  });
}

test('all protocol destinations pass the same DNS/private IP/redirect boundary before sending keys',async()=>{
  let requests=0,lookups=0;
  const send=createUpstreamFetch({lookup:async()=>{lookups++;return [{address:'127.0.0.1',family:4}];},request:()=>{requests++;}});
  for(const apiProtocol of ['chat-completions','responses','anthropic','gemini']) {
    const c=validateConfig({adminToken:TOKEN,provider:'custom',apiBaseUrl:'https://api.vendor.example/v1',model:'model',apiProtocol});
    const r=upstreamRequest(c,[],false);
    await assert.rejects(send(r.endpoint,{method:'POST',redirect:'error',headers:r.headers}),/PRIVATE_ADDRESS/);
  }
  for(const suffix of ['/responses?key=secret','/messages#x','/models/model:streamGenerateContent?alt=sse&key=secret','/files'])
    await assert.rejects(send('https://api.vendor.example/v1'+suffix,{method:'POST',redirect:'error'}),/DESTINATION/);
  assert.equal(lookups,4);assert.equal(requests,0);
});

test('protocol decoding rejects tool execution, malformed text and false completion events',()=>{
  for(const [protocol,chunk] of [
    ['responses',{type:'response.output_item.added',item:{type:'function_call'}}],
    ['responses',{type:'response.completed',response:{status:'failed'}}],
    ['responses',{type:'response.incomplete',response:{incomplete_details:{reason:'content_filter'}}}],
    ['anthropic',{type:'content_block_start',index:0,content_block:{type:'tool_use'}}],
    ['anthropic',{type:'content_block_delta',index:0,delta:{type:'text_delta',text:'unbound'}}],
    ['anthropic',{type:'message_stop'}],
    ['gemini',{candidates:[{content:{parts:[{functionCall:{name:'run'}}]}}]}],
    ['gemini',{candidates:[{finishReason:'SAFETY'}]}],
    ['chat-completions',{choices:[{delta:{content:['bad']}}]}]
  ])assert.throws(()=>createProtocolDecoder(protocol)(chunk));
});

test('thinking filter survives every split point, hides unclosed reasoning and preserves literal code tags',()=>{
  const text='  <think>secret</think>\n<analysis>more secret</analysis>正文';
  for(let index=0;index<=text.length;index++) {
    const filter=createThinkingFilter();const result=filter(text.slice(0,index))+filter(text.slice(index))+filter('',true);
    assert.equal(result,'正文');
  }
  for(const text of ['<think>never close','<thi','<analysis>long hidden '+ 'x'.repeat(100000)]) {
    const filter=createThinkingFilter();assert.equal(filter(text)+filter('',true),'');
  }
  const filter=createThinkingFilter();assert.equal(filter('```html\n<think>literal</think>\n```'),'```html\n<think>literal</think>\n```');
  assert.equal(createThinkingFilter(false)('<think>explicitly opted out</think>'),'<think>explicitly opted out</think>');
});

test('durable short windows retain per-IP cooling, global hour and CAPTCHA replay proofs across reload',async t=>{
  const stateDir=await fs.mkdtemp(path.join(os.tmpdir(),'durable-abuse-'));
  t.after(()=>fs.rm(stateDir,{recursive:true,force:true}));let clock=CLOCK;
  const config=validateConfig({adminToken:TOKEN,publicPerIpMinuteLimit:12,challengeAfterRequests:6,publicGlobalHourLimit:1});
  const create=()=>createAbuseGuard(config,{now:()=>clock,stateDir});
  let guard=create(),client=guard.enter('8.8.8.8');
  client.failure();client.failure();client.failure();
  const body={question:'hello'},challenge=guard.challenge(client,'chat',body),proof={challenge,ticket:'test-ticket-12345',randstr:'test'};
  guard.consume(client,'chat',body,proof);guard.reserveGlobal();client.release();
  guard=create();client=guard.enter('8.8.8.8');assert.equal(client.suspicious(),true);assert.equal(client.cooldownSeconds(),600);
  assert.throws(()=>guard.consume(client,'chat',body,proof),/CAPTCHA_INVALID/);assert.throws(()=>guard.reserveGlobal(),/GLOBAL_RATE_LIMIT/);client.release();
  const text=await fs.readFile(path.join(stateDir,'abuse.json'),'utf8');assert.doesNotMatch(text,/8\.8\.8\.8|test-ticket|hello|test-native-key/);
  clock+=3600001;guard=create();client=guard.enter('8.8.8.8');assert.equal(client.suspicious(),false);guard.reserveGlobal();client.release();
});

test('corrupt or removed persisted state fails closed rather than clearing limits',async t=>{
  const stateDir=await fs.mkdtemp(path.join(os.tmpdir(),'corrupt-abuse-'));
  t.after(()=>fs.rm(stateDir,{recursive:true,force:true}));
  const config=validateConfig({adminToken:TOKEN}),make=()=>createAbuseGuard(config,{now:()=>CLOCK,stateDir});
  const guard=make();guard.enter('8.8.8.8').release();
  await fs.unlink(path.join(stateDir,'abuse.json'));assert.throws(()=>guard.enter('8.8.8.8'),/STATE_UNAVAILABLE/);
  await fs.writeFile(path.join(stateDir,'abuse.json'),'{broken');assert.throws(()=>make().enter('8.8.8.8'),/STATE_UNAVAILABLE/);
  await fs.writeFile(path.join(stateDir,'abuse.json'),JSON.stringify({version:1,clients:[],consumed:[],global:[CLOCK+1]}));
  assert.throws(()=>make().enter('8.8.8.8'),/STATE_UNAVAILABLE/);
});

test('a thinking-only answer is not reported as an empty successful completion',async t=>{
  const f=await fixture(t,'chat-completions',{},async()=>reply('chat-completions','<think>only hidden reasoning</think>'));
  const text=await (await f.post()).text();assert.match(text,/UPSTREAM_EMPTY/);assert.doesNotMatch(text,/hidden reasoning|event: done/);
});
