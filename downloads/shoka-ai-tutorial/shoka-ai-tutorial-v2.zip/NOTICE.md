# 上游说明

本包是 AI 教程的通用示例，不包含整个 Shoka 主题。主题相关样式与结构参考 MIT 许可的 amehime/hexo-theme-shoka；使用这些部分时保留本包中的上游许可。

Markdown 分词依赖 markdown-it，构建依赖 esbuild、cheerio 等。它们通过 npm 安装，不在本源码包中捆绑；请保留各依赖自身的许可。SearXNG 不在本包中，通过其官方镜像另行部署并遵守其许可。

原主题：https://github.com/amehime/hexo-theme-shoka
Markdown：https://github.com/markdown-it/markdown-it
SearXNG：https://github.com/searxng/searxng
