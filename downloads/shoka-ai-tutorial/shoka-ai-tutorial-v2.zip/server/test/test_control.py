"""Isolated tests of the Chinese local control UI; all admin subprocesses are mocked."""
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch

SPEC = importlib.util.spec_from_file_location('ai_control', Path(__file__).parents[1] / 'bin' / 'ai-control.py')
CONTROL = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CONTROL)

STATUS = {
    'configured': True, 'paidEnabled': False, 'knowledgeReady': True,
    'public': {'enabled': True, 'available': True, 'continuous': True, 'expiresAt': None,
               'knowledgeReady': True, 'features': {'ask': True, 'explain': True, 'guide': True},
               'limits': {'daily': 500, 'perIpDaily': 30, 'maxOutputTokens': 768}},
}
SECRET = 'fake-sensitive-value-must-never-be-rendered'


class ControlTests(unittest.TestCase):
    def rejected(self, function, *args):
        with patch('sys.stdout', new_callable=io.StringIO) as stdout, \
                patch('sys.stderr', new_callable=io.StringIO) as stderr:
            try:
                value = function(*args)
            except (Exception, SystemExit) as error:
                self.assertNotIn(SECRET, str(error))
            else:
                self.assertIn(value, [False, None, 1, 2], 'Rejected input must not yield a success value')
            self.assertNotIn(SECRET, stdout.getvalue() + stderr.getvalue())

    def test_run_admin_uses_fixed_sibling_script_no_shell_and_captures_output(self):
        completed = subprocess.CompletedProcess([], 0, stdout=json.dumps(STATUS), stderr=SECRET)
        with patch.object(CONTROL.subprocess, 'run', return_value=completed) as run, \
                patch('sys.stdout', new_callable=io.StringIO) as stdout, \
                patch('sys.stderr', new_callable=io.StringIO) as stderr:
            result = CONTROL.run_admin('status')
        self.assertEqual(result, STATUS)
        run.assert_called_once()
        args, kwargs = run.call_args.args[0], run.call_args.kwargs
        self.assertIsInstance(args, list)
        self.assertEqual(args[:2], ['/usr/bin/python3', '-I'])
        targets = [index for index, value in enumerate(args) if Path(value).name == 'ai-admin.py']
        self.assertEqual(len(targets), 1)
        index = targets[0]
        self.assertEqual(Path(args[index]).resolve(), (Path(CONTROL.__file__).parent / 'ai-admin.py').resolve())
        self.assertEqual(args[2:index], ['-X', 'utf8'])
        self.assertEqual(args[index + 1:], ['status'])
        self.assertFalse(kwargs.get('shell', False))
        self.assertTrue(kwargs.get('capture_output') or
                        (kwargs.get('stdout') == subprocess.PIPE and kwargs.get('stderr') == subprocess.PIPE))
        self.assertEqual(kwargs.get('stdin'), subprocess.DEVNULL)
        self.assertGreater(kwargs.get('timeout', 0), 0)
        self.assertLessEqual(kwargs['timeout'], 120)
        self.assertNotIn(SECRET, stdout.getvalue() + stderr.getvalue())

    def test_run_admin_rejects_unexposed_actions_before_spawning(self):
        with patch.object(CONTROL.subprocess, 'run') as run:
            for args in [(), ('paid-smoke',), ('set-key',), ('init',), ('sync-knowledge', 'https://evil.example/'),
                         ('status; echo injected',), ('../ai-admin.py',), ('status', 'extra')]:
                with self.subTest(args=args):
                    self.rejected(CONTROL.run_admin, *args)
            run.assert_not_called()

    def test_sync_only_accepts_fixed_action_and_whitelisted_success_messages(self):
        messages = {
            'Public knowledge unchanged; no reload needed; configuration and quotas preserved.': 'unchanged',
            'Public knowledge updated and reloaded; configuration and quotas preserved.': 'updated',
        }
        for message, state in messages.items():
            with self.subTest(state=state), patch.object(CONTROL.subprocess, 'run', return_value=
                    subprocess.CompletedProcess([], 0, stdout=message + '\n', stderr=SECRET)) as run:
                self.assertEqual(CONTROL.run_admin('sync-knowledge'), state)
                self.assertEqual(run.call_args.args[0][-1], 'sync-knowledge')
                self.assertEqual(run.call_args.kwargs['timeout'], 600)
                self.assertFalse(run.call_args.kwargs['shell'])
        for code, message in [(0, SECRET), (1, SECRET)]:
            with patch.object(CONTROL.subprocess, 'run', return_value=
                    subprocess.CompletedProcess([], code, stdout=message, stderr=SECRET)):
                self.rejected(CONTROL.run_admin, 'sync-knowledge')

    def test_sync_cli_never_prompts_or_modifies_settings(self):
        for state in ['updated', 'unchanged']:
            with self.subTest(state=state), patch.object(CONTROL.os, 'geteuid', return_value=0, create=True), \
                    patch.object(CONTROL, 'run_admin', return_value=state) as run, \
                    patch('builtins.input', side_effect=AssertionError('CLI must not prompt')), \
                    patch('sys.stdout', new_callable=io.StringIO) as stdout:
                self.assertEqual(CONTROL.main(['sync']), 0)
                run.assert_called_once_with('sync-knowledge')
                self.assertIn('没有调用模型', stdout.getvalue())
                self.assertIn('90 秒', stdout.getvalue())
                self.assertIn('跳过重载' if state == 'unchanged' else '已更新', stdout.getvalue())
        with patch.object(CONTROL.os, 'geteuid', return_value=0, create=True), patch.object(CONTROL, 'run_admin') as run:
            for args in [['sync', 'extra'], ['sync', 'https://evil.example/'], ['sync;status']]:
                self.rejected(CONTROL.main, args)
            run.assert_not_called()

    def test_menu_sync_needs_confirmation(self):
        for answer in ['y', '', 'n', EOFError()]:
            with self.subTest(answer=type(answer).__name__), patch.object(CONTROL.sys.stdin, 'isatty', return_value=True), \
                    patch.object(CONTROL, 'get_status', return_value=STATUS), \
                    patch.object(CONTROL, 'sync_knowledge') as sync, \
                    patch('builtins.input', side_effect=['7', answer, '0']), \
                    patch('sys.stdout', new_callable=io.StringIO) as stdout:
                self.assertEqual(CONTROL.menu(), 0)
                self.assertIn('7  同步博客文章资料', stdout.getvalue())
                self.assertEqual(sync.call_count, 1 if answer == 'y' else 0)

    def test_subprocess_failures_do_not_surface_output_or_exception_details(self):
        failures = [
            subprocess.CompletedProcess([], 1, stdout=SECRET, stderr=SECRET),
            subprocess.TimeoutExpired([SECRET], 30, output=SECRET, stderr=SECRET),
            OSError(SECRET),
        ]
        for failure in failures:
            with self.subTest(failure=type(failure).__name__):
                kwargs = {'side_effect': failure} if isinstance(failure, Exception) else {'return_value': failure}
                with patch.object(CONTROL.subprocess, 'run', **kwargs):
                    self.rejected(CONTROL.run_admin, 'status')

    def test_get_status_parses_only_status_json(self):
        with patch.object(CONTROL, 'run_admin', return_value=STATUS) as run:
            self.assertEqual(CONTROL.get_status(), STATUS)
        run.assert_called_once_with('status')
        for output in [SECRET, '[]', 'null', '"' + SECRET + '"', '{invalid-json:' + SECRET + '}',
                       '{}', '{"public":[]}', json.dumps(STATUS) + 'x' * 17000]:
            completed = subprocess.CompletedProcess([], 0, stdout=output, stderr=SECRET)
            with self.subTest(output=output[:30]), patch.object(CONTROL.subprocess, 'run', return_value=completed):
                self.rejected(CONTROL.get_status)

    def test_status_output_is_chinese_and_does_not_dump_unknown_fields(self):
        value = json.loads(json.dumps(STATUS))
        value['apiKey'] = SECRET
        value['adminToken'] = SECRET
        value['public']['extra'] = '\x1b[31m' + SECRET
        with patch('sys.stdout', new_callable=io.StringIO) as stdout:
            CONTROL.print_status(value)
        output = stdout.getvalue()
        self.assertRegex(output, '[\u4e00-\u9fff]')
        self.assertIn('500', output)
        self.assertIn('30', output)
        self.assertIn('768 Token/次', output)
        self.assertIn('费用', output)
        self.assertNotIn(SECRET, output)
        self.assertNotIn('\x1b[31m', output)
        self.assertNotIn('"public"', output)
        self.assertNotIn('apiKey', output)

    def test_status_rejects_untrusted_limit_text_and_bool_strings(self):
        value = json.loads(json.dumps(STATUS))
        value['public']['limits']['daily'] = '\x1b[2J' + SECRET
        value['public']['limits']['perIpDaily'] = {'bad': SECRET}
        value['public']['limits']['maxOutputTokens'] = '\x1b[2J' + SECRET
        value['public']['enabled'] = SECRET
        with patch('sys.stdout', new_callable=io.StringIO) as stdout:
            CONTROL.print_status(value)
        self.assertNotIn(SECRET, stdout.getvalue())
        self.assertNotIn('\x1b[2J', stdout.getvalue())

    def test_valid_limits_use_admin_command_and_human_feedback_without_json(self):
        fake = json.dumps({'dailyRequestLimit': 500, 'publicPerIpDailyLimit': 30, 'quotaReset': False,
                           'unexpectedSecret': SECRET})
        with patch.object(CONTROL, 'run_admin', return_value=fake) as run, \
                patch('sys.stdout', new_callable=io.StringIO) as stdout:
            CONTROL.set_limits(500, 30)
        run.assert_called_once_with('configure-limits', '500', '30')
        output = stdout.getvalue()
        self.assertRegex(output, '[\u4e00-\u9fff]')
        self.assertNotIn(SECRET, output)
        self.assertNotIn('dailyRequestLimit', output)
        self.assertNotIn('"quotaReset"', output)

    def test_invalid_limits_never_spawn_admin_or_fall_back_to_defaults(self):
        values = [(0, 30), (9007199254740992, 30), (500, 0), (500, 9007199254740992), (-1, 10), (True, 30),
                  (500, False), (1.5, 30), (500, None), ('500; echo injected', '30'),
                  ('', '30'), ('NaN', '30'), ('５００', '30'), ('500', '٣٠'),
                  ('500.0', '30'), ('+500', '30'), (' 500', '30'), ('500\n', '30'),
                  ('9' * 10000, '30')]
        with patch.object(CONTROL, 'run_admin') as run:
            for daily, per_ip in values:
                with self.subTest(daily=daily, per_ip=per_ip):
                    self.rejected(CONTROL.set_limits, daily, per_ip)
            run.assert_not_called()

    def test_limits_accept_former_caps_and_safe_integer_boundary(self):
        for daily, per_ip in [('1001', '101'), ('1000001', '100001'),
                              ('9007199254740991', '9007199254740991'), ('1', '1')]:
            with self.subTest(daily=daily), patch.object(CONTROL.subprocess, 'run', return_value=
                    subprocess.CompletedProcess([], 0, stdout=SECRET, stderr=SECRET)) as run, \
                    patch('sys.stdout', new_callable=io.StringIO):
                CONTROL.set_limits(daily, per_ip)
            self.assertEqual(run.call_args.args[0][-3:], ['configure-limits', daily, per_ip])
            self.assertFalse(run.call_args.kwargs['shell'])
            self.assertGreaterEqual(run.call_args.kwargs['timeout'], 60)

    def test_status_displays_new_limits_without_exposing_invalid_fields(self):
        status = json.loads(json.dumps(STATUS))
        status['public']['limits'] = {'daily': 9007199254740991, 'perIpDaily': 9007199254740991,
                                      'maxOutputTokens': 393216}
        with patch('sys.stdout', new_callable=io.StringIO) as output:
            CONTROL.print_status(status)
        self.assertEqual(output.getvalue().count('9007199254740991 次/日'), 2)
        self.assertIn('393216 Token/次', output.getvalue())
        for invalid in [True, False, 0, -1, 1.5, 9007199254740992, SECRET]:
            status['public']['limits']['daily'] = invalid
            status['public']['limits']['perIpDaily'] = invalid
            with patch('sys.stdout', new_callable=io.StringIO) as output:
                CONTROL.print_status(status)
            self.assertIn('全站额度：未读取到', output.getvalue())
            self.assertIn('每 IP 额度：未读取到', output.getvalue())
            self.assertNotIn(SECRET, output.getvalue())

    def test_enable_and_disable_only_map_to_public_controls(self):
        for enabled, action in [(True, 'public-continuous'), (False, 'public-disable')]:
            with self.subTest(enabled=enabled), patch.object(CONTROL, 'run_admin', return_value=SECRET) as run, \
                    patch('sys.stdout', new_callable=io.StringIO) as stdout:
                CONTROL.set_enabled(enabled)
            run.assert_called_once_with(action)
            self.assertRegex(stdout.getvalue(), '[\u4e00-\u9fff]')
            self.assertNotIn(SECRET, stdout.getvalue())
        with patch.object(CONTROL, 'run_admin') as run:
            for invalid in [1, 0, None, 'true', 'false', SECRET]:
                self.rejected(CONTROL.set_enabled, invalid)
            run.assert_not_called()

    def test_output_token_values_are_bounded_and_only_use_whitelisted_admin_action(self):
        for value in [1, '63', 64, '768', 1024, '2048', 2049, 8192, '393216']:
            with self.subTest(value=value), patch.object(CONTROL, 'run_admin', return_value=SECRET) as run, \
                    patch('sys.stdout', new_callable=io.StringIO) as stdout:
                CONTROL.set_output_tokens(value)
            run.assert_called_once_with('configure-output', str(value))
            self.assertIn('Token', stdout.getvalue())
            self.assertIn('费用', stdout.getvalue())
            self.assertIn('保持不变', stdout.getvalue())
            self.assertNotIn(SECRET, stdout.getvalue())
        with patch.object(CONTROL, 'run_admin') as run:
            for value in [None, True, False, 393217, 0, -64, 64.5, '', '1e3', '２０４８', '٢٠٤٨',
                          ' 2048', '2048 ', '2048\n', '2048; echo injected', '$(cat secret)', '9' * 10000]:
                with self.subTest(value=value):
                    self.rejected(CONTROL.set_output_tokens, value)
            run.assert_not_called()

    def test_configure_output_subprocess_is_fixed_argv_and_allows_rollback_time(self):
        with patch.object(CONTROL.subprocess, 'run', return_value=subprocess.CompletedProcess(
                [], 0, stdout=SECRET, stderr=SECRET)) as run, patch('sys.stdout', new_callable=io.StringIO) as stdout:
            CONTROL.run_admin('configure-output', '2048')
        argv, options = run.call_args.args[0], run.call_args.kwargs
        self.assertEqual(argv[-2:], ['configure-output', '2048'])
        self.assertFalse(options['shell'])
        self.assertGreaterEqual(options['timeout'], 60)
        self.assertLessEqual(options['timeout'], 120)
        self.assertEqual(stdout.getvalue(), '')
        with patch.object(CONTROL.subprocess, 'run') as run:
            for args in [('configure-output',), ('configure-output', '2048', 'extra'),
                         ('configure-output', '2048; echo injected'), ('configure-output', '')]:
                self.rejected(CONTROL.run_admin, *args)
            run.assert_not_called()

    def test_tokens_cli_is_explicit_without_prompt_or_other_mutations(self):
        with patch.object(CONTROL.os, 'geteuid', return_value=0, create=True), \
                patch.object(CONTROL, 'set_output_tokens') as tokens, \
                patch.object(CONTROL, 'set_enabled') as enabled, patch.object(CONTROL, 'set_limits') as limits, \
                patch('builtins.input', side_effect=AssertionError('CLI must not prompt')):
            self.assertEqual(CONTROL.main(['tokens', '2048']), 0)
        tokens.assert_called_once_with('2048')
        enabled.assert_not_called()
        limits.assert_not_called()
        with patch.object(CONTROL.os, 'geteuid', return_value=0, create=True), \
                patch.object(CONTROL, 'run_admin') as run:
            for args in [['tokens'], ['tokens', '2048', 'extra'], ['tokens', ''], ['tokens', '2048;status'],
                         ['tokens', '0'], ['tokens', '393217']]:
                self.rejected(CONTROL.main, args)
            run.assert_not_called()

    def test_menu_five_sets_output_tokens_only_after_valid_input_and_confirmation(self):
        for answers, expected in [(['5', '2048', 'y', '0'], 2048),
                                  (['5', '64', '确认', '0'], 64),
                                  (['5', '1', 'y', '0'], 1),
                                  (['5', '393216', 'y', '0'], 393216),
                                  (['5', '', '0'], None), (['5', '2048', '', '0'], None),
                                  (['5', '2048', 'n', '0'], None), (['5', '393217', '0'], None),
                                  (['5', '0', '0'], None), (['5', EOFError()], None),
                                  (['5', ' 2048 ', '0'], None),
                                  (['5', '2048', EOFError()], None),
                                  (['5', '2048', KeyboardInterrupt()], None)]:
            with self.subTest(answers=answers), patch.object(CONTROL.sys.stdin, 'isatty', return_value=True), \
                    patch('builtins.input', side_effect=answers) as input_, \
                    patch.object(CONTROL, 'get_status', return_value=STATUS), \
                    patch.object(CONTROL, 'set_output_tokens') as tokens, \
                    patch.object(CONTROL, 'set_enabled') as enabled, patch.object(CONTROL, 'set_limits') as limits, \
                    patch('sys.stdout', new_callable=io.StringIO) as stdout:
                self.assertEqual(CONTROL.menu(), 0)
            if expected is None:
                tokens.assert_not_called()
            else:
                tokens.assert_called_once_with(expected)
                prompts = ''.join(str(call.args[0]) for call in input_.call_args_list)
                self.assertIn('更多时间和费用', prompts)
            self.assertIn('5  调整回答长度', stdout.getvalue())
            self.assertIn('3  修改每天额度', stdout.getvalue())
            self.assertIn('4  查看当前状态', stdout.getvalue())
            enabled.assert_not_called()
            limits.assert_not_called()

    def test_status_output_token_limit_never_renders_untrusted_or_boolean_values(self):
        for value in [True, False, 0, 393217, {'secret': SECRET}, SECRET, '\x1b[2J' + SECRET]:
            status = json.loads(json.dumps(STATUS))
            status['public']['limits']['maxOutputTokens'] = value
            with self.subTest(value=value), patch('sys.stdout', new_callable=io.StringIO) as stdout:
                CONTROL.print_status(status)
            self.assertIn('回答上限：未读取到', stdout.getvalue())
            self.assertNotIn(SECRET, stdout.getvalue())
            self.assertNotIn('\x1b', stdout.getvalue())

    def test_cli_dispatch_is_explicit_and_never_prompts(self):
        with patch.object(CONTROL.os, 'geteuid', return_value=0, create=True), \
                patch.object(CONTROL, 'set_enabled') as enabled, \
                patch.object(CONTROL, 'set_limits') as limits, \
                patch.object(CONTROL, 'get_status', return_value=STATUS) as status, \
                patch.object(CONTROL, 'print_status') as show, \
                patch('builtins.input', side_effect=AssertionError('CLI must not ask a confirmation')):
            CONTROL.main(['on'])
            enabled.assert_called_with(True)
            CONTROL.main(['off'])
            enabled.assert_called_with(False)
            CONTROL.main(['limit', '500', '30'])
            self.assertEqual(tuple(map(int, limits.call_args.args)), (500, 30))
            CONTROL.main(['status'])
            status.assert_called_once()
            show.assert_called_once_with(STATUS)

    def test_default_main_uses_menu_not_any_mutation(self):
        with patch.object(CONTROL.os, 'geteuid', return_value=0, create=True), \
                patch.object(CONTROL, 'menu') as menu, patch.object(CONTROL, 'run_admin') as run:
            CONTROL.main([])
        menu.assert_called_once()
        run.assert_not_called()

    def test_help_and_invalid_cli_do_not_invoke_admin(self):
        with patch.object(CONTROL.os, 'geteuid', return_value=0, create=True), \
                patch.object(CONTROL, 'run_admin') as run:
            with patch('sys.stdout', new_callable=io.StringIO) as stdout:
                CONTROL.main(['help'])
            self.assertRegex(stdout.getvalue(), '[\u4e00-\u9fff]')
            self.assertIn('9007199254740991', stdout.getvalue())
            self.assertIn('1–393216 Token', stdout.getvalue())
            self.assertNotIn('64–2048', stdout.getvalue())
            for args in [['on', 'extra'], ['off', 'extra'], ['limit', '500'], ['status', 'extra'],
                         ['paid-smoke'], ['rm', '-rf', '/'], ['help', 'extra']]:
                with self.subTest(args=args):
                    self.rejected(CONTROL.main, args)
            run.assert_not_called()

    def test_noninteractive_menu_does_not_prompt_or_write(self):
        with patch.object(CONTROL.sys.stdin, 'isatty', return_value=False), \
                patch('builtins.input') as input_, \
                patch.object(CONTROL, 'set_enabled') as enabled, patch.object(CONTROL, 'set_limits') as limits, \
                patch.object(CONTROL, 'run_admin') as run:
            self.rejected(CONTROL.menu)
            input_.assert_not_called()
            enabled.assert_not_called()
            limits.assert_not_called()
            run.assert_not_called()

    def test_empty_or_eof_menu_selection_does_not_write(self):
        for answer in ['', EOFError()]:
            with self.subTest(answer=type(answer).__name__), \
                    patch.object(CONTROL.sys.stdin, 'isatty', return_value=True), \
                    patch('builtins.input', side_effect=[answer, '0'] if not isinstance(answer, Exception) else answer), \
                    patch.object(CONTROL, 'get_status', return_value=STATUS), \
                    patch.object(CONTROL, 'set_enabled') as enabled, patch.object(CONTROL, 'set_limits') as limits, \
                    patch('sys.stdout', new_callable=io.StringIO):
                try:
                    CONTROL.menu()
                except EOFError:
                    self.fail('EOF must cancel the menu gracefully')
                enabled.assert_not_called()
                limits.assert_not_called()

    def menu_with(self, answers):
        with patch.object(CONTROL.sys.stdin, 'isatty', return_value=True), \
                patch('builtins.input', side_effect=answers) as input_, \
                patch.object(CONTROL, 'get_status', return_value=STATUS) as status, \
                patch.object(CONTROL, 'set_enabled') as enabled, \
                patch.object(CONTROL, 'set_limits') as limits, \
                patch('sys.stdout', new_callable=io.StringIO) as output:
            result = CONTROL.menu()
        self.assertEqual(result, 0)
        prompts = '\n'.join(str(call.args[0]) for call in input_.call_args_list if call.args)
        return enabled, limits, status, output.getvalue() + prompts

    def test_menu_enable_disable_require_explicit_confirmation(self):
        for selection, value in [('1', True), ('2', False)]:
            for confirm in ['y', 'yes', '确认']:
                with self.subTest(selection=selection, confirm=confirm):
                    enabled, limits, status, output = self.menu_with([selection, confirm, '0'])
                    enabled.assert_called_once_with(value)
                    limits.assert_not_called()
                    status.assert_called_once()
                    if value:
                        self.assertIn('费用', output)

    def test_menu_unconfirmed_switches_do_not_write(self):
        for selection in ['1', '2']:
            for confirm in ['', 'n', 'no', 'maybe', EOFError()]:
                with self.subTest(selection=selection, confirm=type(confirm).__name__):
                    enabled, limits, _, _ = self.menu_with([selection, confirm, '0'])
                    enabled.assert_not_called()
                    limits.assert_not_called()

    def test_menu_limits_require_both_inputs_and_explicit_confirmation(self):
        for daily, per_ip in [('500', '30'), ('1001', '101'), ('9007199254740991', '9007199254740991')]:
            enabled, limits, status, output = self.menu_with(['3', daily, per_ip, 'y', '0'])
            limits.assert_called_once_with(int(daily), int(per_ip))
            enabled.assert_not_called()
            status.assert_called_once()
            self.assertIn('1–9007199254740991', output)
        for answers in [
            ['3', '', '0'], ['3', '500', '', '0'], ['3', '500', '30', '', '0'],
            ['3', '500', '30', 'n', '0'], ['3', EOFError()], ['3', '500', EOFError()],
            ['3', '500', '30', EOFError()], ['3', '9007199254740992', '0'],
            ['3', '500', '9007199254740992', '0'], ['3', ' 500 ', '0'],
        ]:
            with self.subTest(answers=answers):
                enabled, limits, _, _ = self.menu_with(answers)
                enabled.assert_not_called()
                limits.assert_not_called()

    def test_menu_status_and_unknown_selection_do_not_write(self):
        for choice in ['4', 'unknown', '99', 'paid-smoke']:
            with self.subTest(choice=choice):
                enabled, limits, status, _ = self.menu_with([choice, '0'])
                enabled.assert_not_called()
                limits.assert_not_called()
                self.assertEqual(status.call_count, 2 if choice == '4' else 1)

    def test_nonroot_cannot_read_or_mutate_through_main_but_help_is_available(self):
        with patch.object(CONTROL.os, 'geteuid', return_value=1000, create=True), \
                patch.object(CONTROL, 'run_admin') as run, patch.object(CONTROL, 'menu') as menu:
            for args in [[], ['status'], ['on'], ['off'], ['limit', '500', '30'], ['tokens', '2048'], ['sync']]:
                with self.subTest(args=args):
                    self.rejected(CONTROL.main, args)
            with patch('sys.stdout', new_callable=io.StringIO):
                self.assertEqual(CONTROL.main(['help']), 0)
            run.assert_not_called()
            menu.assert_not_called()


if __name__ == '__main__':
    unittest.main()
