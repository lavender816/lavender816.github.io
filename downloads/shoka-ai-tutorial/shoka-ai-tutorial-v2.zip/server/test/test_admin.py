"""Admin tests use only fake public downloads and fake configuration; never server secrets."""
from contextlib import nullcontext
from email.message import Message
import importlib.util
import io
import json
import os
from pathlib import Path
import stat
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import call, patch

SPEC = importlib.util.spec_from_file_location('ai_admin', Path(__file__).parents[1] / 'bin' / 'ai-admin.py')
ADMIN = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ADMIN)


class Response(io.BytesIO):
    def __init__(self, body=b'{"version":1}', status=200, url=None, content_type='application/json', length=None, encoding=None):
        super().__init__(body)
        self.status = status
        self.url = url or ADMIN.KNOWLEDGE_URL
        self.headers = Message()
        self.headers['Content-Type'] = content_type
        if length is not None:
            self.headers['Content-Length'] = str(length)
        if encoding:
            self.headers['Content-Encoding'] = encoding

    def geturl(self):
        return self.url


class AdminTests(unittest.TestCase):
    def test_manual_download_deadline_restores_alarm_on_all_exit_paths(self):
        # Windows has no SIGALRM; mock the Ubuntu interface without sleeping.
        for outcome in ['success', 'deadline', 'network-error']:
            with self.subTest(outcome=outcome), \
                    patch.object(ADMIN.signal, 'SIGALRM', 14, create=True), \
                    patch.object(ADMIN.signal, 'ITIMER_REAL', 0, create=True), \
                    patch.object(ADMIN.signal, 'signal', return_value='previous-handler') as handler, \
                    patch.object(ADMIN.signal, 'setitimer', create=True) as timer:
                if outcome == 'success':
                    with ADMIN.knowledge_timeout():
                        timer.assert_called_once_with(0, 90)
                elif outcome == 'deadline':
                    with self.assertRaisesRegex(TimeoutError, '^KNOWLEDGE_DOWNLOAD_TIMEOUT$'):
                        with ADMIN.knowledge_timeout():
                            handler.call_args.args[1](14, None)
                else:
                    with self.assertRaisesRegex(OSError, '^offline$'):
                        with ADMIN.knowledge_timeout():
                            raise OSError('offline')
                self.assertEqual(timer.call_args_list, [call(0, 90), call(0, 0)])
                self.assertEqual(handler.call_count, 2)
                handler.assert_called_with(14, 'previous-handler')

    def download(self, response):
        with patch.object(ADMIN, 'knowledge_timeout', return_value=nullcontext()), \
                patch.object(ADMIN.urllib.request, 'build_opener') as build:
            build.return_value.open.return_value = response
            result = io.BytesIO()
            ADMIN.download_knowledge(result)
            req = build.return_value.open.call_args.args[0]
            self.assertEqual(req.full_url, 'https://blog.example.com/ai-knowledge.json')
            self.assertEqual(build.return_value.open.call_args.kwargs, {'timeout': 15})
            self.assertTrue(any(isinstance(handler, ADMIN.NoKnowledgeRedirect) for handler in build.call_args.args))
            headers = {key.lower(): value for key, value in req.header_items()}
            self.assertNotIn('authorization', headers)
            self.assertNotIn('cookie', headers)
            self.assertEqual(headers['accept-encoding'], 'identity')
            return result.getvalue()

    def test_fixed_https_download_without_credentials(self):
        self.assertEqual(self.download(Response(b'{}', length=2)), b'{}')

    def test_redirect_is_rejected(self):
        with self.assertRaisesRegex(RuntimeError, 'KNOWLEDGE_REDIRECT_REJECTED'):
            ADMIN.NoKnowledgeRedirect().redirect_request(None, None, 302, '', {}, 'http://169.254.169.254/')
        with self.assertRaisesRegex(RuntimeError, 'KNOWLEDGE_DOWNLOAD_REJECTED'):
            self.download(Response(url='https://evil.example/'))

    def test_declared_oversize_is_rejected_before_read(self):
        with self.assertRaisesRegex(RuntimeError, 'KNOWLEDGE_TOO_LARGE'):
            self.download(Response(length=ADMIN.KNOWLEDGE_LIMIT + 1))

    def test_undeclared_oversize_is_bounded(self):
        with self.assertRaisesRegex(RuntimeError, 'KNOWLEDGE_TOO_LARGE'):
            self.download(Response(b'x' * (ADMIN.KNOWLEDGE_LIMIT + 1)))

    def test_missing_json_truncation_and_encoding_are_rejected(self):
        for response in [Response(status=404), Response(content_type='text/html'), Response(encoding='gzip'),
                         Response(b'{}', length=5), Response(b''), Response(length='bogus')]:
            with self.subTest(response=response), self.assertRaises(RuntimeError):
                self.download(response)

    def test_permission_checks_reject_symlinks_nonroot_and_writable_parents(self):
        fake = lambda mode, uid=0: SimpleNamespace(lstat=lambda: SimpleNamespace(st_mode=mode, st_uid=uid))
        ADMIN.assert_owned_directory(fake(stat.S_IFDIR | 0o755))
        ADMIN.assert_owned_file(fake(stat.S_IFREG | 0o644))
        for value in [fake(stat.S_IFLNK | 0o777), fake(stat.S_IFDIR | 0o777), fake(stat.S_IFDIR | 0o755, 1000)]:
            with self.assertRaises(RuntimeError):
                ADMIN.assert_owned_directory(value)
        for value in [fake(stat.S_IFLNK | 0o777), fake(stat.S_IFREG | 0o666), fake(stat.S_IFREG | 0o644, 1000)]:
            with self.assertRaises(RuntimeError):
                ADMIN.assert_owned_file(value)

    def test_local_preview_changes_only_the_fixed_origin(self):
        for value, origin in [('on', 'http://localhost:4000'), ('off', '')]:
            config = {'publicEnabled': False, 'publicUntil': 123, 'paidEnabled': False,
                      'dailyRequestLimit': 50, 'publicPerIpDailyLimit': 10}
            original = dict(config)
            with patch.object(ADMIN.os, 'geteuid', return_value=0, create=True), \
                    patch.object(sys, 'argv', ['ai-admin.py', 'local-preview', value]), \
                    patch.object(ADMIN, 'read', return_value=config), patch.object(ADMIN, 'save') as save, \
                    patch.object(ADMIN, 'restart') as restart, patch('sys.stdout', new_callable=io.StringIO):
                ADMIN.main()
                self.assertEqual(save.call_args.args[0], {**original, 'publicLocalDevOrigin': origin})
                restart.assert_called_once()

    def test_local_preview_rejects_arbitrary_origin_arguments(self):
        with patch.object(ADMIN.os, 'geteuid', return_value=0, create=True), \
                patch.object(sys, 'argv', ['ai-admin.py', 'local-preview', 'https://evil.example']), \
                patch.object(ADMIN, 'read') as read, self.assertRaisesRegex(RuntimeError, 'EXPECTED_LOCAL_PREVIEW'):
            ADMIN.main()
        read.assert_not_called()

    def run_action(self, args, config, ready=True):
        with patch.object(ADMIN.os, 'geteuid', return_value=0, create=True), \
                patch.object(sys, 'argv', ['ai-admin.py', *args]), \
                patch.object(ADMIN, 'read', return_value=dict(config)), patch.object(ADMIN, 'save') as save, \
                patch.object(ADMIN, 'restart') as restart, \
                patch.object(ADMIN, 'request', return_value=Response(
                    b'{"configured":true,"knowledgeReady":true}' if ready else b'{"configured":true,"knowledgeReady":false}')), \
                patch.object(ADMIN.time, 'time', return_value=1800000000), \
                patch('sys.stdout', new_callable=io.StringIO):
            try:
                ADMIN.main()
            except Exception:
                save.assert_not_called()
                restart.assert_not_called()
                raise
            restart.assert_called_once()
            save.assert_called_once()
            return save.call_args.args[0]

    def test_continuous_public_access_is_explicit_and_preserves_limits(self):
        original = {'apiKey': 'fake-key-for-isolated-test', 'dailyRequestLimit': 500,
                    'publicPerIpDailyLimit': 30, 'publicLocalDevOrigin': 'http://localhost:4000',
                    'paidEnabled': True, 'paidUntil': 123, 'publicEnabled': False, 'publicUntil': 123}
        result = self.run_action(['public-continuous'], original)
        self.assertEqual(result, {**original, 'publicEnabled': True, 'publicUntil': 0,
                                  'publicContinuous': True, 'paidEnabled': False, 'paidUntil': 0})

    def test_trial_command_replaces_continuous_mode_with_seven_day_expiry(self):
        result = self.run_action(['public-enable'], {'apiKey': 'fake-key-for-isolated-test',
                                                    'publicContinuous': True, 'publicUntil': 0})
        self.assertTrue(result['publicEnabled'])
        self.assertFalse(result['publicContinuous'])
        self.assertEqual(result['publicUntil'], 1800000000000 + 7 * 24 * 60 * 60 * 1000)
        self.assertFalse(result['paidEnabled'])

    def test_disabling_public_access_clears_permanent_mode(self):
        original = {'publicEnabled': True, 'publicContinuous': True, 'publicUntil': 0,
                    'dailyRequestLimit': 500, 'publicPerIpDailyLimit': 30}
        result = self.run_action(['public-disable'], original)
        self.assertEqual(result, {**original, 'publicEnabled': False, 'publicContinuous': False})

    def test_updating_limits_preserves_continuous_mode_and_other_config(self):
        original = {'publicEnabled': True, 'publicContinuous': True, 'publicUntil': 0,
                    'dailyRequestLimit': 500, 'publicPerIpDailyLimit': 30, 'maxConcurrent': 2,
                    'maxOutputTokens': 2048, 'apiKey': 'fake-key-for-isolated-test'}
        for daily, per_ip in [('500', '30'), ('1001', '101'), ('1', '1'),
                              ('9007199254740991', '9007199254740991')]:
            with self.subTest(daily=daily):
                result = self.run_action(['configure-limits', daily, per_ip], original)
                self.assertEqual(result, {**original, 'dailyRequestLimit': int(daily), 'publicPerIpDailyLimit': int(per_ip)})

    def test_configure_limits_invalid_arguments_never_read_or_write_configuration(self):
        invalid = [[], ['500'], ['500', '30', 'extra']]
        for value in ['', '0', '-1', '9007199254740992', '9007199254740991.0', 'true', True,
                      '５００', '٣٠', '+1', ' 1', '1 ', '1\n', '1e3', '500;echo injected', '9' * 10000]:
            invalid.extend([[value, '30'], ['500', value]])
        for extra in invalid:
            with self.subTest(extra=extra), patch.object(ADMIN.os, 'geteuid', return_value=0, create=True), \
                    patch.object(sys, 'argv', ['ai-admin.py', 'configure-limits', *extra]), \
                    patch.object(ADMIN, 'read') as read, patch.object(ADMIN, 'save') as save, \
                    patch.object(ADMIN, 'restart') as restart, self.assertRaises(RuntimeError):
                ADMIN.main()
            read.assert_not_called()
            save.assert_not_called()
            restart.assert_not_called()

    def test_configure_limits_failure_restores_original_without_touching_quota(self):
        original = {'dailyRequestLimit': 500, 'publicPerIpDailyLimit': 30, 'maxOutputTokens': 2048,
                    'apiKey': 'fake-private-do-not-print', 'publicEnabled': True, 'publicContinuous': True}
        for phase in ['save', 'restart', 'rollback-restart', 'interrupt']:
            saved_failure = RuntimeError(original['apiKey'])
            restart_errors = [saved_failure, None]
            if phase == 'rollback-restart':
                restart_errors[1] = RuntimeError(original['apiKey'])
            elif phase == 'interrupt':
                restart_errors[0] = KeyboardInterrupt()
            with self.subTest(phase=phase), patch.object(ADMIN.os, 'geteuid', return_value=0, create=True), \
                    patch.object(sys, 'argv', ['ai-admin.py', 'configure-limits', '2000', '200']), \
                    patch.object(ADMIN, 'read', return_value=original), \
                    patch.object(ADMIN, 'save', side_effect=[saved_failure, None] if phase == 'save' else None) as save, \
                    patch.object(ADMIN, 'restart', side_effect=[None] if phase == 'save' else restart_errors) as restart, \
                    patch.object(ADMIN, 'read_state') as state, patch.object(ADMIN, 'request') as request, \
                    patch('sys.stdout', new_callable=io.StringIO) as output:
                if phase == 'interrupt':
                    with self.assertRaises(KeyboardInterrupt):
                        ADMIN.main()
                else:
                    with self.assertRaisesRegex(RuntimeError, '^LIMITS_UPDATE_FAILED$'):
                        ADMIN.main()
            self.assertEqual([call.args[0] for call in save.call_args_list],
                             [{**original, 'dailyRequestLimit': 2000, 'publicPerIpDailyLimit': 200}, original])
            self.assertEqual(restart.call_count, 1 if phase == 'save' else 2)
            self.assertEqual(original['dailyRequestLimit'], 500)
            state.assert_not_called()
            request.assert_not_called()
            self.assertNotIn(original['apiKey'], output.getvalue())

    def test_public_modes_allow_general_chat_without_knowledge_but_still_require_key(self):
        for action in ['public-enable', 'public-continuous']:
            with self.subTest(action=action), self.assertRaisesRegex(RuntimeError, 'KEY_NOT_CONFIGURED'):
                self.run_action([action], {}, False)
            result = self.run_action([action], {'apiKey': 'fake-key-for-isolated-test'}, False)
            self.assertTrue(result['publicEnabled'])
            self.assertEqual(result['publicContinuous'], action == 'public-continuous')

    def test_public_enable_rejects_unhealthy_or_unconfigured_running_status(self):
        for response in [Response(b'{}'), Response(b'[]'), Response(b'null'),
                         Response(b'{"configured":false,"knowledgeReady":true}'),
                         Response(b'{"configured":"true"}'), Response(b'{"configured":true}', status=503)]:
            with self.subTest(response=response), patch.object(ADMIN.os, 'geteuid', return_value=0, create=True), \
                    patch.object(sys, 'argv', ['ai-admin.py', 'public-continuous']), \
                    patch.object(ADMIN, 'read', return_value={'apiKey': 'fake-key-for-isolated-test'}), \
                    patch.object(ADMIN, 'request', return_value=response), patch.object(ADMIN, 'save') as save, \
                    patch.object(ADMIN, 'restart') as restart, self.assertRaisesRegex(RuntimeError, 'SERVICE_NOT_READY'):
                ADMIN.main()
            save.assert_not_called()
            restart.assert_not_called()

    def test_configure_output_accepts_bounds_and_preserves_every_other_field(self):
        original = {'apiKey': 'fake-key-private', 'adminToken': 'fake-admin-private',
                    'maxOutputTokens': 768, 'dailyRequestLimit': 500, 'publicPerIpDailyLimit': 30,
                    'publicEnabled': True, 'publicContinuous': True, 'publicUntil': 0,
                    'paidEnabled': False, 'paidUntil': 0, 'maxConcurrent': 2,
                    'ownerExtra': {'preserve': ['test-history-is-not-a-real-log']}}
        for tokens in [1, 63, 64, 768, 1024, 2048, 2049, 8192, 393216]:
            with self.subTest(tokens=tokens), patch.object(ADMIN.os, 'geteuid', return_value=0, create=True), \
                    patch.object(sys, 'argv', ['ai-admin.py', 'configure-output', str(tokens)]), \
                    patch.object(ADMIN, 'read', return_value=original), patch.object(ADMIN, 'save') as save, \
                    patch.object(ADMIN, 'restart') as restart, patch.object(ADMIN, 'request') as request, \
                    patch('sys.stdout', new_callable=io.StringIO) as stdout:
                ADMIN.main()
            save.assert_called_once_with({**original, 'maxOutputTokens': tokens})
            restart.assert_called_once()
            request.assert_not_called()
            self.assertEqual(original['maxOutputTokens'], 768)
            self.assertEqual(json.loads(stdout.getvalue()), {'maxOutputTokens': tokens, 'quotaReset': False})
            self.assertNotIn(original['apiKey'], stdout.getvalue())
            self.assertNotIn(original['adminToken'], stdout.getvalue())

    def test_configure_output_invalid_arguments_never_read_or_mutate_configuration(self):
        invalid = [[], [''], ['393217'], ['0'], ['-64'], ['64.0'], ['true'], [True], ['２０４８'], ['٢٠٤٨'],
                   [' 2048'], ['2048 '], ['1e3'], ['2048;cat /etc/blog-ai/config.json'],
                   ['$(echo secret)'], ['2048\n'], ['2048', 'extra'], ['2048', 'public-enable'], ['9' * 10000]]
        for extra in invalid:
            with self.subTest(extra=extra), patch.object(ADMIN.os, 'geteuid', return_value=0, create=True), \
                    patch.object(sys, 'argv', ['ai-admin.py', 'configure-output', *extra]), \
                    patch.object(ADMIN, 'read') as read, patch.object(ADMIN, 'save') as save, \
                    patch.object(ADMIN, 'restart') as restart, self.assertRaises(RuntimeError):
                ADMIN.main()
            read.assert_not_called()
            save.assert_not_called()
            restart.assert_not_called()

    def test_configure_output_restart_failure_restores_original_and_hides_details(self):
        original = {'apiKey': 'fake-private-do-not-print', 'adminToken': 'fake-token-do-not-print',
                    'maxOutputTokens': 768, 'dailyRequestLimit': 500, 'publicPerIpDailyLimit': 30,
                    'publicEnabled': True, 'publicContinuous': True}
        for errors in [[RuntimeError(original['apiKey']), None],
                       [RuntimeError(original['apiKey']), RuntimeError(original['adminToken'])]]:
            with self.subTest(rollback_fails=errors[1] is not None), \
                    patch.object(ADMIN.os, 'geteuid', return_value=0, create=True), \
                    patch.object(sys, 'argv', ['ai-admin.py', 'configure-output', '2048']), \
                    patch.object(ADMIN, 'read', return_value=original), patch.object(ADMIN, 'save') as save, \
                    patch.object(ADMIN, 'restart', side_effect=errors) as restart, \
                    patch('sys.stdout', new_callable=io.StringIO) as stdout, \
                    patch('sys.stderr', new_callable=io.StringIO) as stderr:
                with self.assertRaisesRegex(RuntimeError, '^OUTPUT_UPDATE_FAILED$') as failure:
                    ADMIN.main()
            self.assertEqual([call.args[0] for call in save.call_args_list],
                             [{**original, 'maxOutputTokens': 2048}, original])
            self.assertEqual(restart.call_count, 2)
            self.assertEqual(original['maxOutputTokens'], 768)
            self.assertNotIn(original['apiKey'], stdout.getvalue() + stderr.getvalue() + str(failure.exception))
            self.assertNotIn(original['adminToken'], stdout.getvalue() + stderr.getvalue() + str(failure.exception))

    def test_configure_output_atomic_save_uses_private_temp_file_and_replace(self):
        config = {'apiKey': 'fake-test-only', 'maxOutputTokens': 2048}
        with tempfile.TemporaryDirectory(prefix='blog-ai-admin-test-') as directory:
            target = Path(directory) / 'config.json'
            target.write_text('{"maxOutputTokens":768}', encoding='utf-8')
            replace = os.replace
            seen = []
            def replace_checked(source, destination):
                self.assertEqual(Path(destination), target)
                self.assertEqual(json.loads(target.read_text(encoding='utf-8')), {'maxOutputTokens': 768})
                self.assertEqual(json.loads(Path(source).read_text(encoding='utf-8')), config)
                seen.append(Path(source))
                return replace(source, destination)
            with patch.object(ADMIN, 'CONFIG', target), \
                    patch.object(ADMIN.os, 'fchmod', create=True) as chmod, \
                    patch.object(ADMIN.os, 'replace', side_effect=replace_checked), \
                    patch('sys.stdout', new_callable=io.StringIO) as stdout:
                ADMIN.save(config)
            self.assertEqual(chmod.call_args.args[1], 0o600)
            self.assertEqual(json.loads(target.read_text(encoding='utf-8')), config)
            self.assertEqual(len(seen), 1)
            self.assertFalse(seen[0].exists())
            self.assertEqual([item.name for item in Path(directory).iterdir()], ['config.json'])
            self.assertEqual(stdout.getvalue(), '')

    def test_private_smoke_disables_then_restores_continuous_mode(self):
        original = {'apiKey': 'fake-key-for-isolated-test', 'publicEnabled': True,
                    'publicUntil': 0, 'publicContinuous': True, 'paidEnabled': False, 'paidUntil': 0,
                    'dailyRequestLimit': 500, 'publicPerIpDailyLimit': 30, 'maxOutputTokens': 1024}
        with patch.object(ADMIN.os, 'geteuid', return_value=0, create=True), \
                patch.object(sys, 'argv', ['ai-admin.py', 'paid-smoke']), \
                patch.object(ADMIN, 'read', return_value=dict(original)), patch.object(ADMIN, 'save') as save, \
                patch.object(ADMIN, 'restart'), patch('sys.stdout', new_callable=io.StringIO), \
                patch.object(ADMIN, 'check_stream', side_effect=RuntimeError('FAKE_UPSTREAM_FAILURE')) as stream:
            with self.assertRaisesRegex(RuntimeError, 'FAKE_UPSTREAM_FAILURE'):
                ADMIN.main()
            temporary = save.call_args_list[0].args[0]
            self.assertFalse(temporary['publicEnabled'])
            self.assertFalse(temporary['publicContinuous'])
            self.assertEqual(temporary['publicUntil'], 0)
            self.assertEqual(save.call_args_list[1].args[0], original)
            stream.assert_called_once()


if __name__ == '__main__':
    unittest.main()
