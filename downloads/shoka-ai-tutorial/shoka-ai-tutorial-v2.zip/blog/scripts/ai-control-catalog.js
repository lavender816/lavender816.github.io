
'use strict';
const { buildCatalog, readRoute } = require('../lib/pageview-catalog.cjs');
const { controlCatalog } = require('../lib/ai-control-catalog.cjs');
const { buildKnowledge, plainText } = require('../lib/ai-knowledge.cjs');
hexo.extend.filter.register('after_generate', async function() {
  const counted = await buildCatalog({ route: hexo.route, posts: hexo.locals.get('posts'), root: hexo.config.root,
    siteTitles: [hexo.config.title, hexo.config.subtitle, hexo.theme.config.alternate] });
  const routes = hexo.route.list();
  const publicKnowledge = buildKnowledge({ posts: hexo.locals.get('posts'), pages: hexo.locals.get('pages'),
    root: hexo.config.root || '/', now: Date.now() });
  const countByPath = new Map(counted.entries.map(entry => [entry.href, entry]));
  const postsByPath = new Map();
  hexo.locals.get('posts').forEach(post => postsByPath.set('/' + post.path.replace(/index\.html$/i, ''), post));
  const catalog = { version: 1, entries: publicKnowledge.articles.filter(item => {
    const relative = item.path.replace(/^\//, '');
    return routes.includes(relative.endsWith('/') ? relative + 'index.html' : relative);
  }).map(item => {
    const counter = countByPath.get(item.path);
    const post = postsByPath.get(item.path);
    const length = post && Number(post.length);
    return { path: item.path.replace(/^\//, ''), href: item.path, title: item.title,
      kind: post ? 'post' : 'page', counted: !!counter,
      wordCount: counter ? counter.wordCount : Number.isFinite(length) ? Math.max(0, Math.floor(length)) : plainText(post ? post.content : item.text, 4 * 1024 * 1024).replace(/\s+/g, '').length,
      categories: item.categories || [] };
  }) };
  const friends = routes.includes('friends/index.html') ? await readRoute(hexo.route.get('friends/index.html')) : '';
  hexo.route.set('ai-control-catalog.json', JSON.stringify(controlCatalog(catalog, routes, friends, hexo.config.root, hexo.locals.get('posts'))));
}, 100);
