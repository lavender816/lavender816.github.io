
var aiAssets = {
  blog_ai: ['blog-ai', 'ShokaBlogAI'], ai_markdown: ['ai-markdown', 'ShokaAIMarkdown'],
  ai_actions: ['ai-actions', 'BlogAIActions'], ai_playground: ['ai-playground', 'BlogAIPlayground'],
  text_workshop: ['text-workshop', 'ShokaTextWorkshop']
};
var aiPending = Object.create(null), aiStylePending = Object.create(null);
var aiOldFeatures = window.ShokaFeatures || {}, aiPageGeneration = 0;
function aiAsset(file) {
  return typeof fingerprintedAsset === 'function' ? fingerprintedAsset(file) : (CONFIG.root || '/') + file;
}
function loadAIAsset(tag, file) {
  return new Promise(function(resolve, reject) {
    var node = document.createElement(tag), timer = setTimeout(fail, 20000);
    function fail() { clearTimeout(timer); node.remove(); reject(new Error('AI_ASSET_UNAVAILABLE')); }
    node.onload = function() { clearTimeout(timer); resolve(); }; node.onerror = fail;
    if(tag === 'link') { node.rel = 'stylesheet'; node.href = aiAsset(file); }
    else { node.src = aiAsset(file); node.async = true; }
    document.head.appendChild(node);
  });
}
function loadAIStyles(file) {
  if(!aiStylePending[file]) aiStylePending[file] = loadAIAsset('link', file).catch(function(error) {
    delete aiStylePending[file]; throw error;
  });
  return aiStylePending[file];
}
function loadAI(id) {
  var item = aiAssets[id];
  if(!item) return aiOldFeatures.load ? aiOldFeatures.load(id) : Promise.reject(new Error('AI_PREREQUISITE_MISSING'));
  if(!aiPending[id]) aiPending[id] = Promise.all([
    loadAIStyles('css/' + item[0] + '.css'),
    window[item[1]] ? Promise.resolve() : loadAIAsset('script', 'js/' + item[0] + '.js')
  ]).then(function() {
    if(!window[item[1]]) throw new Error('AI_MODULE_MISSING');
    return window[item[1]];
  }).catch(function(error) { delete aiPending[id]; throw error; });
  return aiPending[id];
}
window.ShokaFeatures = Object.assign({}, aiOldFeatures, {
  load: loadAI, asset: aiAsset,
  generation: function() { return aiOldFeatures.generation ? aiOldFeatures.generation() : aiPageGeneration; },
  setTheme: function(value) {
    if(!['dark', 'light'].includes(value)) return false;
    if(aiOldFeatures.setTheme) return aiOldFeatures.setTheme(value);
    changeTheme(value); store.set('theme', value); return true;
  }
});
window.addEventListener('pjax:send', function() { aiPageGeneration++; });
var aiWorkshopTarget = null;
function mountAIWorkshop() {
  var target = document.querySelector('[data-text-workshop]');
  if(!target || target === aiWorkshopTarget) return;
  aiWorkshopTarget = target;
  if(target.dataset.textWorkshop === 'home') {
    loadAIStyles('css/text-workshop.css').catch(function() {}); return;
  }
  var generation = window.ShokaFeatures.generation();
  loadAI('text_workshop').then(function(api) {
    if(target.isConnected && generation === window.ShokaFeatures.generation()) api.mount(document);
  }).catch(function() {
    if(!target.isConnected || generation !== window.ShokaFeatures.generation()) return;
    if(aiWorkshopTarget === target) aiWorkshopTarget = null;
    var box = target.querySelector('[data-tw-runtime]');
    if(box) box.textContent = '工坊资源加载失败，请刷新重试。';
  });
}
window.addEventListener('pjax:send', function() {
  aiWorkshopTarget = null;
  if(window.ShokaTextWorkshop) window.ShokaTextWorkshop.destroy();
});
window.addEventListener('pjax:success', mountAIWorkshop);
