
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const base = path.dirname(fileURLToPath(import.meta.url));
const [blog, ai] = process.argv.slice(2);
function origin(value) {
  const url = new URL(value);
  if(url.protocol !== 'https:' || url.username || url.password || url.port || url.search || url.hash || url.pathname !== '/') throw new Error('Use an HTTPS origin without path or credentials');
  return url.origin;
}
const blogOrigin = origin(blog), aiOrigin = origin(ai);
if(blogOrigin === aiOrigin || [blogOrigin, aiOrigin].some(value => new URL(value).hostname.endsWith('.example.com'))) throw new Error('Replace the example domains with YOUR two real domains');
// Edit only the explicitly exported tutorial files, not an existing project.
const manifest = JSON.parse(fs.readFileSync(path.join(base, 'manifest.json'), 'utf8'));
let changed = 0;
for(const name of manifest.files) {
  if(name === 'configure-examples.mjs' || !/\.(?:mjs|cjs|js|py|json|conf|md)$/.test(name)) continue;
  if(name.includes('..') || path.isAbsolute(name)) throw new Error('Invalid manifest path');
  const file = path.join(base, name), original = fs.readFileSync(file, 'utf8');
  const next = original.replaceAll('https://blog.example.com', blogOrigin).replaceAll('https://ai.example.com', aiOrigin)
    .replaceAll('ai.example.com', new URL(aiOrigin).hostname).replaceAll('blog.example.com', new URL(blogOrigin).hostname);
  if(next !== original) { fs.writeFileSync(file, next); changed++; }
}
console.log('Configured tutorial files:', changed, 'No API keys are needed or written by this command.');
