import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createWebSearch } from '../src/web-search.mjs';
import { validateConfig } from '../src/service.mjs';

const endpoint = 'http://127.0.0.1:8088/search';
const entry = { title: 'synthetic title', url: 'https://example.org/reference', content: 'reference' };
const reply = entries => new Response(JSON.stringify({ results: entries }), {
  headers: { 'Content-Type': 'application/json' }
});
const never = () => new Promise(() => {});
const signal = () => new AbortController().signal;

async function within(promise, ms = 1000) {
  let timer;
  try {
    return await Promise.race([promise, new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error('SEARCH_TEST_DEADLINE')), ms);
    })]);
  } finally { clearTimeout(timer); }
}

function fakeBody(reader) {
  return { ok: true, headers: new Headers({ 'Content-Type': 'application/json' }),
    body: { getReader: () => reader } };
}

test('bounded linear cleaning handles the exact 250 KB unclosed-tag audit payload promptly', async () => {
  const entries = [{ ...entry, content: '<'.repeat(250000) }];
  assert.equal(Buffer.byteLength(JSON.stringify({ results: entries })), 250092);
  let calls = 0;
  const search = createWebSearch(endpoint, { fetchImpl: async () => { calls++; return reply(entries); } });
  const start = performance.now();
  const tick = new Promise(resolve => setTimeout(resolve, 0));
  const result = await search('synthetic isolated audit', signal());
  await tick;
  // A generous fixed budget avoids noise; the old implementation took ~13 s.
  assert.ok(performance.now() - start < 1000, 'cleaning blocked the event loop');
  assert.equal(result.status, 'ok');
  assert.equal(result.results[0].text, '<'.repeat(800));
  assert.equal(calls, 1);
});

test('raw field caps apply before markup/whitespace cleaning, retaining output and source bounds', async () => {
  let query;
  const search = createWebSearch(endpoint, { fetchImpl: async (_url, init) => {
    query = new URLSearchParams(init.body).get('q');
    return reply([
      { ...entry, title: ' '.repeat(8192) + 'hidden-after-cap' },
      ...Array.from({ length: 29 }, (_, index) => ({ title: '<'.repeat(3000),
        content: '<'.repeat(3000), url: `https://example.org/${index}` }))
    ]);
  } });
  const result = await search('<'.repeat(250000), signal());
  assert.equal(query, '<'.repeat(400));
  assert.equal(result.results.length, 4);
  assert.ok(result.results.every(item => item.title === '<'.repeat(160) && item.text === '<'.repeat(800)));
  assert.ok(result.results.every(item => item.url !== entry.url));
});

test('cleaning preserves ordinary text, tag separation, controls and unmatched less-than text', async () => {
  const search = createWebSearch(endpoint, { fetchImpl: async () => reply([
    { ...entry, title: '<b>正常标题</b>', content: 'a<i>b</i>\u0000\t c  1 < 2' }
  ]) });
  const result = await search('safe query', signal());
  assert.equal(result.results[0].title, '正常标题');
  assert.equal(result.results[0].text, 'a b c 1 < 2');
});

test('an already cancelled caller never initiates a search request', async () => {
  let calls = 0;
  const controller = new AbortController(), reason = new Error('caller cancelled');
  controller.abort(reason);
  const search = createWebSearch(endpoint, { fetchImpl: async () => { calls++; return reply([entry]); } });
  await assert.rejects(search('query', controller.signal), error => error === reason);
  assert.equal(calls, 0);
});

test('caller cancellation escapes an abort-ignoring fetch and disposes its late response', async () => {
  let finishFetch, cancelCalls = 0, fetchCalls = 0;
  const controller = new AbortController(), reason = new Error('caller cancelled');
  const search = createWebSearch(endpoint, { fetchImpl: () => {
    fetchCalls++;
    return new Promise(resolve => { finishFetch = resolve; });
  } });
  const pending = search('query', controller.signal);
  controller.abort(reason);
  await assert.rejects(within(pending), error => error === reason);
  finishFetch({ body: { cancel: () => { cancelCalls++; return never(); } } });
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(fetchCalls, 1);
  assert.equal(cancelCalls, 1);
});

test('caller cancellation escapes a hanging body read and never waits on its cancel hook', async () => {
  const controller = new AbortController(), reason = new Error('caller cancelled');
  let beginRead, cancelCalls = 0;
  const reading = new Promise(resolve => { beginRead = resolve; });
  const search = createWebSearch(endpoint, { fetchImpl: async () => fakeBody({
    read: () => { beginRead(); return never(); },
    cancel: () => { cancelCalls++; return never(); }
  }) });
  const pending = search('query', controller.signal);
  await reading;
  controller.abort(reason);
  await assert.rejects(within(pending), error => error === reason);
  assert.equal(cancelCalls, 1);
});

test('7 second timeout bounds abort-ignoring fetch and body read without retries', async () => {
  await Promise.all(['fetch', 'read'].map(async stage => {
    let calls = 0, cancelCalls = 0, requestSignal;
    const search = createWebSearch(endpoint, { fetchImpl: (_url, init) => {
      calls++;
      requestSignal = init.signal;
      return stage === 'fetch' ? never() : Promise.resolve(fakeBody({
        read: never, cancel: () => { cancelCalls++; return never(); }
      }));
    } });
    const start = performance.now();
    assert.deepEqual(await within(search('query', signal()), 9500), { status: 'unavailable', results: [] });
    assert.ok(performance.now() - start >= 6900);
    assert.equal(requestSignal.aborted, true);
    assert.equal(calls, 1);
    assert.equal(cancelCalls, stage === 'read' ? 1 : 0);
  }));
});

test('elapsed deadline is checked after synchronous response/result processing', async () => {
  let time = 0;
  const afterFetch = createWebSearch(endpoint, { monotonicNow: () => time, fetchImpl: async () => {
    time = 7001;
    return reply([entry]);
  } });
  assert.equal((await afterFetch('query', signal())).status, 'unavailable');
  time = 0;
  const afterClean = createWebSearch(endpoint, { monotonicNow: () => time,
    now: () => { time = 7001; return 0; }, fetchImpl: async () => reply([entry]) });
  assert.equal((await afterClean('query', signal())).status, 'unavailable');
});

test('cancellation during result processing is not returned as successful search data', async () => {
  const controller = new AbortController(), reason = new Error('caller cancelled');
  const search = createWebSearch(endpoint, { now: () => { controller.abort(reason); return 0; },
    fetchImpl: async () => reply([entry]) });
  await assert.rejects(search('query', controller.signal), error => error === reason);
});

test('cleanup hooks cannot hang or replace a valid response/error', async () => {
  for (const cancel of [never, () => { throw new Error('private cleanup error'); },
    () => Promise.reject(new Error('private cleanup rejection'))]) {
    let readCalls = 0;
    const payload = new TextEncoder().encode(JSON.stringify({ results: [entry] }));
    const search = createWebSearch(endpoint, { fetchImpl: async () => fakeBody({ cancel,
      read: async () => readCalls++ ? { done: true } : { value: payload, done: false }
    }) });
    assert.equal((await within(search('query', signal()))).status, 'ok');
    const failed = createWebSearch(endpoint, { fetchImpl: async () => ({ ok: false, body: { cancel } }) });
    assert.equal((await within(failed('query', signal()))).status, 'unavailable');
  }
});

test('local proxy template covers the permitted request maximum without changing the 60 s default', async () => {
  const config = { adminToken: 'local-test-admin-token-123456789012345' };
  assert.equal(validateConfig(config).requestTimeoutMs, 60000);
  assert.equal(validateConfig({ ...config, requestTimeoutMs: 120000 }).requestTimeoutMs, 120000);
  assert.throws(() => validateConfig({ ...config, requestTimeoutMs: 120001 }));
  const nginx = await readFile(new URL('../deploy/nginx-https.conf', import.meta.url), 'utf8');
  const api = nginx.slice(nginx.indexOf('location ^~ /api/ {', nginx.indexOf('listen 443')));
  const proxySeconds = Number(api.match(/proxy_read_timeout\s+(\d+)s;/)?.[1]);
  assert.ok(proxySeconds >= 130 && proxySeconds <= 150, 'proxy must leave a bounded margin above 120 s');
});
