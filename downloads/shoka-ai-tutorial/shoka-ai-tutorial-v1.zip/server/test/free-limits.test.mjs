import test from 'node:test';
import assert from 'node:assert/strict';
import * as fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createHmac } from 'node:crypto';
import { createAiServer, validateConfig } from '../src/service.mjs';
import { createUsageAlerts } from '../src/usage-alerts.mjs';
import { workshopEvents } from '../src/workshop.mjs';
import { listenForFetch } from './listen-test.mjs';

const TOKEN = 'test-free-limits-admin-0123456789';
const KEY = 'test-free-limits-upstream-012345';
const SITE = 'https://blog.example.com';
const DAY = '2026-09-19';
const NOW = Date.UTC(2026, 8, 19, 4);
const MAX = Number.MAX_SAFE_INTEGER;
const finish = 'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n';
const frame = value => 'data: ' + JSON.stringify({ choices: [{ delta: { content: value } }] }) + '\n\n';
function stream(text = '测试', chunkSize = 1000) {
  const encoder = new TextEncoder();
  let index = 0;
  return new Response(new ReadableStream({ pull(controller) {
    if (index < text.length) {
      controller.enqueue(encoder.encode(frame(text.slice(index, index += chunkSize))));
    } else { controller.enqueue(encoder.encode(finish)); controller.close(); }
  } }), { headers: { 'Content-Type': 'text/event-stream' } });
}

async function fixture(t, extra = {}, fetchImpl) {
  const stateDir = await fs.mkdtemp(path.join(os.tmpdir(), 'blog-ai-free-limits-'));
  const calls = [];
  const server = createAiServer({ adminToken: TOKEN, apiKey: KEY, publicEnabled: true,
    publicContinuous: true, dailyRequestLimit: 500, publicPerIpDailyLimit: 30,
    maxOutputTokens: 2048, ...extra }, { stateDir, now: () => NOW,
    fetchImpl: async (url, init) => {
      calls.push({ url, body: JSON.parse(init.body) });
      return fetchImpl ? fetchImpl(url, init) : stream();
    } });
  await listenForFetch(server);
  const base = `http://127.0.0.1:${server.address().port}`;
  t.after(async () => { await server.shutdown(); await fs.rm(stateDir, { recursive: true, force: true }); });
  const request = (mode, body, ip = '8.8.8.8') => fetch(base + '/api/public/' + mode, {
    method: body === undefined ? 'GET' : 'POST',
    headers: { Origin: SITE, 'X-Real-IP': ip, ...(body === undefined ? {} : { 'Content-Type': 'application/json' }) },
    ...(body === undefined ? {} : { body: JSON.stringify(body) })
  });
  const quotaFile = path.join(stateDir, 'quota.json');
  const seed = async (count, perIp, otherIps = {}) => {
    const salt = createHmac('sha256', TOKEN).update('blog-ai-public-quota-v1').digest();
    const hash = createHmac('sha256', salt).update(DAY + '\0' + '8.8.8.8').digest('hex');
    const publicIps = { ...otherIps, ...(perIp ? { [hash]: perIp } : {}) };
    await fs.writeFile(quotaFile, JSON.stringify({ version: 2, days: { [DAY]: count }, publicIps: { [DAY]: publicIps } }));
  };
  return { request, calls, stateDir, quotaFile, seed };
}

test('owner limits accept safe positive integers and provider token range without changing defaults', () => {
  for (const value of [1, 101, 1001, 1_000_001, MAX]) {
    const config = validateConfig({ adminToken: TOKEN, dailyRequestLimit: value, publicPerIpDailyLimit: value });
    assert.equal(config.dailyRequestLimit, value); assert.equal(config.publicPerIpDailyLimit, value);
  }
  for (const value of [1, 63, 2049, 4096, 8192, 393216]) {
    assert.equal(validateConfig({ adminToken: TOKEN, maxOutputTokens: value }).maxOutputTokens, value);
  }
  for (const key of ['dailyRequestLimit', 'publicPerIpDailyLimit', 'maxOutputTokens']) {
    for (const value of [0, -1, 1.1, true, null, '500', NaN, Infinity, MAX + 1,
      ...(key === 'maxOutputTokens' ? [393217] : [])]) {
      assert.throws(() => validateConfig({ adminToken: TOKEN, [key]: value }), /^Error: INVALID_CONFIG$/);
    }
  }
  const defaults = validateConfig({ adminToken: TOKEN });
  assert.equal(defaults.dailyRequestLimit, 20); assert.equal(defaults.publicPerIpDailyLimit, 5);
  assert.equal(defaults.maxOutputTokens, 1024); assert.equal(defaults.maxConcurrent, 2);
  assert.equal(defaults.publicEnabled, false);
  const existing = validateConfig({ adminToken: TOKEN, dailyRequestLimit: 500, publicPerIpDailyLimit: 30, maxOutputTokens: 2048 });
  assert.equal(existing.dailyRequestLimit, 500); assert.equal(existing.publicPerIpDailyLimit, 30);
  assert.equal(existing.maxOutputTokens, 2048);
});

test('public status exposes exact chosen limits and bounded transport, never secrets or money controls', async t => {
  const f = await fixture(t, { dailyRequestLimit: 25000, publicPerIpDailyLimit: 1500, maxOutputTokens: 8192 });
  const value = await (await f.request('status')).json();
  assert.deepEqual(value.limits, { daily: 25000, perIpDaily: 1500, maxOutputTokens: 8192 });
  assert.deepEqual(value.transport, { maxResponseBytes: 524288, maxAnswerChars: 65536, timeoutMs: 60000, workshopInputChars: 3200 });
  assert.equal(value.features.workshop, true);
  assert.doesNotMatch(JSON.stringify(value), /test-free-limits|apiKey|adminToken|monthly|budget|yuan|balance/);
  assert.equal(f.calls.length, 0);
  const high = await fixture(t, { maxOutputTokens: 393216 });
  const highStatus = await (await high.request('status')).json();
  assert.equal(highStatus.transport.maxResponseBytes, 25165824);
  assert.equal(highStatus.transport.maxAnswerChars, 3145728);
});

test('chat/explain/workshop pass chosen output tokens to the fixed provider without public clamping', async t => {
  const f = await fixture(t, { maxOutputTokens: 8192 }, (_url, init) => {
    const json = JSON.parse(init.body);
    return json.response_format ? stream(JSON.stringify({ title: '短文', summary: '概要', cards: [], actions: [], memory: '' })) : stream();
  });
  for (const [mode, body] of [['chat', { question: '测试' }], ['explain', { text: '测试' }],
    ['workshop', { kind: 'story', input: '写一个场景' }]]) {
    const output = await (await f.request(mode, body)).text();
    assert.match(output, /event: done/); assert.doesNotMatch(output, /event: error/);
    assert.equal(f.calls.at(-1).body.max_tokens, 8192);
    assert.deepEqual(f.calls.at(-1).body.thinking, { type: 'disabled' });
    assert.equal(f.calls.at(-1).url, 'https://api.deepseek.com/chat/completions');
  }
});

test('large saved counts pass old artificial ceilings and keep both quotas enforced', async t => {
  const f = await fixture(t, { dailyRequestLimit: 1_000_002, publicPerIpDailyLimit: 5002 });
  await f.seed(1_000_000, 5000);
  for (let i = 0; i < 2; i++) assert.match(await (await f.request('chat', { question: '继续' })).text(), /event: done/);
  const response = await f.request('chat', { question: '额度已用完' });
  assert.equal(response.status, 429); assert.equal((await response.json()).error.code, 'DAILY_LIMIT');
  const state = JSON.parse(await fs.readFile(f.quotaFile, 'utf8'));
  assert.equal(state.days[DAY], 1_000_002); assert.equal(Object.values(state.publicIps[DAY])[0], 5002);
  const perIp = await fixture(t, { dailyRequestLimit: 10000, publicPerIpDailyLimit: 1001 });
  await perIp.seed(2000, 1001);
  assert.equal((await (await perIp.request('chat', { question: '同一IP' })).json()).error.code, 'IP_DAILY_LIMIT');
  assert.match(await (await perIp.request('chat', { question: '另一IP' }, '1.1.1.1')).text(), /event: done/);
});

test('max-safe counters stop exactly at chosen quota and cannot overflow or reset', async t => {
  const f = await fixture(t, { dailyRequestLimit: MAX, publicPerIpDailyLimit: MAX });
  await f.seed(MAX - 1, MAX - 1);
  assert.match(await (await f.request('chat', { question: '最后一次' })).text(), /event: done/);
  assert.equal((await (await f.request('chat', { question: '不能溢出' })).json()).error.code, 'DAILY_LIMIT');
  assert.equal(JSON.parse(await fs.readFile(f.quotaFile, 'utf8')).days[DAY], MAX);
  assert.equal(f.calls.length, 1);
});

test('IP storage capacity fails before persistence without poisoning existing visitor counters', async t => {
  const f = await fixture(t, { dailyRequestLimit: 20000, publicPerIpDailyLimit: 500 });
  const ips = Object.fromEntries(Array.from({ length: 4095 }, (_, i) => [i.toString(16).padStart(64, '0'), 1]));
  await f.seed(4096, 1, ips);
  const before = await fs.readFile(f.quotaFile, 'utf8');
  assert.equal((await (await f.request('chat', { question: '新访客' }, '1.1.1.1')).json()).error.code, 'STATE_UNAVAILABLE');
  assert.equal(await fs.readFile(f.quotaFile, 'utf8'), before);
  assert.match(await (await f.request('chat', { question: '已有访客' })).text(), /event: done/);
  assert.equal(f.calls.length, 1);
});

test('alert thresholds use exact arithmetic at large safe-integer limits', async t => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'blog-ai-free-alerts-'));
  t.after(() => fs.rm(dir, { recursive: true, force: true }));
  const events = [];
  const notify = createUsageAlerts(dir, { now: () => NOW, sink: value => events.push(value) });
  const threshold = Number((BigInt(MAX) * 80n + 99n) / 100n);
  await notify({ day: DAY, used: threshold - 1, limit: MAX });
  assert.equal(events.length, 0);
  await notify({ day: DAY, used: threshold, limit: MAX });
  assert.deepEqual(events.map(value => value.threshold), [80]);
  await notify({ day: DAY, used: MAX, limit: MAX });
  assert.deepEqual(events.map(value => value.threshold), [80, 95, 100]);
});

test('larger configured output streams beyond old total bounds while frames and runaway output stay bounded', async t => {
  // Tiny provider chunks exceed the previous 1MiB upstream total legitimately.
  const answer = '春'.repeat(70000);
  const f = await fixture(t, { maxOutputTokens: 32768 }, () => stream(answer, 2));
  const output = await (await f.request('chat', { question: '较长内容' })).text();
  assert.ok(Buffer.byteLength(output) > 1048576);
  assert.match(output, /event: done/); assert.doesNotMatch(output, /event: error/);
  const deltas = [...output.matchAll(/event: delta\ndata: (.*)\n/g)].map(match => JSON.parse(match[1]).text).join('');
  assert.equal(deltas, answer);
  const blocked = await fixture(t, { maxOutputTokens: 4096 }, () => stream('x'.repeat(70000)));
  const tooLong = await (await blocked.request('chat', { question: '失控上游' })).text();
  assert.match(tooLong, /OUTPUT_LIMIT/); assert.doesNotMatch(tooLong, /event: done/);
});

test('workshop permits a valid larger card set but keeps schema, buffering and truncation safeguards', async () => {
  const result = { title: '场景', summary: '总结', cards: Array.from({ length: 8 }, (_, i) => ({
    title: '卡片' + i, text: '春'.repeat(2400), tag: '虚构', sourceIds: [], quotes: []
  })), actions: [], memory: '' };
  const text = JSON.stringify(result);
  assert.ok(Buffer.byteLength(text) > 48 * 1024);
  const seen = [];
  const receive = workshopEvents(async (...args) => seen.push(args), [], 'story', '场景');
  for (let index = 0; index < text.length; index += 1000) await receive('delta', { text: text.slice(index, index + 1000) });
  assert.equal(seen.length, 0);
  await receive('done', { truncated: false });
  assert.deepEqual(seen[0], ['result', result]);
  const tooBig = workshopEvents(async () => assert.fail('no partial results'), [], 'story', '场景');
  await assert.rejects(tooBig('delta', { text: 'x'.repeat(128 * 1024 + 1) }), /OUTPUT_LIMIT/);
});
