import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import test from 'node:test';
import { setTimeout as delay } from 'node:timers/promises';
import { createAiServer, validateConfig } from '../src/service.mjs';
import { listenForFetch } from './listen-test.mjs';

const SITE = 'https://blog.example.com';
const TOKEN = 'continuous-review-admin-token-not-real-0123456789';
const KEY = 'sk-continuous-review-mock-key-not-real';
const START = Date.UTC(2026, 8, 15, 4);
const DAY = 86400000;
const CATALOG = {
  version: 1, generatedAt: '2026-09-15T04:00:00Z', site: SITE, playlists: [],
  articles: [{ id: '42', title: '公开文章', path: '/posts/42/', url: SITE + '/posts/42/',
    excerpt: '公开内容摘要', text: '公开文章的正文用于隔离测试。', tags: [], categories: [] }],
};
const CONTINUOUS = {
  publicEnabled: true, publicContinuous: true, publicUntil: 0,
  dailyRequestLimit: 500, publicPerIpDailyLimit: 30,
};

function upstream() {
  return new Response('data: {"choices":[{"delta":{"content":"模拟答案"}}]}\n\n'
    + 'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
  { headers: { 'Content-Type': 'text/event-stream' } });
}

function ipHash(ip, day = '2026-09-15') {
  const salt = createHmac('sha256', TOKEN).update('blog-ai-public-quota-v1').digest();
  return createHmac('sha256', salt).update(day + '\0' + ip).digest('hex');
}

async function fixture(t, initial = CONTINUOUS, options = {}) {
  const parent = path.resolve(tmpdir());
  const stateDir = await mkdtemp(path.join(parent, 'blog-ai-continuous-review-'));
  let clock = START, server, base;
  const calls = [];
  let current = { adminToken: TOKEN, apiKey: KEY, ...initial };
  const start = async patch => {
    if (server) await server.shutdown();
    current = { ...current, ...patch };
    server = createAiServer(current, {
      stateDir, knowledge: CATALOG, now: () => clock,
      fetchImpl: async (url, init) => {
        calls.push({ url, init });
        return options.fetchImpl ? options.fetchImpl(url, init) : upstream();
      },
    });
    await listenForFetch(server);
    base = 'http://127.0.0.1:' + server.address().port;
  };
  t.after(async () => {
    if (server) await server.shutdown();
    assert.equal(path.dirname(path.resolve(stateDir)), parent);
    assert.ok(path.basename(stateDir).startsWith('blog-ai-continuous-review-'));
    await rm(stateDir, { recursive: true, force: true });
  });
  await start();
  return {
    calls, stateDir, restart: start, advance: ms => { clock += ms; },
    request: (route, body, headers = {}) => fetch(base + route, {
      method: body === undefined ? 'GET' : 'POST',
      headers: { Origin: SITE, 'X-Real-IP': '8.8.8.8',
        ...(body === undefined ? {} : { 'Content-Type': 'application/json' }), ...headers },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    }),
    state: async () => JSON.parse(await readFile(path.join(stateDir, 'quota.json'), 'utf8')),
    seed: async value => writeFile(path.join(stateDir, 'quota.json'), JSON.stringify(value), { mode: 0o600 }),
  };
}

async function explain(f, headers) {
  const response = await f.request('/api/public/explain', { text: '用户主动选择的测试文字' }, headers);
  const body = await response.text();
  return { status: response.status, body };
}

test('continuous access is never implicitly enabled in default or legacy configuration', async t => {
  const defaults = validateConfig({ adminToken: TOKEN });
  assert.equal(defaults.publicEnabled, false);
  assert.equal(defaults.publicContinuous, false);
  assert.equal(defaults.publicUntil, 0);
  const f = await fixture(t, {});
  const status = await (await f.request('/api/public/status')).json();
  assert.equal(status.enabled, false);
  assert.equal(status.continuous, false);
  assert.equal((await explain(f)).status, 503);
  await f.restart({ publicEnabled: true });
  const legacy = await explain(f);
  assert.equal(legacy.status, 503);
  assert.match(legacy.body, /PUBLIC_DISABLED/);
  assert.equal(f.calls.length, 0);
  await assert.rejects(f.state(), { code: 'ENOENT' });
});

test('explicit continuous mode remains available beyond seven days and after restart', async t => {
  const f = await fixture(t);
  const first = await explain(f);
  assert.equal(first.status, 200);
  assert.match(first.body, /event: done/);
  f.advance(8 * DAY);
  let status = await (await f.request('/api/public/status')).json();
  assert.equal(status.enabled, true);
  assert.equal(status.continuous, true);
  assert.equal(status.expiresAt, null);
  const second = await explain(f);
  assert.equal(second.status, 200);
  assert.match(second.body, /event: done/);
  await f.restart();
  status = await (await f.request('/api/public/status')).json();
  assert.equal(status.enabled, true);
  assert.equal((await explain(f)).status, 200);
  assert.equal(f.calls.length, 3);
  const state = await f.state();
  assert.equal(state.days['2026-09-15'], 1);
  assert.equal(state.days['2026-09-23'], 2);
});

test('master disable, missing key and private paid lease still fail closed in continuous mode', async t => {
  const f = await fixture(t, { ...CONTINUOUS, publicEnabled: false });
  const disabled = await explain(f);
  assert.equal(disabled.status, 503);
  assert.match(disabled.body, /PUBLIC_DISABLED/);
  assert.equal((await (await f.request('/api/public/status')).json()).enabled, false);
  await f.restart({ publicEnabled: true, apiKey: '' });
  const noKey = await explain(f);
  assert.equal(noKey.status, 503);
  assert.match(noKey.body, /AI_NOT_CONFIGURED/);
  assert.equal((await (await f.request('/api/public/status')).json()).available, false);
  await f.restart({ apiKey: KEY });
  const privateCall = await f.request('/api/explain', { text: 'Private endpoint' }, { Authorization: 'Bearer ' + TOKEN });
  assert.equal(privateCall.status, 503);
  assert.match(await privateCall.text(), /AI_DISABLED/);
  assert.equal(f.calls.length, 0);
  await assert.rejects(f.state(), { code: 'ENOENT' });
});

test('continuous flag is strictly boolean and cannot be combined with a lease timestamp', () => {
  for (const publicContinuous of ['true', 1, null, {}, []]) {
    assert.throws(() => validateConfig({ adminToken: TOKEN, publicContinuous }), /INVALID_CONFIG/);
  }
  for (const publicUntil of [1, START + DAY, -1, '0', Infinity]) {
    assert.throws(() => validateConfig({ adminToken: TOKEN, ...CONTINUOUS, publicUntil }), /INVALID_CONFIG/);
  }
  assert.equal(validateConfig({ adminToken: TOKEN, ...CONTINUOUS, publicEnabled: false }).publicContinuous, true);
  for (const patch of [{ dailyRequestLimit: Number.MAX_SAFE_INTEGER + 1 }, { publicPerIpDailyLimit: Number.MAX_SAFE_INTEGER + 1 },
    { dailyRequestLimit: 500.5 }, { publicPerIpDailyLimit: 0 }]) {
    assert.throws(() => validateConfig({ adminToken: TOKEN, ...CONTINUOUS, ...patch }), /INVALID_CONFIG/);
  }
  assert.throws(() => createAiServer({ adminToken: TOKEN, publicEnabled: true, publicUntil: START + 8 * DAY },
    { now: () => START, fetchImpl: () => assert.fail('must not call a model') }), /INVALID_PUBLIC_LEASE/);
});

test('ordinary seven-day mode still expires and switching from continuous does not bypass it', async t => {
  const f = await fixture(t);
  await f.restart({ publicContinuous: false, publicUntil: START + 7 * DAY });
  assert.equal((await explain(f)).status, 200);
  f.advance(7 * DAY);
  const status = await (await f.request('/api/public/status')).json();
  assert.equal(status.continuous, false);
  assert.equal(status.enabled, false);
  assert.equal(status.expiresAt, START + 7 * DAY);
  const expired = await explain(f);
  assert.equal(expired.status, 503);
  assert.match(expired.body, /PUBLIC_DISABLED/);
  assert.equal(f.calls.length, 1);
});

test('continuous stream uses request timeout, not the zero publicUntil timestamp', async t => {
  const f = await fixture(t, { ...CONTINUOUS, requestTimeoutMs: 1000 }, {
    fetchImpl: async (_url, init) => {
      await delay(75);
      assert.equal(init.signal.aborted, false, 'publicUntil=0 must not create a 1 ms timeout');
      return upstream();
    },
  });
  const response = await explain(f);
  assert.equal(response.status, 200);
  assert.match(response.body, /模拟答案/);
  assert.match(response.body, /event: done/);
  assert.doesNotMatch(response.body, /UPSTREAM_TIMEOUT/);
});

test('continuous mode still cancels a stalled upstream and retains its reserved charge', async t => {
  const f = await fixture(t, { ...CONTINUOUS, requestTimeoutMs: 1000 }, {
    fetchImpl: async () => new Promise(() => {}),
  });
  const response = await explain(f);
  assert.equal(response.status, 504);
  assert.match(response.body, /UPSTREAM_TIMEOUT/);
  assert.equal(f.calls[0].init.signal.aborted, true);
  assert.equal((await f.state()).days['2026-09-15'], 1);
});

test('500 global and 30 per-IP budgets are exposed safely and enforced after limit changes and restarts', async t => {
  const f = await fixture(t, { ...CONTINUOUS, dailyRequestLimit: 50, publicPerIpDailyLimit: 10 });
  const hash = ipHash('8.8.8.8');
  await f.seed({ version: 2, days: { '2026-09-15': 50 }, publicIps: { '2026-09-15': { [hash]: 10 } } });
  await f.restart({ dailyRequestLimit: 500, publicPerIpDailyLimit: 30 });
  const status = await (await f.request('/api/public/status')).json();
  assert.deepEqual(status.limits, { daily: 500, perIpDaily: 30, maxOutputTokens: 1024 });
  assert.doesNotMatch(JSON.stringify(status), new RegExp(KEY + '|' + TOKEN));
  assert.equal((await f.state()).days['2026-09-15'], 50);
  for (let i = 0; i < 20; i++) {
    if (i && i % 5 === 0) f.advance(60001); // daily-budget test, not a short-burst bypass
    assert.equal((await explain(f)).status, 200);
  }
  let state = await f.state();
  assert.equal(state.days['2026-09-15'], 70);
  assert.equal(state.publicIps['2026-09-15'][hash], 30);
  await f.restart();
  const blocked = await explain(f);
  assert.equal(blocked.status, 429);
  assert.match(blocked.body, /IP_DAILY_LIMIT/);
  assert.equal((await explain(f, { 'X-Real-IP': '1.1.1.1' })).status, 200);
  state = await f.state();
  assert.equal(state.days['2026-09-15'], 71);
  assert.equal(state.publicIps['2026-09-15'][hash], 30);
  assert.equal(f.calls.length, 21);
  assert.doesNotMatch(JSON.stringify(state), /8\.8\.8\.8|1\.1\.1\.1|用户主动|sk-continuous/);
});

test('500th global call is allowed once and restart cannot restore the exhausted daily budget', async t => {
  const f = await fixture(t);
  await f.seed({ version: 1, days: { '2026-09-15': 499 } });
  assert.equal((await explain(f)).status, 200);
  const saved = await f.state();
  assert.equal(saved.version, 2);
  assert.equal(saved.days['2026-09-15'], 500);
  await f.restart();
  const blocked = await explain(f, { 'X-Real-IP': '1.1.1.1' });
  assert.equal(blocked.status, 429);
  assert.match(blocked.body, /DAILY_LIMIT/);
  assert.deepEqual(await f.state(), saved);
  f.advance(DAY);
  assert.equal((await explain(f)).status, 200);
  assert.equal((await f.state()).days['2026-09-16'], 1);
  assert.equal(f.calls.length, 2);
});

test('corrupt persisted state cannot silently grant fresh continuous-mode quotas', async t => {
  const f = await fixture(t);
  await writeFile(path.join(f.stateDir, 'quota.json'), '{broken', { mode: 0o600 });
  const response = await explain(f);
  assert.equal(response.status, 503);
  assert.match(response.body, /STATE_UNAVAILABLE/);
  assert.equal(f.calls.length, 0);
  assert.equal(await readFile(path.join(f.stateDir, 'quota.json'), 'utf8'), '{broken');
});
