// Windows may allocate an ephemeral port that the Fetch standard intentionally blocks.
// Rebind only the test listener; never retry a model/API request.
const forbidden = new Set([1719, 1720, 1723, 2049, 3659, 4045, 5060, 5061, 6000,
  6566, 6665, 6666, 6667, 6668, 6669, 6697, 10080]);
export async function listenForFetch(server) {
  for (let attempt = 0; attempt < 20; attempt++) {
    await new Promise((resolve, reject) => {
      const failed = error => { server.off('listening', ready); reject(error); };
      const ready = () => { server.off('error', failed); resolve(); };
      server.once('error', failed); server.once('listening', ready);
      server.listen(0, '127.0.0.1');
    });
    const port = server.address().port;
    if (port >= 1024 && !forbidden.has(port)) return;
    await new Promise(resolve => server.close(resolve));
  }
  throw new Error('NO_FETCH_SAFE_TEST_PORT');
}
