import test from 'node:test';
import assert from 'node:assert/strict';
import { workshopPlan, validateWorkshopBody, validateWorkshopResult, workshopEvents, WORKSHOP_KINDS } from '../src/workshop.mjs';

const input = '如果你想换个方向，可以写：主角不碰唱盘，转而检查店内的门、后间或柜台后的帘子，寻找老板的下落，并记录字条缺掉的另一半与空木盒之间可能的关系。';
const result = () => ({ title: '帘子后面的脚步声', summary: '虚构故事续篇。', cards: [{ title: '另一条线索', text: '主角绕过唱盘，在帘子下发现了半张字条。', tag: '虚构', sourceIds: [], quotes: [] }], actions: [], memory: '主角尚未碰唱盘，正在寻找老板。' });
async function accept(value, materials = [], kind = 'story') {
  const events = [];
  const consume = workshopEvents(async (name, data) => events.push({ name, data }), materials, kind, input);
  const raw = typeof value === 'string' ? value : JSON.stringify(value);
  await consume('delta', { text: raw.slice(0, 20) });
  await consume('delta', { text: raw.slice(20) });
  assert.equal(events.length, 0);
  await consume('done', { ok: true, truncated: false });
  assert.deepEqual(events.map(event => event.name), ['result', 'done']);
  return events[0].data;
}
test('reported story continuation is a valid request; no-source prompt must not demonstrate fabricated citations', () => {
  const body = { kind: 'story', input, context: '主角在唱片店看到字条和空木盒。', materials: [] };
  assert.equal(validateWorkshopBody(body, 8000), body);
  const plan = workshopPlan(body);
  assert.match(plan.messages[0].content, /本次没有任何来源材料/);
  assert.match(plan.messages[0].content, /角色台词是虚构情节/);
  assert.doesNotMatch(plan.messages[0].content, /"sourceIds":\["m1"\]/);
  assert.equal(JSON.parse(plan.messages[1].content.slice(10)).input, input);
});
test('all seven kinds accept absent empty optional metadata without changing prose or inventing evidence', async () => {
  for(const kind of WORKSHOP_KINDS) {
    const value = result(); delete value.memory; delete value.actions;
    delete value.cards[0].sourceIds; value.cards[0].quotes = null;
    if(kind === 'clues') value.cards[0].tag = '尚待确认';
    else delete value.cards[0].tag;
    const normalized = await accept(value, [], kind);
    assert.equal(normalized.cards[0].text, value.cards[0].text);
    assert.deepEqual(normalized.cards[0].sourceIds, []); assert.deepEqual(normalized.cards[0].quotes, []);
    assert.equal(normalized.memory, ''); assert.deepEqual(normalized.actions, []);
    assert.equal(validateWorkshopResult(normalized, [], kind, input), normalized);
  }
});
test('complete fenced JSON renders as cards; ordinary or nonstandard text is never discarded', async () => {
  assert.deepEqual(await accept('\ufeff```json\n' + JSON.stringify(result()) + '\n```'), result());
  for(const raw of ['here is the result\n' + JSON.stringify(result()), '{"title":"unfinished', '```json\n{}\n```']) {
    assert.equal((await accept(raw)).rawText, raw);
  }
});
test('source-aware prompts list only actual IDs and distinguish metadata from fictional dialogue', () => {
  const plan = workshopPlan({ kind: 'memoir', input, materials: [{ id: 'm3', title: '', date: '', text: '原文片段。' }] });
  assert.match(plan.messages[0].content, /材料编号仅有：m3/);
  assert.doesNotMatch(plan.messages[0].content, /"sourceIds":\["m1"\]/);
});
test('model citations and dates pass unchanged; nonstandard fields fall back losslessly to text', async () => {
  const material = { id: 'm1', title: '片段', date: '', text: '唱片旋转。' };
  const source = result(); source.cards[0].sourceIds = ['m2'];
  assert.deepEqual((await accept(source)).cards, source.cards);
  const quote = result(); quote.cards[0].sourceIds = ['m1']; quote.cards[0].quotes = [{ sourceId: 'm1', quote: '唱片停止。' }];
  assert.deepEqual((await accept(quote, [material])).cards, quote.cards);
  const date = result(); date.summary = '1999年发生的往事。';
  assert.equal((await accept(date, [], 'memoir')).summary, date.summary);
  assert.equal((await accept({ ...result(), summary: null })).summary, '');
  for(const value of [{ ...result(), unknown: 'extra' }, { ...result(), memory: '字'.repeat(1801) },
    { ...result(), cards: Array(9).fill(result().cards[0]) }]) assert.equal((await accept(value)).rawText, JSON.stringify(value));
});

test('model is asked for fuller content and structured presentation without changing quota/token configuration', () => {
  for(const kind of WORKSHOP_KINDS) {
    const plan = workshopPlan({ kind, input });
    assert.match(plan.messages[0].content, /优先输出一个合法 JSON/);
    assert.match(plan.messages[0].content, /1200至2200字/);
    assert.doesNotMatch(plan.messages[0].content, /每张正文约100至200字/);
  }
});
