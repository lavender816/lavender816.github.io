import test from 'node:test';
import assert from 'node:assert/strict';
import * as fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import net from 'node:net';
import { createAiServer, validateConfig } from '../src/service.mjs';
import { assertConfigPermissions, loadConfig } from '../src/config.mjs';
import { listenForFetch } from './listen-test.mjs';

const TOKEN = 'test-admin-token-0123456789-abcdef';
const API_KEY = 'test-upstream-key-0123456789';
const encoder = new TextEncoder();
const finish = 'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n';

function successStream(text = '你好，测试成功。') {
  return new Response(`data: ${JSON.stringify({ choices: [{ delta: { content: text } }] })}\n\n${finish}`, { headers: { 'Content-Type': 'text/event-stream' } });
}

async function fixture(t, extra = {}, options = {}) {
  const stateDir = await fs.mkdtemp(path.join(os.tmpdir(), 'blog-ai-test-'));
  let clock = Date.UTC(2026, 8, 15, 15, 59);
  const server = createAiServer({ adminToken: TOKEN, ...(extra.paidEnabled ? { paidUntil: clock + 120_000 } : {}), ...extra }, { stateDir, now: () => clock, ...options });
  await listenForFetch(server);
  const url = `http://127.0.0.1:${server.address().port}`;
  t.after(async () => { await server.shutdown(); await fs.rm(stateDir, { recursive: true, force: true }); });
  const request = (route, body, headers = {}) => fetch(url + route, {
    method: body === undefined ? 'GET' : 'POST',
    headers: { Authorization: `Bearer ${TOKEN}`, ...(body === undefined ? {} : { 'Content-Type': 'application/json' }), ...headers },
    ...(body === undefined ? {} : { body: JSON.stringify(body) })
  });
  return { server, url, request, stateDir, advance: (ms = 60_001) => { clock += ms; } };
}

test('config validates fixed destinations, flags, limits and secrets without revealing input', () => {
  assert.equal(validateConfig({ adminToken: TOKEN }).paidEnabled, false);
  for (const patch of [{ adminToken: 'short' }, { apiKey: null },
    { allowedOrigin: '*' }, { upstream: 'https://evil.example' }, { model: 'https://evil.example' }, { maxConcurrent: 3 },
    { dailyRequestLimit: 0 }, { maxOutputTokens: Infinity }, { paidEnabled: 'true' },
    JSON.parse('{"__proto__":{}}')]) {
    assert.throws(() => validateConfig({ adminToken: TOKEN, ...patch }), /^Error: INVALID_CONFIG$/);
  }
});

test('health exposes only readiness; status and mock require authentication', async t => {
  let called = 0;
  const { url, request } = await fixture(t, {}, { fetchImpl: () => { called++; throw new Error(); } });
  assert.deepEqual(await (await fetch(url + '/healthz')).json(), { ok: true });
  const unauth = await fetch(url + '/api/status');
  assert.equal(unauth.status, 401);
  const status = await request('/api/status');
  assert.deepEqual(await status.json(), { configured: false, paidEnabled: false, knowledgeReady: false });
  const response = await request('/api/mock-stream', {});
  assert.equal(response.status, 200);
  const start = performance.now();
  const output = await response.text();
  assert.match(output, /"mock":true[\s\S]*未调用 DeepSeek[\s\S]*event: done/);
  assert.equal(output.match(/event: delta/g).length, 3);
  assert.ok(performance.now() - start >= 180, 'mock chunks should arrive across real intervals');
  assert.equal(called, 0);
});

test('paid endpoints stay disabled by default even with a key; knowledge endpoint is not faked', async t => {
  let called = 0;
  const { request } = await fixture(t, { apiKey: API_KEY }, { fetchImpl: () => { called++; } });
  for (const route of ['/api/explain', '/api/rewrite']) {
    const response = await request(route, { text: '测试' });
    assert.equal(response.status, 503);
    assert.equal((await response.json()).error.code, 'AI_DISABLED');
  }
  const ask = await request('/api/ask', { question: '本站有哪些文章' });
  assert.equal((await ask.json()).error.code, 'KNOWLEDGE_NOT_READY');
  assert.equal(called, 0);
});

test('rejects unsafe bodies, modes, origins, content types and query tokens', async t => {
  const { url, request, advance } = await fixture(t);
  for (const value of [null, [], { text: 'ok', model: 'x' }, { text: 'ok', mode: 'other' },
    { text: '' }, { text: 'x'.repeat(8001) }, JSON.parse('{"text":"x","__proto__":{}}')]) {
    const response = await request('/api/rewrite', value);
    assert.equal(response.status, 400);
  }
  assert.equal((await request('/api/mock-stream', {}, { 'Content-Type': 'text/plain' })).status, 415);
  assert.equal((await request('/api/status', undefined, { Origin: 'https://evil.example' })).status, 403);
  assert.equal((await fetch(url + `/api/status?token=${TOKEN}`)).status, 404);
  advance();
  const preflight = await fetch(url + '/api/explain', { method: 'OPTIONS', headers: { Origin: 'https://blog.example.com', 'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Headers': 'content-type, authorization' } });
  assert.equal(preflight.status, 204);
  assert.equal(preflight.headers.get('access-control-allow-origin'), 'https://blog.example.com');
});

test('duplicate authorization headers are rejected', async t => {
  const { server } = await fixture(t);
  const output = await new Promise((resolve, reject) => {
    let text = '';
    const socket = net.createConnection(server.address().port, '127.0.0.1', () => {
      socket.write(`GET /api/status HTTP/1.1\r\nHost: localhost\r\nAuthorization: Bearer ${TOKEN}\r\nAuthorization: Bearer ${TOKEN}\r\nConnection: close\r\n\r\n`);
    });
    socket.on('data', data => { text += data; }); socket.on('end', () => resolve(text)); socket.on('error', reject);
  });
  assert.match(output, /401 Unauthorized/);
});

test('separate global rate budgets resist forged forwarded IPs and invalid-token denial of service', async t => {
  const { request, advance } = await fixture(t);
  for (let i = 0; i < 10; i++) assert.equal((await request('/api/status', undefined, { Authorization: 'Bearer wrong', 'X-Forwarded-For': `192.0.2.${i}` })).status, 401);
  assert.equal((await request('/api/status', undefined, { Authorization: 'Bearer wrong' })).status, 429);
  for (let i = 0; i < 10; i++) assert.equal((await request('/api/status')).status, 200);
  assert.equal((await request('/api/status')).status, 429);
  advance();
  assert.equal((await request('/api/status')).status, 200);
});

test('paid SSE keeps fixed upstream, supports UTF8 half-packets and excludes reasoning', async t => {
  let observed;
  const input = `: keepalive\r\ndata: ${JSON.stringify({ choices: [{ delta: { reasoning_content: 'PRIVATE_REASON', content: '你好😀' } }] })}\r\n\r\n${finish}`;
  const bytes = encoder.encode(input);
  const { request, stateDir } = await fixture(t, { paidEnabled: true, apiKey: API_KEY }, { fetchImpl: async (url, init) => {
    observed = { url, init };
    const stream = new ReadableStream({ start(controller) { for (const byte of bytes) controller.enqueue(new Uint8Array([byte])); controller.close(); } });
    return new Response(stream, { headers: { 'Content-Type': 'text/event-stream; charset=utf-8' } });
  } });
  const response = await request('/api/explain', { text: 'console.log(1)', instruction: '解释下' });
  const text = await response.text();
  assert.equal(response.status, 200);
  assert.match(text, /你好😀/); assert.match(text, /event: done/); assert.doesNotMatch(text, /PRIVATE_REASON/);
  assert.equal(observed.url, 'https://api.deepseek.com/chat/completions');
  assert.equal(observed.init.redirect, 'error');
  const payload = JSON.parse(observed.init.body);
  assert.deepEqual(payload.thinking, { type: 'disabled' }); assert.equal(payload.model, 'deepseek-flash');
  assert.equal(payload.tools, undefined); assert.equal(payload.max_tokens, 1024);
  assert.deepEqual(JSON.parse(await fs.readFile(path.join(stateDir, 'quota.json'), 'utf8')).days, { '2026-09-15': 1 });
});

test('abnormal provider EOF is an error, never a successful done', async t => {
  const { request } = await fixture(t, { paidEnabled: true, apiKey: API_KEY }, { fetchImpl: async () => new Response('data: {"choices":[{"delta":{"content":"一半"}}]}\n\n', { headers: { 'Content-Type': 'text/event-stream' } }) });
  const text = await (await request('/api/rewrite', { text: '改写内容' })).text();
  assert.match(text, /UPSTREAM_INCOMPLETE/); assert.doesNotMatch(text, /event: done/);
});

test('provider errors are sanitized and attempts remain counted', async t => {
  const { request, stateDir } = await fixture(t, { paidEnabled: true, apiKey: API_KEY }, { fetchImpl: async () => new Response(`secret ${API_KEY}`, { status: 401 }) });
  const response = await request('/api/explain', { text: 'test' });
  assert.equal(response.status, 502);
  assert.deepEqual(await response.json(), { error: { code: 'UPSTREAM_REJECTED' } });
  assert.equal(JSON.parse(await fs.readFile(path.join(stateDir, 'quota.json'), 'utf8')).days['2026-09-15'], 1);
});

test('daily limits persist across restarts and reset at China midnight', async t => {
  let calls = 0;
  const fetchImpl = async () => { calls++; return successStream(); };
  const first = await fixture(t, { paidEnabled: true, apiKey: API_KEY, dailyRequestLimit: 1 }, { fetchImpl });
  assert.match(await (await first.request('/api/explain', { text: 'one' })).text(), /event: done/);
  assert.equal((await first.request('/api/explain', { text: 'two' })).status, 429);
  const second = await fixture(t, { paidEnabled: true, apiKey: API_KEY, dailyRequestLimit: 1 }, { fetchImpl, stateDir: first.stateDir });
  assert.equal((await second.request('/api/rewrite', { text: 'three' })).status, 429);
  second.advance(60_001);
  assert.match(await (await second.request('/api/rewrite', { text: 'tomorrow' })).text(), /event: done/);
  assert.equal(calls, 2);
});

test('quota cannot be bypassed by simultaneous requests', async t => {
  let calls = 0;
  const { request } = await fixture(t, { paidEnabled: true, apiKey: API_KEY, dailyRequestLimit: 1 }, { fetchImpl: async () => { calls++; return successStream(); } });
  const responses = await Promise.all([request('/api/explain', { text: 'a' }), request('/api/explain', { text: 'b' })]);
  assert.deepEqual(responses.map(item => item.status).sort(), [200, 429]);
  await Promise.all(responses.map(item => item.text())); assert.equal(calls, 1);
});

test('invalid or unwritable quota state fails closed without calling provider', async t => {
  let calls = 0;
  const { request, stateDir } = await fixture(t, { paidEnabled: true, apiKey: API_KEY }, { fetchImpl: async () => { calls++; return successStream(); } });
  await fs.writeFile(path.join(stateDir, 'quota.json'), '{"corrupt":true}');
  const response = await request('/api/explain', { text: 'test' });
  assert.equal(response.status, 503); assert.equal((await response.json()).error.code, 'STATE_UNAVAILABLE'); assert.equal(calls, 0);
});

test('client disconnection cancels upstream and releases concurrency; normal POST end does not cancel', async t => {
  const signals = [];
  const { request } = await fixture(t, { paidEnabled: true, apiKey: API_KEY, maxConcurrent: 1 }, { fetchImpl: async (_url, init) => {
    signals.push(init.signal);
    return new Response(new ReadableStream({ start(controller) { controller.enqueue(encoder.encode('data: {"choices":[{"delta":{"content":"开始"}}]}\n\n')); } }), { headers: { 'Content-Type': 'text/event-stream' } });
  } });
  const first = await request('/api/explain', { text: 'normal body end' });
  const reader = first.body.getReader();
  await reader.read();
  assert.equal(signals[0].aborted, false);
  assert.equal((await request('/api/explain', { text: 'busy' })).status, 429);
  await reader.cancel();
  for (let i = 0; i < 30 && !signals[0].aborted; i++) await new Promise(resolve => setTimeout(resolve, 10));
  assert.equal(signals[0].aborted, true);
  const second = await request('/api/explain', { text: 'released' });
  assert.equal(second.status, 200); await second.body.cancel();
});

test('timeout cancels hanging upstream and does not leak exception text', async t => {
  let signal;
  const { request } = await fixture(t, { paidEnabled: true, apiKey: API_KEY, requestTimeoutMs: 1000 }, { fetchImpl: async (_url, init) => { signal = init.signal; return new Promise(() => {}); } });
  const response = await request('/api/explain', { text: 'time out' });
  assert.equal(response.status, 504); assert.equal((await response.json()).error.code, 'UPSTREAM_TIMEOUT'); assert.equal(signal.aborted, true);
});

test('upstream output is bounded even when it ignores requested max_tokens', async t => {
  const frame = `data: ${JSON.stringify({ choices: [{ delta: { content: 'x'.repeat(40_000) } }] })}\n\n`;
  const { request } = await fixture(t, { paidEnabled: true, apiKey: API_KEY }, { fetchImpl: async () => new Response(frame + frame + finish, { headers: { 'Content-Type': 'text/event-stream' } }) });
  const text = await (await request('/api/explain', { text: 'bounded' })).text();
  assert.match(text, /OUTPUT_LIMIT/); assert.doesNotMatch(text, /event: done/); assert.ok(Buffer.byteLength(text) < 66000);
});

test('paid lease is mandatory, bounded and rechecked after expiry', async t => {
  let calls = 0;
  const fetchImpl = async () => { calls++; return successStream(); };
  const f = await fixture(t, { paidEnabled: true, apiKey: API_KEY }, { fetchImpl });
  assert.equal((await f.request('/api/status')).status, 200);
  f.advance(120_001);
  assert.equal((await (await f.request('/api/status')).json()).paidEnabled, false);
  const response = await f.request('/api/explain', { text: 'expired' });
  assert.equal(response.status, 503); assert.equal((await response.json()).error.code, 'AI_DISABLED');
  const missing = await fixture(t, { paidEnabled: true, paidUntil: 0, apiKey: API_KEY }, { fetchImpl });
  assert.equal((await missing.request('/api/rewrite', { text: 'missing' })).status, 503);
  assert.equal(calls, 0);
  assert.throws(() => createAiServer({ adminToken: TOKEN, paidUntil: Date.now() + 600_000 }), /INVALID_PAID_LEASE/);
});

test('upstream total byte cap includes comments and omitted provider metadata', async t => {
  const { request } = await fixture(t, { paidEnabled: true, apiKey: API_KEY }, { fetchImpl: async () => new Response(new ReadableStream({
    start(controller) {
      for (let i = 0; i < 22; i++) controller.enqueue(encoder.encode(`:${'x'.repeat(50_000)}\n`));
      controller.enqueue(encoder.encode(finish)); controller.close();
    }
  }), { headers: { 'Content-Type': 'text/event-stream' } }) });
  const text = await (await request('/api/explain', { text: 'bounded total traffic' })).text();
  assert.match(text, /UPSTREAM_LIMIT/); assert.doesNotMatch(text, /event: done/); assert.ok(text.length < 1000);
});

test('mock streaming cancellation releases the concurrency slot and pending delay', async t => {
  const { request } = await fixture(t, { maxConcurrent: 1 });
  const first = await request('/api/mock-stream', {});
  await first.body.cancel();
  await new Promise(resolve => setTimeout(resolve, 30));
  const second = await request('/api/mock-stream', {});
  assert.equal(second.status, 200); assert.match(await second.text(), /event: done/);
});

test('systemd root-owned ACL credentials accept 0440 only in a trusted read-only directory', () => {
  const directory = { mode: 0o40550, uid: 0, gid: 0, isDirectory: () => true, isSymbolicLink: () => false };
  const file = { mode: 0o100440, uid: 0, gid: 0, size: 334, isFile: () => true };
  const options = { systemd: true, directory, uid: 999, gid: 988 };
  assert.doesNotThrow(() => assertConfigPermissions(file, options));
  assert.doesNotThrow(() => assertConfigPermissions({ ...file, uid: 999, gid: 988, mode: 0o100400 }, options));
  for (const patch of [{ mode: 0o100444 }, { mode: 0o100640 }, { mode: 0o100450 }, { mode: 0o104440 },
    { uid: 1234 }, { gid: 1234 }, { size: 16385 }, { isFile: () => false }]) {
    assert.throws(() => assertConfigPermissions({ ...file, ...patch }, options), /CONFIG_PERMISSIONS/);
  }
  for (const patch of [{ mode: 0o40750 }, { mode: 0o40555 }, { mode: 0o42750 }, { mode: 0o40570 },
    { uid: 1234 }, { gid: 1234 }, { isDirectory: () => false }, { isSymbolicLink: () => true }]) {
    assert.throws(() => assertConfigPermissions(file, { ...options, directory: { ...directory, ...patch } }), /CONFIG_PERMISSIONS/);
  }
});

test('manual config keeps strict 0600 or 0400 and cannot inherit the systemd 0440 exception', () => {
  const file = { mode: 0o100600, size: 200, isFile: () => true };
  assert.doesNotThrow(() => assertConfigPermissions(file));
  assert.doesNotThrow(() => assertConfigPermissions({ ...file, mode: 0o100400 }));
  for (const mode of [0o440, 0o640, 0o644, 0o700, 0o4600]) {
    assert.throws(() => assertConfigPermissions({ ...file, mode }), /CONFIG_PERMISSIONS/);
  }
});

test('loadConfig reads explicit private JSON without exposing failures or falling back to credentials', async t => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'blog-ai-config-test-'));
  t.after(() => fs.rm(dir, { recursive: true, force: true }));
  const file = path.join(dir, 'private.json');
  await fs.writeFile(file, JSON.stringify({ adminToken: TOKEN }), { mode: 0o600 });
  assert.deepEqual(await loadConfig({ AI_CONFIG_FILE: file, CREDENTIALS_DIRECTORY: 'not-used' }), { adminToken: TOKEN });
  await fs.writeFile(file, `{"secret":"${API_KEY}"`);
  await assert.rejects(loadConfig({ AI_CONFIG_FILE: file }), /^Error: CONFIG_UNAVAILABLE$/);
  await assert.rejects(loadConfig({ AI_CONFIG_FILE: path.join(dir, 'missing'), CREDENTIALS_DIRECTORY: dir }), /^Error: CONFIG_UNAVAILABLE$/);
  await assert.rejects(loadConfig({ AI_CONFIG_FILE: 'relative.json' }), /^Error: CONFIG_UNAVAILABLE$/);
});

test('Linux credential integration accepts read-only credential mount shape without weakening explicit paths', { skip: process.platform !== 'linux' }, async t => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'blog-ai-systemd-test-'));
  t.after(async () => { await fs.chmod(dir, 0o700); await fs.rm(dir, { recursive: true, force: true }); });
  const file = path.join(dir, 'ai-config');
  await fs.writeFile(file, JSON.stringify({ adminToken: TOKEN }), { mode: 0o440 });
  await fs.chmod(file, 0o440); await fs.chmod(dir, 0o550);
  assert.deepEqual(await loadConfig({ CREDENTIALS_DIRECTORY: dir }), { adminToken: TOKEN });
  await assert.rejects(loadConfig({ AI_CONFIG_FILE: file, CREDENTIALS_DIRECTORY: dir }), /CONFIG_UNAVAILABLE/);
  await fs.chmod(dir, 0o750);
  await assert.rejects(loadConfig({ CREDENTIALS_DIRECTORY: dir }), /CONFIG_UNAVAILABLE/);
});
