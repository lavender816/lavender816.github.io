import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import test from 'node:test';
import { createAiServer } from '../src/service.mjs';
import { listenForFetch } from './listen-test.mjs';

const TOKEN = 'independent-review-token-0123456789abcdef';
const API_KEY = 'sk-independent-review-placeholder-not-a-real-key';
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function temporaryState(t) {
  const parent = path.resolve(tmpdir());
  const directory = await mkdtemp(path.join(parent, 'blog-ai-review-'));
  t.after(async () => {
    assert.equal(path.dirname(path.resolve(directory)), parent);
    assert.ok(path.basename(directory).startsWith('blog-ai-review-'));
    await rm(directory, { recursive: true, force: true });
  });
  return directory;
}

async function start(t, config = {}, dependencies = {}) {
  const clock = dependencies.now ?? Date.now;
  const server = await createAiServer({
    adminToken: TOKEN,
    ...(config.paidEnabled ? { paidUntil: clock() + 120_000 } : {}),
    ...config,
  }, dependencies);
  await listenForFetch(server);
  t.after(async () => { if (server.listening) await server.shutdown(); });
  const url = `http://127.0.0.1:${server.address().port}`;
  const post = (route, body = { text: '本地安全回归测试' }, headers = {}, options = {}) =>
    fetch(`${url}${route}`, {
      method: 'POST',
      headers: { authorization: `Bearer ${TOKEN}`, 'content-type': 'application/json', ...headers },
      body: JSON.stringify(body),
      ...options,
    });
  return { server, url, post };
}

function successfulProvider() {
  return new Response('data: {"choices":[{"delta":{"content":"仅测试"}}]}\n\ndata: [DONE]\n\n', {
    headers: { 'content-type': 'text/event-stream' },
  });
}

test('security: disabled paid routes and unready knowledge never call an upstream', async (t) => {
  let called = 0;
  const service = await start(t, { apiKey: API_KEY }, {
    fetchImpl: async () => { called += 1; throw new Error('unexpected upstream call'); },
  });
  for (const endpoint of ['/api/explain', '/api/rewrite', '/api/ask']) {
    const response = await service.post(endpoint, endpoint === '/api/ask' ? { question: '测试问题' } : undefined);
    assert.equal(response.status, 503);
    assert.doesNotMatch(await response.text(), new RegExp(`${TOKEN}|${API_KEY}`));
  }
  assert.equal(called, 0);
});

test('security: malformed credentials, query tokens and unknown fields cannot reach a provider', async (t) => {
  let called = 0;
  const stateDir = await temporaryState(t);
  const service = await start(t, { paidEnabled: true, apiKey: API_KEY }, {
    stateDir,
    fetchImpl: async () => { called += 1; return successfulProvider(); },
  });
  for (const authorization of ['', 'Bearer wrong', `Bearer ${TOKEN}, Bearer ${TOKEN}`]) {
    const response = await service.post('/api/explain', undefined, { authorization });
    assert.equal(response.status, 401);
    await response.arrayBuffer();
  }
  const queryToken = await service.post(`/api/explain?token=${TOKEN}`, undefined, { authorization: '' });
  assert.ok(queryToken.status >= 400 && queryToken.status < 500);
  await queryToken.arrayBuffer();
  for (const additional of [{ base_url: 'http://169.254.169.254/' }, { model: 'arbitrary-model' }, { tools: [] }]) {
    const response = await service.post('/api/explain', { text: 'test', ...additional });
    assert.ok(response.status >= 400 && response.status < 500);
    await response.arrayBuffer();
  }
  assert.equal(called, 0);
});

test('security: response metadata and mock stream do not disclose credentials or call a provider', async (t) => {
  let called = 0;
  const service = await start(t, { apiKey: API_KEY }, {
    fetchImpl: async () => { called += 1; return successfulProvider(); },
  });
  for (const endpoint of ['/healthz', '/api/status']) {
    const response = await fetch(`${service.url}${endpoint}`, { headers: { authorization: `Bearer ${TOKEN}` } });
    assert.equal(response.status, 200);
    assert.doesNotMatch(await response.text(), new RegExp(`${TOKEN}|${API_KEY}`));
  }
  const mock = await service.post('/api/mock-stream', {});
  assert.equal(mock.status, 200);
  assert.match(mock.headers.get('content-type'), /text\/event-stream/);
  assert.match(mock.headers.get('cache-control'), /no-store/);
  const body = await mock.text();
  assert.doesNotMatch(body, new RegExp(`${TOKEN}|${API_KEY}`));
  assert.ok(body.length > 0);
  assert.equal(called, 0);
});

test('security: a completed POST body does not abort SSE, but closing its response aborts upstream work', async (t) => {
  const stateDir = await temporaryState(t);
  let upstreamSignal;
  const service = await start(t, { paidEnabled: true, apiKey: API_KEY }, {
    stateDir,
    fetchImpl: async (_url, init) => {
      upstreamSignal = init.signal;
      return new Response(new ReadableStream({
        start(controller) {
          controller.enqueue(new TextEncoder().encode('data: {"choices":[{"delta":{"content":"第一段"}}]}\n\n'));
          init.signal.addEventListener('abort', () => {
            try { controller.error(new DOMException('Aborted', 'AbortError')); } catch {}
          }, { once: true });
        },
      }), { headers: { 'content-type': 'text/event-stream' } });
    },
  });
  const client = new AbortController();
  const response = await service.post('/api/explain', undefined, {}, { signal: client.signal });
  assert.equal(response.status, 200);
  const reader = response.body.getReader();
  assert.equal((await reader.read()).done, false);
  await sleep(30);
  assert.equal(upstreamSignal.aborted, false, 'normal request-body completion must not cancel generation');
  client.abort();
  await reader.cancel().catch(() => {});
  for (let attempt = 0; attempt < 50 && !upstreamSignal.aborted; attempt += 1) await sleep(10);
  assert.equal(upstreamSignal.aborted, true, 'client response disconnection must cancel the provider request');
});

test('security: prepaid daily request quota survives a service restart', async (t) => {
  const stateDir = await temporaryState(t);
  let called = 0;
  const config = { paidEnabled: true, apiKey: API_KEY, dailyRequestLimit: 1 };
  const dependencies = { stateDir, fetchImpl: async () => { called += 1; return successfulProvider(); } };
  const first = await start(t, config, dependencies);
  const accepted = await first.post('/api/explain');
  assert.equal(accepted.status, 200);
  await accepted.text();
  await first.server.shutdown();
  const second = await start(t, config, dependencies);
  const rejected = await second.post('/api/explain');
  assert.equal(rejected.status, 429);
  await rejected.text();
  assert.equal(called, 1);
  const quota = await readFile(path.join(stateDir, 'quota.json'), 'utf8');
  assert.doesNotMatch(quota, new RegExp(`${TOKEN}|${API_KEY}`));
});

test('security: concurrent requests cannot both spend the final daily quota slot', async (t) => {
  const stateDir = await temporaryState(t);
  let called = 0;
  const service = await start(t, { paidEnabled: true, apiKey: API_KEY, dailyRequestLimit: 1 }, {
    stateDir,
    fetchImpl: async () => { called += 1; await sleep(30); return successfulProvider(); },
  });
  const responses = await Promise.all([service.post('/api/explain'), service.post('/api/explain')]);
  assert.deepEqual(responses.map((item) => item.status).sort(), [200, 429]);
  await Promise.all(responses.map((item) => item.text()));
  assert.equal(called, 1);
});

test('security: corrupt persisted quota fails closed instead of resetting spend', async (t) => {
  const stateDir = await temporaryState(t);
  await writeFile(path.join(stateDir, 'quota.json'), '{ damaged persisted state', { mode: 0o600 });
  let called = 0;
  let service;
  try {
    service = await start(t, { paidEnabled: true, apiKey: API_KEY }, {
      stateDir,
      fetchImpl: async () => { called += 1; return successfulProvider(); },
    });
  } catch {
    assert.equal(called, 0);
    return;
  }
  const response = await service.post('/api/explain');
  assert.ok(response.status >= 500);
  await response.text();
  assert.equal(called, 0);
});

test('security: hostile origins and oversized input are rejected before an upstream call', async (t) => {
  const stateDir = await temporaryState(t);
  let called = 0;
  const service = await start(t, { paidEnabled: true, apiKey: API_KEY }, {
    stateDir,
    fetchImpl: async () => { called += 1; return successfulProvider(); },
  });
  for (const origin of ['null', 'https://evil.example', 'https://blog.example.com.evil.example']) {
    const response = await service.post('/api/explain', undefined, { origin });
    assert.equal(response.status, 403);
    await response.text();
  }
  const oversized = await service.post('/api/explain', { text: '水'.repeat(20_000) });
  assert.equal(oversized.status, 413);
  await oversized.text();
  assert.equal(called, 0);
});

test('security: an expired paid lease blocks calls and stays expired after restarting', async (t) => {
  const stateDir = await temporaryState(t);
  let time = Date.parse('2026-09-15T15:59:00Z');
  let called = 0;
  const config = { paidEnabled: true, paidUntil: time + 1000, apiKey: API_KEY };
  const dependencies = {
    stateDir,
    now: () => time,
    fetchImpl: async () => { called += 1; return successfulProvider(); },
  };
  const first = await start(t, config, dependencies);
  time += 1001;
  const expired = await first.post('/api/explain');
  assert.equal(expired.status, 503);
  await expired.text();
  await first.server.shutdown();
  const second = await start(t, config, dependencies);
  const stillExpired = await second.post('/api/explain');
  assert.equal(stillExpired.status, 503);
  await stillExpired.text();
  assert.equal(called, 0);
});

test('security: invalid credential flooding cannot exhaust the legitimate private-token rate limit', async (t) => {
  const service = await start(t, {}, { fetchImpl: async () => { throw new Error('unexpected upstream call'); } });
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const response = await fetch(`${service.url}/api/status`, { headers: { authorization: 'Bearer invalid-credential-0123456789abcdef' } });
    assert.ok([401, 429].includes(response.status));
    await response.text();
  }
  const legitimate = await fetch(`${service.url}/api/status`, { headers: { authorization: `Bearer ${TOKEN}` } });
  assert.equal(legitimate.status, 200);
  await legitimate.text();
});
