import test from 'node:test';
import assert from 'node:assert/strict';
import * as fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createAiServer, validateConfig } from '../src/service.mjs';
import { listenForFetch } from './listen-test.mjs';

const token = 'test-admin-token-0123456789-abcdef';

test('stored model IDs are syntax-bounded; owner command verifies live catalog before saving', () => {
  for (const model of ['deepseek-flash', 'deepseek-v4-pro', 'deepseek-future-5']) {
    assert.equal(validateConfig({ adminToken: token, model }).model, model);
  }
  for (const model of ['https://evil.example', 'bad model', 'bad\n', '../escape', null, 'x'.repeat(129)]) {
    assert.throws(() => validateConfig({ adminToken: token, model }), /INVALID_CONFIG/);
  }
  assert.equal(validateConfig({ adminToken: token, requestTimeoutMs: 120000 }).requestTimeoutMs, 120000);
  assert.throws(() => validateConfig({ adminToken: token, requestTimeoutMs: 120001 }), /INVALID_CONFIG/);
  assert.throws(() => validateConfig({ adminToken: token, publicPerIpMinuteLimit: 6, challengeAfterRequests: 6 }), /INVALID_CONFIG/);
});

test('private owner status shows selected controls while public status omits them', async t => {
  const stateDir = await fs.mkdtemp(path.join(os.tmpdir(), 'blog-controls-'));
  const server = createAiServer({ adminToken: token, model: 'deepseek-v4-pro',
    publicEnabled: true, publicContinuous: true, requestTimeoutMs: 120000,
    publicPerIpMinuteLimit: 20, challengeAfterRequests: 10, maxConcurrent: 1,
    maxInputChars: 12000 }, { stateDir });
  await listenForFetch(server);
  t.after(async () => { await server.shutdown(); await fs.rm(stateDir, { recursive: true, force: true }); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const privateStatus = await (await fetch(base + '/api/status', { headers: { Authorization: `Bearer ${token}` } })).json();
  assert.deepEqual(privateStatus.controls, { model: 'deepseek-v4-pro', maxConcurrent: 1, maxInputChars: 12000 });
  assert.equal(privateStatus.protection.perIpMinute, 20);
  assert.equal(privateStatus.protection.challengeAfterRequests, 10);
  assert.equal(privateStatus.public.transport.timeoutMs, 120000);
  const publicStatus = await (await fetch(base + '/api/public/status')).json();
  assert.equal(publicStatus.transport.timeoutMs, 120000);
  assert.equal('controls' in publicStatus, false);
  assert.equal('model' in publicStatus, false);
});
