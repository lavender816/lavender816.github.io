import test from 'node:test';
import assert from 'node:assert/strict';
import * as fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { createAiServer, validateConfig } from '../src/service.mjs';
import { createAbuseGuard } from '../src/abuse.mjs';
import { createUsageAlerts } from '../src/usage-alerts.mjs';
import { listenForFetch } from './listen-test.mjs';

const ORIGIN = 'https://blog.example.com';
const TOKEN = 'test-abuse-owner-token-0123456789-secret';
const KEY = 'sk-abuse-test-not-a-real-model-key';
const CAPTCHA = { provider: 'tencent', appId: '123456789', appSecretKey: 'test-app-secret-0123456789',
  secretId: 'test-cam-secret-id-0123456789', secretKey: 'test-cam-secret-key-0123456789' };
const payload = { text: '仅在隔离环境里验证安全控制' };
const stream = () => new Response('data: {"choices":[{"delta":{"content":"模拟回答"}}]}\n\ndata: [DONE]\n\n',
  { headers: { 'Content-Type': 'text/event-stream' } });

async function fixture(t, config = {}, overrides = {}) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'ai-abuse-test-'));
  let now = Date.UTC(2026, 8, 19, 4), calls = [], validations = [], alerts = [];
  const server = createAiServer({ adminToken: TOKEN, apiKey: KEY, publicEnabled: true,
    publicContinuous: true, dailyRequestLimit: 500, publicPerIpDailyLimit: 30, ...config }, {
    stateDir: dir, now: () => now, alertSink: event => alerts.push(event),
    fetchImpl: async (url, init) => { calls.push({ url, init }); return stream(); },
    captchaFetchImpl: async (url, init) => { validations.push({ url, init }); return Response.json({ Response: { CaptchaCode: 1, EvilLevel: 0 } }); },
    ...overrides
  });
  await listenForFetch(server);
  t.after(async () => { await server.shutdown(); assert.equal(path.dirname(dir), path.resolve(os.tmpdir())); await fs.rm(dir, { recursive: true, force: true }); });
  const base = 'http://127.0.0.1:' + server.address().port;
  return { base, dir, calls, validations, alerts, advance: ms => { now += ms; },
    async post(body = payload, ip = '8.8.8.8', mode = 'explain') {
      const response = await fetch(base + '/api/public/' + mode, { method: 'POST',
        headers: { Origin: ORIGIN, 'X-Real-IP': ip, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const text = await response.text();
      return { status: response.status, text, data: response.ok ? null : JSON.parse(text), retryAfter: response.headers.get('Retry-After') };
    }
  };
}

test('public flood is isolated by IP, cooldown expires, and neither spoofed XFF nor admin traffic shares the bucket', async t => {
  const f = await fixture(t);
  for (let i = 0; i < 5; i++) assert.equal((await f.post()).status, 200);
  for (let i = 0; i < 35; i++) assert.equal((await f.post()).status, 429);
  assert.equal(f.calls.length, 5);
  assert.equal((await f.post(payload, '1.1.1.1')).status, 200);
  const owner = await fetch(f.base + '/api/status', { headers: { Authorization: 'Bearer ' + TOKEN } });
  assert.equal(owner.status, 200);
  f.advance(60001); assert.equal((await f.post()).status, 200);
});

test('one IP cannot occupy both global generation slots; other IP can still generate', async t => {
  let started, release;
  const ready = new Promise(resolve => { started = resolve; });
  const held = new Promise(resolve => { release = resolve; });
  let count = 0;
  const f = await fixture(t, {}, { fetchImpl: async () => { if (++count === 1) { started(); await held; } return stream(); } });
  const first = f.post(); await ready;
  try {
    const blocked = await f.post(); assert.equal(blocked.data.error.code, 'IP_CONCURRENT_LIMIT');
    assert.equal((await f.post(payload, '1.1.1.1')).status, 200);
  } finally { release(); await first; }
  assert.equal((await f.post()).status, 200);
});

test('no-CAPTCHA mode cools repeated invalid input without verification charges or quota writes', async t => {
  const f = await fixture(t);
  for (let i = 0; i < 3; i++) assert.equal((await f.post({ text: 'x', model: 'forbidden' })).status, 400);
  const denied = await f.post();
  assert.equal(denied.status, 429);
  assert.equal(denied.data.error.code, 'ABUSE_COOLDOWN');
  assert.equal(f.calls.length, 0);
  assert.equal(f.validations.length, 0);
  await assert.rejects(fs.stat(path.join(f.dir, 'quota.json')), { code: 'ENOENT' });
  assert.equal((await f.post(payload, '1.1.1.1')).status, 200);
  f.advance(600001);
  assert.equal((await f.post()).status, 200);
  assert.equal(f.validations.length, 0);
});

test('adaptive CAPTCHA challenge is before spending; ticket only authorizes the bound request', async t => {
  const f = await fixture(t, { captcha: CAPTCHA, challengeAfterRequests: 2 });
  assert.equal((await f.post()).status, 200);
  const required = await f.post(); assert.equal(required.status, 403);
  const challenge = required.data.error.challenge;
  assert.deepEqual([challenge.provider, challenge.appId], ['tencent', CAPTCHA.appId]);
  assert.doesNotMatch(required.text, /appSecretKey|secretKey|secretId|sk-abuse|8\.8\.8\.8/);
  assert.equal(f.calls.length, 1); assert.equal(f.validations.length, 0);
  const verification = { challenge: challenge.challenge, ticket: 'test-single-use-ticket-123', randstr: '@TEST' };
  assert.equal((await f.post({ ...payload, verification })).status, 200);
  assert.equal(f.calls.length, 2); assert.equal(f.validations.length, 1);
  assert.equal(f.validations[0].url, 'https://captcha.tencentcloudapi.com/');
  assert.equal(f.validations[0].init.redirect, 'error');
  const checked = JSON.parse(f.validations[0].init.body);
  assert.equal(checked.UserIp, '8.8.8.8'); assert.equal(checked.CaptchaType, 9);
  assert.match(f.validations[0].init.headers.Authorization, /^TC3-HMAC-SHA256 Credential=.*\/captcha\/tc3_request, SignedHeaders=content-type;host, Signature=[a-f0-9]{64}$/);
  assert.doesNotMatch(f.calls[1].init.body, /verification|test-single-use-ticket|test-app-secret|test-cam-secret/);
  assert.equal((await f.post({ ...payload, verification })).data.error.code, 'CAPTCHA_INVALID');
  assert.equal(f.calls.length, 2); assert.equal(f.validations.length, 1);
});

test('forged, expired, wrong-IP, wrong-body, wrong-route and fallback tickets fail before verification/model', async t => {
  const f = await fixture(t, { captcha: CAPTCHA, challengeAfterRequests: 2 });
  await f.post(); const challenge = (await f.post()).data.error.challenge.challenge;
  const verification = { challenge, ticket: 'mock-captcha-ticket-123', randstr: '@TEST' };
  for (const [body, ip, mode] of [
    [{ ...payload, verification: { ...verification, challenge: 'forged.invalid' } }],
    [{ ...payload, verification }, '1.1.1.1'],
    [{ text: 'another question', verification }],
    [{ question: 'different route', verification }, '8.8.8.8', 'chat'],
    [{ ...payload, verification: { ...verification, ticket: 'trerror_bypass_is_forbidden' } }]
  ]) assert.equal((await f.post(body, ip, mode)).data.error.code, 'CAPTCHA_INVALID');
  f.advance(180001);
  assert.equal((await f.post({ ...payload, verification })).data.error.code, 'CAPTCHA_INVALID');
  assert.equal(f.calls.length, 1); assert.equal(f.validations.length, 0);
});

test('CAPTCHA errors never fail open or expose provider credentials/errors', async t => {
  for (const result of [() => Response.json({ Response: { CaptchaCode: 21 } }),
    () => Response.json({ Response: { CaptchaCode: 1, EvilLevel: 100 } }),
    () => Response.json({ Response: { Error: { Message: CAPTCHA.secretKey } } }),
    () => { throw new Error(CAPTCHA.secretKey); }]) {
    const f = await fixture(t, { captcha: CAPTCHA, challengeAfterRequests: 2 }, { captchaFetchImpl: result });
    await f.post(); const challenge = (await f.post()).data.error.challenge.challenge;
    const rejected = await f.post({ ...payload, verification: { challenge, ticket: 'mock-captcha-ticket-test', randstr: '@T' } });
    assert.ok([403, 503].includes(rejected.status)); assert.doesNotMatch(rejected.text, new RegExp(CAPTCHA.secretKey));
    assert.equal(f.calls.length, 1);
  }
});

test('a verified human still obeys persistent daily budgets and never receives an extra allowance', async t => {
  const f = await fixture(t, { captcha: CAPTCHA, challengeAfterRequests: 2, publicPerIpDailyLimit: 1 });
  await f.post(); const challenge = (await f.post()).data.error.challenge.challenge;
  const denied = await f.post({ ...payload, verification: { challenge, ticket: 'mock-captcha-ticket-test', randstr: '@T' } });
  assert.equal(denied.data.error.code, 'IP_DAILY_LIMIT'); assert.equal(f.calls.length, 1);
  const quota = JSON.parse(await fs.readFile(path.join(f.dir, 'quota.json'), 'utf8'));
  assert.equal(quota.days['2026-09-19'], 1);
});

test('repeated malformed input triggers human verification without blocking unrelated IPs', async t => {
  const f = await fixture(t, { captcha: CAPTCHA });
  for (let i = 0; i < 3; i++) assert.equal((await f.post({ text: 'x', model: 'forbidden' })).status, 400);
  assert.equal((await f.post()).data.error.code, 'CAPTCHA_REQUIRED');
  assert.equal(f.calls.length, 0); assert.equal((await f.post(payload, '1.1.1.1')).status, 200);
});

test('abuse memory is bounded, active identities are not evicted, and released entries expire', () => {
  let time = 1_000_000;
  const guard = createAbuseGuard(validateConfig({ adminToken: TOKEN }), { now: () => time });
  const held = guard.enter('held');
  for (let i = 0; i < 4095; i++) guard.enter(String(i)).release();
  assert.throws(() => guard.enter('new'), /ABUSE_CAPACITY/);
  time += 601000; guard.enter('new').release();
  assert.throws(() => guard.enter('held'), /IP_CONCURRENT_LIMIT/);
  held.release(); held.release(); guard.enter('held').release();
});

test('usage alerts persist and deduplicate across restart; quota file format stays compatible', async t => {
  const f = await fixture(t, { dailyRequestLimit: 20 });
  await fs.writeFile(path.join(f.dir, 'quota.json'), JSON.stringify({ version: 1, days: { '2026-09-19': 15 } }));
  await f.post(); assert.deepEqual(f.alerts.map(e => e.threshold), [80]);
  f.advance(60001);
  for (let i = 0; i < 4; i++) await f.post();
  assert.deepEqual(f.alerts.map(e => e.threshold), [80, 95, 100]);
  assert.equal((await f.post(payload, '1.1.1.1')).data.error.code, 'DAILY_LIMIT');
  const restarted = createUsageAlerts(f.dir, { sink: event => f.alerts.push(event) });
  await restarted({ day: '2026-09-19', used: 20, limit: 20 });
  assert.equal(f.alerts.length, 3);
  const ledger = await fs.readFile(path.join(f.dir, 'usage-alerts.json'), 'utf8');
  assert.doesNotMatch(ledger, /8\.8\.8\.8|隔离环境|adminToken|apiKey|secret/);
  const quota = JSON.parse(await fs.readFile(path.join(f.dir, 'quota.json'), 'utf8'));
  assert.deepEqual(Object.keys(quota).sort(), ['days', 'publicIps', 'version']);
  await restarted({ day: '2026-09-20', used: 16, limit: 20 }); assert.equal(f.alerts.length, 4);
});

test('invalid security configuration is rejected without echoing any private value', () => {
  for (const patch of [{ publicPerIpMinuteLimit: 0 }, { challengeAfterRequests: 99 },
    { captcha: { ...CAPTCHA, endpoint: 'https://evil.example' } }, { captcha: { ...CAPTCHA, secretKey: '' } }]) {
    assert.throws(() => validateConfig({ adminToken: TOKEN, ...patch }), /^Error: INVALID_CONFIG$/);
  }
});

test('global minute/hour admission spans different IPs and denied requests spend neither quota nor model calls', async t => {
  const f = await fixture(t, { publicGlobalMinuteLimit: 2, publicGlobalHourLimit: 3 });
  for(const ip of ['8.8.8.8', '1.1.1.1']) assert.equal((await f.post(payload, ip)).status, 200);
  const denied = await f.post(payload, '9.9.9.9');
  assert.equal(denied.status, 429);
  assert.equal(denied.data.error.code, 'GLOBAL_RATE_LIMIT');
  assert.equal(denied.retryAfter, '60');
  assert.equal(f.calls.length, 2);
  let quota = JSON.parse(await fs.readFile(path.join(f.dir, 'quota.json'), 'utf8'));
  assert.equal(quota.days['2026-09-19'], 2);
  f.advance(60001);
  assert.equal((await f.post(payload, '9.9.9.9')).status, 200);
  const hourly = await f.post({ question: '正常的另一个问题' }, '8.8.4.4', 'chat');
  assert.equal(hourly.data.error.code, 'GLOBAL_RATE_LIMIT');
  assert.equal(Number(hourly.retryAfter), 3540);
  quota = JSON.parse(await fs.readFile(path.join(f.dir, 'quota.json'), 'utf8'));
  assert.equal(quota.days['2026-09-19'], 3);
  assert.equal(f.calls.length, 3);
  f.advance(3_600_000);
  assert.equal((await f.post(payload, '8.8.4.4')).status, 200);
});

test('a rejected IP daily reservation releases its temporary global admission, without disabling unrelated visitors', async t => {
  const f = await fixture(t, { publicGlobalMinuteLimit: 1, publicPerIpDailyLimit: 1 });
  assert.equal((await f.post()).status, 200);
  f.advance(60001);
  assert.equal((await f.post()).data.error.code, 'IP_DAILY_LIMIT');
  assert.equal((await f.post(payload, '1.1.1.1')).status, 200);
  assert.equal(f.calls.length, 2);
});

test('parallel different-IP requests cannot race the global admission and shared waits report the longer boundary', async t => {
  let started, release, calls = 0;
  const ready = new Promise(resolve => { started = resolve; });
  const held = new Promise(resolve => { release = resolve; });
  const f = await fixture(t, { publicGlobalMinuteLimit: 1, publicGlobalHourLimit: 1 }, {
    fetchImpl: async () => { calls++; started(); await held; return stream(); }
  });
  const first = f.post(); await ready;
  try {
    const blocked = await f.post(payload, '1.1.1.1');
    assert.equal(blocked.data.error.code, 'GLOBAL_RATE_LIMIT');
    assert.equal(blocked.retryAfter, '3600', 'retry must wait for both minute and hour boundaries');
    assert.equal(calls, 1);
  } finally { release(); assert.equal((await first).status, 200); }
  const quota = JSON.parse(await fs.readFile(path.join(f.dir, 'quota.json'), 'utf8'));
  assert.equal(quota.days['2026-09-19'], 1);
});

test('global reservations are synchronous, cancel idempotently and expire at rolling boundaries', () => {
  let time = 100_000;
  const guard = createAbuseGuard(validateConfig({ adminToken: TOKEN, publicGlobalMinuteLimit: 1, publicGlobalHourLimit: 2 }), { now: () => time });
  const pending = guard.reserveGlobal();
  assert.throws(() => guard.reserveGlobal(), /GLOBAL_RATE_LIMIT/);
  pending.cancel(); pending.cancel();
  guard.reserveGlobal();
  time += 60_000;
  guard.reserveGlobal();
  time += 60_000;
  assert.throws(() => guard.reserveGlobal(), /GLOBAL_RATE_LIMIT/);
  time += 3_600_000;
  guard.reserveGlobal();
  for(const field of ['publicGlobalMinuteLimit', 'publicGlobalHourLimit']) {
    for(const value of [0, -1, NaN, Infinity, 1.5, '20', true, Number.MAX_SAFE_INTEGER + 1]) {
      assert.throws(() => validateConfig({ adminToken: TOKEN, [field]: value }), /INVALID_CONFIG/);
    }
  }
});
