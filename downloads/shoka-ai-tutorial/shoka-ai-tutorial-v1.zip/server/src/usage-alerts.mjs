import * as fs from 'node:fs/promises';
import { constants } from 'node:fs';
import { randomUUID } from 'node:crypto';
import path from 'node:path';

// Separate from quota.json so rollback cannot invalidate or reset paid counters.
// A bounded local alert ledger survives restarts; no user data or secrets are logged.
export function createUsageAlerts(stateDir, { sink = () => {}, now = Date.now } = {}) {
  let queue = Promise.resolve(), lastFailure = -Infinity;
  async function observe({ day, used, limit }) {
    let temporary;
    try {
      const file = path.join(stateDir, 'usage-alerts.json');
      let state = { version: 1, events: [] }, handle;
      try {
        handle = await fs.open(file, constants.O_RDONLY | (constants.O_NOFOLLOW || 0));
        const stat = await handle.stat();
        if (!stat.isFile() || stat.size > 32768) throw new Error();
        state = JSON.parse(await handle.readFile('utf8'));
        if (state.version !== 1 || !Array.isArray(state.events) || state.events.length > 100
            || state.events.some(event => !/^\d{4}-\d{2}-\d{2}$/.test(event.day) || ![80, 95, 100].includes(event.threshold)
              || !Number.isSafeInteger(event.used) || event.used < 0 || !Number.isSafeInteger(event.limit) || event.limit < 1
              || typeof event.time !== 'string')) throw new Error();
      } catch (error) { if (error.code !== 'ENOENT') throw error; }
      finally { await handle?.close(); }
      if (!Number.isSafeInteger(used) || used < 0 || !Number.isSafeInteger(limit) || limit < 1) throw new Error();
      const pending = [80, 95, 100].filter(threshold => BigInt(used) * 100n >= BigInt(limit) * BigInt(threshold)
        && !state.events.some(event => event.day === day && event.threshold === threshold));
      if (!pending.length) return;
      const events = pending.map(threshold => ({ day, used, limit, threshold, time: new Date(now()).toISOString() }));
      state.events = state.events.concat(events).slice(-90);
      temporary = path.join(stateDir, '.usage-alert-' + randomUUID() + '.tmp');
      const writer = await fs.open(temporary, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL, 0o600);
      try { await writer.writeFile(JSON.stringify(state)); await writer.sync(); } finally { await writer.close(); }
      await fs.rename(temporary, file); temporary = undefined;
      for (const event of events) sink({ event: 'AI_USAGE_ALERT', ...event });
    } catch {
      // Alert failure must neither refund quota nor leak file/credential contents.
      if (temporary) await fs.unlink(temporary).catch(() => {});
      if (now() - lastFailure >= 60_000) {
        lastFailure = now();
        try { sink({ event: 'AI_USAGE_ALERT_UNAVAILABLE' }); } catch { /* quota remains enforced */ }
      }
    }
  }
  return summary => {
    const next = queue.then(() => observe(summary));
    queue = next.catch(() => {});
    return next;
  };
}
