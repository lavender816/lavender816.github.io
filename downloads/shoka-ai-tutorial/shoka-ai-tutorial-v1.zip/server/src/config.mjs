import * as fs from 'node:fs/promises';
import path from 'node:path';
import { constants } from 'node:fs';

function denied() { throw new Error('CONFIG_PERMISSIONS'); }

/** Check POSIX metadata independently of I/O so systemd ACL layouts can be regression-tested. */
export function assertConfigPermissions(file, { systemd = false, directory, uid, gid } = {}) {
  if (!file.isFile() || file.size > 16_384) denied();
  const mode = file.mode & 0o7777;
  if (!systemd) {
    // A manually supplied source file must never become group-readable merely because
    // systemd's separate, read-only credential mount permits a group/ACL read mask.
    if (mode !== 0o400 && mode !== 0o600) denied();
    return;
  }
  if (!Number.isSafeInteger(uid) || uid < 0 || !Number.isSafeInteger(gid) || gid < 0) denied();
  const trusted = stat => (stat.uid === 0 || stat.uid === uid) && (stat.gid === 0 || stat.gid === gid);
  if (!directory || !directory.isDirectory() || directory.isSymbolicLink() || !trusted(directory) || !trusted(file)) denied();
  const directoryMode = directory.mode & 0o7777;
  // systemd 255 can supply root:root 0550 + an ACL for the service identity.
  // The enclosing mount and the credential must be read-only and inaccessible to "other".
  if ((directoryMode & 0o7227) !== 0 || (directoryMode & 0o500) !== 0o500
      || (mode !== 0o400 && mode !== 0o440)) denied();
}

export async function loadConfig(env = process.env) {
  let handle;
  try {
    const manual = typeof env.AI_CONFIG_FILE === 'string' && env.AI_CONFIG_FILE.length > 0;
    const systemd = !manual;
    const directory = systemd ? env.CREDENTIALS_DIRECTORY : undefined;
    if (systemd && (process.platform !== 'linux' || typeof directory !== 'string' || !path.isAbsolute(directory))) denied();
    const file = manual ? env.AI_CONFIG_FILE : path.join(directory, 'ai-config');
    if (!path.isAbsolute(file)) denied();
    let directoryStat;
    if (systemd) {
      directoryStat = await fs.lstat(directory);
      if (directoryStat.isSymbolicLink() || path.resolve(await fs.realpath(directory)) !== path.resolve(directory)) denied();
    }
    handle = await fs.open(file, constants.O_RDONLY | (constants.O_NOFOLLOW || 0));
    const stat = await handle.stat();
    if (!stat.isFile() || stat.size > 16_384) denied();
    if (process.platform !== 'win32') {
      assertConfigPermissions(stat, { systemd, directory: directoryStat, uid: process.getuid(), gid: process.getgid() });
    }
    if (systemd) {
      // Detect directory substitution between validation and opening the credential.
      const current = await fs.lstat(directory);
      if (current.isSymbolicLink() || current.dev !== directoryStat.dev || current.ino !== directoryStat.ino) denied();
      assertConfigPermissions(stat, { systemd, directory: current, uid: process.getuid(), gid: process.getgid() });
    }
    const text = new TextDecoder('utf-8', { fatal: true }).decode(await handle.readFile());
    return JSON.parse(text);
  } catch {
    // Never propagate a parser snippet, pathname, credential content or OS error text.
    throw new Error('CONFIG_UNAVAILABLE');
  } finally { await handle?.close(); }
}
