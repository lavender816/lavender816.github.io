// Optional self-hosted SearXNG. No arbitrary page fetching, redirects, provider keys or public proxy.
export function externalUrl(value) {
  try {
    if (typeof value !== 'string' || value.length > 1500 || /[\s\u0000-\u001f]/.test(value)) return null;
    const url = new URL(value);
    if (url.protocol !== 'https:' || url.username || url.password || url.port
      || !/^[a-z\d.-]+\.[a-z]{2,}$/i.test(url.hostname)
      || /(?:^|\.)(?:localhost|local|internal|test|invalid)$/i.test(url.hostname)
      || /(?:token|key|secret|password|auth|signature)=/i.test(url.search)) return null;
    return url.href;
  } catch { return null; }
}
const SEARCH_TIMEOUT_MS = 7000;
const MAX_FIELD_CHARS = 8192;

function clean(value, max) {
  if (typeof value !== 'string') return '';
  // Limit raw work BEFORE stripping markup. Each character is scanned at most
  // twice, including a long run of '<' without a closing '>'. No backtracking.
  const input = value.slice(0, MAX_FIELD_CHARS), parts = [];
  let offset = 0;
  while (offset < input.length) {
    const open = input.indexOf('<', offset);
    const close = open < 0 ? -1 : input.indexOf('>', open + 1);
    if (close < 0) { parts.push(input.slice(offset)); break; }
    parts.push(input.slice(offset, open), ' ');
    offset = close + 1;
  }
  return parts.join('').replace(/[\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
}

function raceAbort(promise, signal) {
  return new Promise((resolve, reject) => {
    const cleanup = () => signal.removeEventListener('abort', aborted);
    const aborted = () => { cleanup(); reject(signal.reason); };
    // Always observe the operation, even if it rejects after cancellation.
    Promise.resolve(promise).then(value => { cleanup(); resolve(value); }, error => { cleanup(); reject(error); });
    if (signal.aborted) aborted();
    else signal.addEventListener('abort', aborted, { once: true });
  });
}

function cancelQuietly(stream) {
  // Stream cleanup is best-effort: a broken upstream cancel hook must not keep
  // a request or concurrency slot alive after its deadline/client cancellation.
  try { Promise.resolve(stream?.cancel()).catch(() => {}); } catch {}
}

export function createWebSearch(endpoint, { fetchImpl = globalThis.fetch, now = Date.now,
  monotonicNow = () => performance.now() } = {}) {
  if (!endpoint) return null;
  const url = new URL(endpoint);
  // Only the administrator can configure this fixed loopback service. No DNS rebinding path.
  if (url.protocol !== 'http:' || url.hostname !== '127.0.0.1' || !url.port || url.port === '3001'
    || url.pathname !== '/search' || url.search || url.hash || url.username || url.password) throw new Error('INVALID_SEARCH_ENDPOINT');
  return async (question, signal) => {
    signal.throwIfAborted();
    const deadline = monotonicNow() + SEARCH_TIMEOUT_MS;
    const timeout = new AbortController(), combined = AbortSignal.any([signal, timeout.signal]);
    const expire = () => timeout.abort(new DOMException('Search timed out', 'TimeoutError'));
    const timer = setTimeout(expire, SEARCH_TIMEOUT_MS);
    timer.unref();
    const check = () => {
      signal.throwIfAborted();
      // A timer cannot run during synchronous parsing/cleaning; check elapsed
      // monotonic time too, so late results are never presented as successful.
      if (monotonicNow() >= deadline) expire();
      combined.throwIfAborted();
    };
    let response, reader;
    try {
      // Send only the current query, never article content, conversation history, IP or credentials.
      const query = clean(question, 400).replace(/https?:\/\/\S+|[\w.+-]+@[\w.-]+\.[a-z]+/gi, ' ');
      check();
      const pending = Promise.resolve(fetchImpl(url.href, { method: 'POST', redirect: 'error', signal: combined,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
        body: new URLSearchParams({ q: query, format: 'json', language: 'zh-CN', safesearch: '1', categories: 'general' }).toString() }));
      // A dependency that ignores abort can resolve after we have returned.
      void pending.then(late => { if (combined.aborted) cancelQuietly(late?.body); }, () => {});
      response = await raceAbort(pending, combined);
      check();
      if (!response.ok || !/application\/json/i.test(response.headers.get('content-type') || '')) throw new Error();
      reader = response.body.getReader(); let bytes = 0, raw = ''; const decoder = new TextDecoder();
      while (true) {
        check();
        const part = await raceAbort(reader.read(), combined);
        check();
        if (part.done) break;
        bytes += part.value.length; if (bytes > 262144) throw new Error();
        raw += decoder.decode(part.value, { stream: true });
      }
      raw += decoder.decode();
      const parsed = JSON.parse(raw), results = [], seen = new Set();
      check();
      for (const entry of (Array.isArray(parsed.results) ? parsed.results.slice(0, 30) : [])) {
        check();
        const href = externalUrl(entry.url), title = clean(entry.title, 160), text = clean(entry.content, 800);
        if (!href || !title || !text || seen.has(href)) continue;
        seen.add(href); results.push({ title, url: href, text, kind: 'web', retrievedAt: new Date(now()).toISOString() });
        if (results.length >= 4) break;
      }
      check();
      return { status: results.length ? 'ok' : 'empty', results };
    } catch {
      if (signal.aborted) throw signal.reason;
      return { status: 'unavailable', results: [] };
    } finally {
      clearTimeout(timer);
      cancelQuietly(reader || response?.body);
    }
  };
}
