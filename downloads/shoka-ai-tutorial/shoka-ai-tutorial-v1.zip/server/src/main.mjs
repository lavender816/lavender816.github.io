import { createAiServer } from './service.mjs';
import { loadConfig } from './config.mjs';
import { loadKnowledge } from './knowledge.mjs';

let server;
let stopping = false;

async function stop(code = 0) {
  if (stopping) return;
  stopping = true;
  const deadline = setTimeout(() => process.exit(1), 5000);
  deadline.unref();
  try { await server?.shutdown(); } finally { clearTimeout(deadline); process.exitCode = code; }
}

try {
  const config = await loadConfig();
  let knowledge;
  try { knowledge = await loadKnowledge('/opt/blog-ai/current/data/blog-knowledge.json'); }
  catch { console.info('AI_KNOWLEDGE_UNAVAILABLE'); }
  server = createAiServer(config, { stateDir: process.env.STATE_DIRECTORY || process.env.AI_STATE_DIR, knowledge,
    searchEndpoint: process.env.AI_SEARCH_ENDPOINT || '',
    alertSink: event => console.warn(JSON.stringify(event)) });
  server.on('error', () => { console.error('AI_SERVICE_LISTEN_FAILED'); void stop(1); });
  server.listen(3001, '127.0.0.1', () => console.info('AI_SERVICE_READY'));
  process.once('SIGTERM', () => { void stop(); });
  process.once('SIGINT', () => { void stop(); });
  process.on('unhandledRejection', () => { console.error('AI_SERVICE_UNEXPECTED_FAILURE'); void stop(1); });
  process.on('uncaughtException', () => { console.error('AI_SERVICE_UNEXPECTED_FAILURE'); void stop(1); });
} catch {
  console.error('AI_SERVICE_START_FAILED');
  process.exitCode = 1;
}
