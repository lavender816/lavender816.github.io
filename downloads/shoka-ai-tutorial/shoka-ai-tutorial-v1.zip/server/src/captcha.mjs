import { createHash, createHmac } from 'node:crypto';
import { ServiceError } from './errors.mjs';

const HOST = 'captcha.tencentcloudapi.com';
const hash = value => createHash('sha256').update(value).digest('hex');
const hmac = (key, value) => createHmac('sha256', key).update(value).digest();

// Tencent API 3.0 TC3-HMAC-SHA256. Destination/action/version are not client-controlled.
export function captchaRequest(config, ip, proof, timestamp) {
  const body = JSON.stringify({ CaptchaType: 9, CaptchaAppId: Number(config.appId),
    AppSecretKey: config.appSecretKey, UserIp: ip, Ticket: proof.ticket, Randstr: proof.randstr });
  const date = new Date(timestamp * 1000).toISOString().slice(0, 10);
  const scope = date + '/captcha/tc3_request';
  const canonical = 'POST\n/\n\ncontent-type:application/json\nhost:' + HOST + '\n\ncontent-type;host\n' + hash(body);
  const stringToSign = 'TC3-HMAC-SHA256\n' + timestamp + '\n' + scope + '\n' + hash(canonical);
  const key = hmac(hmac(hmac('TC3' + config.secretKey, date), 'captcha'), 'tc3_request');
  const signature = createHmac('sha256', key).update(stringToSign).digest('hex');
  return { body, headers: { 'Content-Type': 'application/json', 'X-TC-Action': 'DescribeCaptchaResult',
    'X-TC-Version': '2019-07-22', 'X-TC-Timestamp': String(timestamp),
    Authorization: 'TC3-HMAC-SHA256 Credential=' + config.secretId + '/' + scope + ', SignedHeaders=content-type;host, Signature=' + signature } };
}

export function createCaptchaVerifier(config, { fetchImpl = globalThis.fetch, now = Date.now } = {}) {
  let active = 0, attempts = [];
  return async (ip, proof, signal) => {
    attempts = attempts.filter(stamp => stamp > now() - 60_000);
    if (active >= 2 || attempts.length >= 30) throw new ServiceError(503, 'CAPTCHA_BUSY');
    attempts.push(now()); active++;
    const timeout = AbortSignal.timeout(6000), combined = AbortSignal.any([signal, timeout]);
    let response;
    try {
      const request = captchaRequest(config, ip, proof, Math.floor(now() / 1000));
      response = await fetchImpl('https://' + HOST + '/', { ...request, method: 'POST', redirect: 'error', signal: combined });
      if (!response.ok || !response.body || !/^application\/json(?:;|$)/i.test(response.headers.get('content-type') || '')) throw new Error();
      let size = 0;
      const chunks = [];
      for await (const chunk of response.body) {
        size += chunk.length;
        if (size > 16384 || combined.aborted) throw new Error();
        chunks.push(chunk);
      }
      const result = JSON.parse(Buffer.concat(chunks).toString('utf8')).Response;
      if (!result || result.Error) throw new Error();
      if (result.CaptchaCode !== 1 || (result.EvilLevel !== undefined && result.EvilLevel !== 0)) throw new ServiceError(403, 'CAPTCHA_INVALID');
    } catch (error) {
      if (signal.aborted) throw new ServiceError(499, 'CLIENT_CLOSED');
      if (error instanceof ServiceError) throw error;
      throw new ServiceError(503, 'CAPTCHA_UNAVAILABLE');
    } finally {
      active--;
      await response?.body?.cancel().catch(() => {});
    }
  };
}
