import { createHmac, createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { ServiceError } from './errors.mjs';

const WINDOW = 600_000;
const MAX_IDENTITIES = 4096;
const MAX_PROOFS = 4096;
const MAX_GLOBAL_RECORDS = 65536;

// Short-lived, bounded, keyed pseudonyms only. No prompts or raw IPs are retained.
export function createAbuseGuard(config, { now = Date.now } = {}) {
  const clients = new Map(), consumed = new Map();
  let globalAdmissions = [];
  const salt = createHmac('sha256', config.adminToken).update('ai-abuse-v1').digest();
  let sweepAt = 0;
  const sign = value => createHmac('sha256', salt).update(value).digest('base64url');
  const fingerprint = value => createHash('sha256').update(value).digest('hex');
  function sweep(time) {
    if (time < sweepAt) return;
    sweepAt = time + 10_000;
    for (const [key, client] of clients) if (!client.active && client.last <= time - WINDOW) clients.delete(key);
    for (const [key, until] of consumed) if (until <= time) consumed.delete(key);
  }
  function enter(ip) {
    const time = now(); sweep(time);
    const key = sign(ip);
    let client = clients.get(key);
    if (!client) {
      if (clients.size >= MAX_IDENTITIES) throw new ServiceError(503, 'ABUSE_CAPACITY');
      client = { attempts: [], failures: [], active: 0, last: time };
      clients.set(key, client);
    }
    client.last = time;
    client.attempts = client.attempts.filter(stamp => stamp > time - 60_000);
    client.failures = client.failures.filter(stamp => stamp > time - WINDOW);
    if (client.attempts.length >= config.publicPerIpMinuteLimit) throw new ServiceError(429, 'IP_RATE_LIMIT');
    client.attempts.push(time);
    if (client.active >= 1) throw new ServiceError(429, 'IP_CONCURRENT_LIMIT');
    client.active++;
    let released = false;
    return {
      key,
      suspicious: () => client.attempts.length >= config.challengeAfterRequests || client.failures.length >= 3,
      cooldownSeconds: () => client.failures.length >= 3 ? 600 : 60,
      failure() { if (client.failures.length < 20) client.failures.push(now()); },
      release() { if (!released) { released = true; client.active--; } }
    };
  }
  // Admission is shared across IPs and all public model features. A reservation
  // precedes the asynchronous daily ledger, so parallel callers cannot race it.
  // Only quota-accepted attempts remain; rejected daily/IP reservations cancel it.
  function reserveGlobal() {
    const time = now();
    globalAdmissions = globalAdmissions.filter(entry => entry.time > time - 3_600_000);
    const minute = globalAdmissions.filter(entry => entry.time > time - 60_000);
    let wait = 0;
    if(minute.length >= config.publicGlobalMinuteLimit) wait = Math.max(wait, minute[0].time + 60_000 - time);
    if(globalAdmissions.length >= config.publicGlobalHourLimit) wait = Math.max(wait, globalAdmissions[0].time + 3_600_000 - time);
    if(wait > 0) throw new ServiceError(429, 'GLOBAL_RATE_LIMIT', { retryAfter: Math.max(1, Math.ceil(wait / 1000)) });
    if(globalAdmissions.length >= MAX_GLOBAL_RECORDS) throw new ServiceError(503, 'ABUSE_CAPACITY');
    const entry = { time };
    globalAdmissions.push(entry);
    let cancelled = false;
    return { cancel() {
      if(cancelled) return;
      cancelled = true;
      globalAdmissions = globalAdmissions.filter(row => row !== entry);
    } };
  }
  function challenge(client, route, body) {
    const payload = Buffer.from(JSON.stringify({ k: client.key, r: route,
      b: fingerprint(JSON.stringify(body)), exp: now() + 180_000, n: randomBytes(18).toString('base64url') })).toString('base64url');
    return payload + '.' + sign(payload);
  }
  function consume(client, route, body, proof) {
    if (!proof || typeof proof !== 'object' || Array.isArray(proof)
        || Object.keys(proof).some(key => !['challenge', 'ticket', 'randstr'].includes(key))
        || typeof proof.challenge !== 'string' || proof.challenge.length > 1200
        || typeof proof.ticket !== 'string' || !/^[!-~]{10,2048}$/.test(proof.ticket) || proof.ticket.startsWith('trerror')
        || typeof proof.randstr !== 'string' || !/^[!-~]{1,128}$/.test(proof.randstr)) throw new ServiceError(403, 'CAPTCHA_INVALID');
    try {
      const [payload, signature, extra] = proof.challenge.split('.');
      const expected = sign(payload), supplied = Buffer.from(signature || '');
      if (extra || supplied.length !== expected.length || !timingSafeEqual(supplied, Buffer.from(expected))) throw new Error();
      const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
      if (data.k !== client.key || data.r !== route || data.b !== fingerprint(JSON.stringify(body))
          || !Number.isSafeInteger(data.exp) || data.exp <= now() || data.exp > now() + 180_000) throw new Error();
      sweep(now());
      const nonce = fingerprint(proof.challenge), ticket = fingerprint(proof.ticket);
      if (consumed.has(nonce) || consumed.has(ticket)) throw new Error();
      if (consumed.size + 2 > MAX_PROOFS) throw new ServiceError(503, 'ABUSE_CAPACITY');
      // Reserve before ANY asynchronous validation: concurrent replay cannot race.
      consumed.set(nonce, now() + WINDOW); consumed.set(ticket, now() + WINDOW);
    } catch (error) {
      if (error instanceof ServiceError) throw error;
      throw new ServiceError(403, 'CAPTCHA_INVALID');
    }
  }
  return { enter, challenge, consume, reserveGlobal };
}
