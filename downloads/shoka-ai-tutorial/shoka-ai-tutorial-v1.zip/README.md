# Shoka AI 教程配套源码

这不是整个博客，也不是生产配置备份。只包含通用化后的 AI 模块、测试与合并片段。

1. 阅读对应教程，先备份自己的博客。
2. 解压后在本机运行：node configure-examples.mjs https://你的博客域名 https://你的AI域名。只运行一次；换域名时从原压缩包重新解压。
3. server/ 是完整的 Node 服务源码；没有真实密钥、额度文件和站点索引。data/ 仅含空的合法索引。
4. blog/ 中的新增文件按相同目录复制到博客。已经存在的文件需比较合并，不要覆盖。
5. integration/ 里的 js/css/yml 是合并片段，不是直接执行的安装器。ai-entry.js、ai-loader.js、site-control-bridge.js 必须加入主题的 app 构建列表，在同一 IIFE 内运行。config.js 不是有效的独立脚本。
6. 文件顺序：已有工具函数/播放器/搜索/主题代码 → ai-loader → site-control-bridge（仅完成适配后添加）→ ai-entry → 原有 PJAX 初始化。
7. 在首次页面刷新入口调用 initBlogAI() 和 mountAIWorkshop()，不要重复注册 PJAX 监听。
8. 阅读设置、音乐、统计、宇宙是可选前置模块。本包不包含它们的完整实现；按教程暴露窄接口后才有对应控制能力。不支持的操作应报告未接入，不能假装成功。
9. 普通 Shoka 播放器不一定有 tracks/state/playConfirmed/setMode 等接口，请先适配。
10. 默认支持站点根路径 /，文章目录 posts/。部署在子目录或自定义永久链接时，请检查知识索引、控制目录与前端路径校验，不能只改一个 URL。
11. 私钥、API Key、adminToken、config.json、quota.json、真实文章与服务器备份均未包含。
12. 保留上游包的许可证。本教程新增代码仅作学习与按需集成参考；实际公开上线仍需自己的回归与安全检查。
