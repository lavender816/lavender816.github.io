
'use strict';
const { buildCatalog, readRoute } = require('../lib/pageview-catalog.cjs');
const { controlCatalog } = require('../lib/ai-control-catalog.cjs');
hexo.extend.filter.register('after_generate', async function() {
  const catalog = await buildCatalog({ route: hexo.route, posts: hexo.locals.get('posts'), root: hexo.config.root,
    siteTitles: [hexo.config.title, hexo.config.subtitle, hexo.theme.config.alternate] });
  const routes = hexo.route.list();
  const friends = routes.includes('friends/index.html') ? await readRoute(hexo.route.get('friends/index.html')) : '';
  hexo.route.set('ai-control-catalog.json', JSON.stringify(controlCatalog(catalog, routes, friends, hexo.config.root, hexo.locals.get('posts'))));
}, 100);
