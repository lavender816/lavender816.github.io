'use strict';

const { buildTextWorkshopCatalog } = require('../lib/text-workshop-catalog.cjs');

// Build-time data only: no page hook, browser request, backend or private config.
// The archaeology page fetches this route only when its source picker opens.
hexo.extend.generator.register('text-workshop-catalog', function generateTextWorkshopCatalog(locals) {
  const catalog = buildTextWorkshopCatalog({
    posts: locals.posts,
    root: hexo.config.root || '/',
    now: Date.now()
  });
  return [{ path: 'text-workshop-catalog.json', data: JSON.stringify(catalog) }];
});
