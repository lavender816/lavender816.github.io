'use strict';

const { buildKnowledge } = require('../lib/ai-knowledge.cjs');

// This build-time generator exports a deliberately small public allowlist.
// It registers no browser script, network request, render hook or remote API call.
hexo.extend.generator.register('ai-public-knowledge', function generateAiKnowledge(locals) {
  const knowledge = buildKnowledge({
    posts: locals.posts,
    pages: locals.pages,
    root: hexo.config.root || '/',
    now: Date.now()
  });
  return [{ path: 'ai-knowledge.json', data: JSON.stringify(knowledge) }];
});
