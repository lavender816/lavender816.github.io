'use strict';
const path = require('node:path');
const esbuild = require('esbuild');

// Local, fingerprinted optional asset. Loading a normal page does not fetch it.
hexo.extend.generator.register('ai-markdown-assets', async function() {
  const bundle = await esbuild.build({
    entryPoints: [path.join(__dirname, '../lib/ai-markdown.cjs')], bundle: true,
    platform: 'browser', format: 'iife', globalName: 'ShokaAIMarkdown', target: 'es2020',
    minify: true, write: false, legalComments: 'eof'
  });
  return [{ path: 'js/ai-markdown.js', data: bundle.outputFiles[0].text }];
});
