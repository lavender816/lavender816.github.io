---
title: 文字分岔剧场
layout: text-workshop
text_workshop: story
description: 选择、回溯与分岔，一起探索由你决定下一步的互动故事。
comment: false
reading: false
copyright: false
fancybox: false
date: 2026-09-19 12:00:00
---
