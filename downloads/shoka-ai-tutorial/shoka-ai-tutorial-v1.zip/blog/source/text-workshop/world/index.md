---
title: 平行世界档案馆
layout: text-workshop
text_workshop: world
description: 从一个假设开始，建立规则、人物与事件档案，延展属于你的平行世界。
comment: false
reading: false
copyright: false
fancybox: false
date: 2026-09-19 12:00:00
---
