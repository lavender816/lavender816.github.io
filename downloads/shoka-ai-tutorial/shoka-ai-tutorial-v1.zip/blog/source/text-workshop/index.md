---
title: 文字工坊
layout: text-workshop
text_workshop: home
description: 七种 AI 文字玩法，从分岔故事、措辞比较到回忆编织，和文字一起探索下一种可能。
comment: false
reading: false
copyright: false
fancybox: false
date: 2026-09-19 12:00:00
---
