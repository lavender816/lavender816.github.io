---
title: 回忆编织机
layout: text-workshop
text_workshop: memoir
description: 由一个片刻开始，通过追问找回细节，将珍贵回忆织成文字。
comment: false
reading: false
copyright: false
fancybox: false
date: 2026-09-19 12:00:00
---
