---
title: 思想考古
layout: text-workshop
text_workshop: archaeology
description: 带着问题重读旧文字，追踪观念的来路、转折与未完成的思考。
comment: false
reading: false
copyright: false
fancybox: false
date: 2026-09-19 12:00:00
---
