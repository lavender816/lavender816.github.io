---
title: 观点圆桌
layout: text-workshop
text_workshop: roundtable
description: 从多个立场讨论同一个议题，追问分歧，梳理有依据的思考。
comment: false
reading: false
copyright: false
fancybox: false
date: 2026-09-19 12:00:00
---
