---
title: 线索工作台
layout: text-workshop
text_workshop: clues
description: 整理零散材料，区分证据与猜想，让推演可以追溯到原始线索。
comment: false
reading: false
copyright: false
fancybox: false
date: 2026-09-19 12:00:00
---
