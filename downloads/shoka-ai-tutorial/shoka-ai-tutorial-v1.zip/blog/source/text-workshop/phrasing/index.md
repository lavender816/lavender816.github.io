---
title: 措辞试衣间
layout: text-workshop
text_workshop: phrasing
description: 比较同一段话的不同语气，保留本意，找到分寸恰好的表达。
comment: false
reading: false
copyright: false
fancybox: false
date: 2026-09-19 12:00:00
---
