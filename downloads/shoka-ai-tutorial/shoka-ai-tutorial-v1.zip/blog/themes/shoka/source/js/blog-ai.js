(function() {
  'use strict';
  // Lazy embedded content only: parent surfaces own placement, visibility and focus.
  if(window.ShokaBlogAI) return;
  var instances = new Map(), serial = 0;
  var modes = {
    ask: { name: '问问本站', hint: '优先参考本站文章，没有相关资料时也能正常回答。', placeholder: '博客文章、技术问题，或任何想聊的话题…', label: '你想了解什么', send: '查找并回答' },
    explain: { name: '选区解释', hint: '确认要解释的文字。只发送下面的选区，不会上传整篇文章。', send: '解释这段文字' },
    guide: { name: '文章导读', hint: '先了解这篇文章的关键内容和阅读路线，再慢慢读。', send: '生成导读' },
    chat: { name: 'Blog AI', hint: '博客资料优先，也能聊知识、编程和灵感。', placeholder: '今天有什么想聊的？', label: '想问点什么', send: '发送' }
  };
  var blogQuestions = [
    '第一次来，推荐先读哪些博客文章？',
    '想学习 Shoka 美化，该按什么顺序阅读？',
    '本站有哪些 Markdown 扩展用法？',
    '博客里的音乐可视化是怎么实现的？',
    'Three.js 留声机有哪些实现要点？',
    '博客的数据统计图表是怎么做的？',
    '有哪些提升博客加载速度的思路？',
    '如何搭建 Hexo 博客？本站有相关教程吗？',
    '本站有哪些 Java 学习笔记？',
    '想了解计算机图形学，可以读哪些文章？',
    '文章封面和图片展示有哪些美化方法？',
    '从本站文章中选一个适合练手的小项目。'
  ];
  // One in-memory batch only: no stored browsing history and no extra AI/network request.
  var recentSuggestions = { key: '', questions: [] };
  function shortText(value, max) {
    return typeof value === 'string' ? value.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max).replace(/[\uD800-\uDBFF]$/, '') : '';
  }
  function suggestionPool(context) {
    if(context.mode !== 'ask' && context.mode !== 'chat') return [];
    if(context.tour) return ['想逛逛本站关于音乐与可视化的文章', '找找 Three.js 创作背后的故事', '博客里有哪些有趣的视觉设计？', '带我看看 Markdown 和写作相关的文章', '发现本站图形学和动画的文章', '有哪些关于 Shoka 美化的文章值得逛逛？'].map(function(question) { return { label: question, question: question }; });
    if(!context.article || !context.title) return blogQuestions.map(function(question) { return { label: question, question: question }; });
    var subject = '请结合本站文章《' + context.title + '》的内容，';
    var pool = [
      { label: '概括本文的核心要点', question: subject + '概括核心内容和主要观点。' },
      { label: '用小白能懂的话讲讲', question: subject + '用初学者能理解的语言解释重要概念。' },
      { label: '从哪里开始阅读？', question: subject + '给出理解这篇文章的阅读顺序和需要的基础知识。' },
      { label: '有哪些值得注意的地方？', question: subject + '指出需要特别注意或进一步核实的地方；区分原文内容与通用建议。' },
      { label: '举例解释核心观点', question: subject + '用一个简单的例子解释核心观点，并注明哪些是补充举例。' },
      { label: '推荐本站相关阅读', question: subject + '推荐可以继续阅读的本站相关文章，说明它们的联系。' }
    ];
    context.headings.forEach(function(heading) {
      var label = heading.length > 16 ? heading.slice(0, 16) + '…' : heading;
      pool.push({ label: '讲讲「' + label + '」', question: subject + '解释「' + heading + '」这一节的重点和它与全文的关系。' });
    });
    return pool;
  }
  function nextSuggestions(context) {
    var key = context.article ? context.path + '|' + context.title : 'global';
    var pool = suggestionPool(context), previous = recentSuggestions.key === key ? recentSuggestions.questions : [];
    var choices = pool.filter(function(item) { return previous.indexOf(item.question) < 0; });
    if(choices.length < 2) choices = pool.slice();
    for(var i = choices.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1)), item = choices[i]; choices[i] = choices[j]; choices[j] = item;
    }
    var result = choices.slice(0, 2);
    recentSuggestions = { key: key, questions: result.map(function(item) { return item.question; }) };
    return result;
  }
  function element(tag, className, text) {
    var node = document.createElement(tag);
    if(className) node.className = className;
    if(text !== undefined) node.textContent = text;
    return node;
  }
  function config() { return window.BlogAIConfig || {}; }
  function transportLimits(value, fallback) {
    fallback = fallback || { maxResponseBytes: 1048576, maxAnswerChars: 65536, timeoutMs: 90000 };
    var valid = value && typeof value === 'object' && !Array.isArray(value);
    function integer(name, min, max) {
      return valid && Object.hasOwn(value, name) && Number.isSafeInteger(value[name]) && value[name] >= min && value[name] <= max;
    }
    // Transport guardrails are separate from model tokens; never trust arbitrary server limits.
    return {
      maxResponseBytes: integer('maxResponseBytes', 65536, 25165824) ? Math.max(1048576, value.maxResponseBytes) : fallback.maxResponseBytes,
      maxAnswerChars: integer('maxAnswerChars', 65536, 3145728) ? value.maxAnswerChars : fallback.maxAnswerChars,
      timeoutMs: integer('timeoutMs', 1000, 120000) ? Math.max(90000, value.timeoutMs + 5000) : fallback.timeoutMs
    };
  }
  function endpoint() {
    var cfg = config();
    if(cfg.enabled !== true || typeof cfg.endpoint !== 'string') return '';
    try {
      var url = new URL(cfg.endpoint, location.href);
      var local = url.hostname === 'localhost' || url.hostname === '127.0.0.1' || url.hostname === '[::1]';
      if((url.protocol !== 'https:' && !(local && url.protocol === 'http:')) || url.username || url.password || url.search || url.hash) return '';
      return url.href.replace(/\/+$/, '');
    } catch(error) { return ''; }
  }
  function safeSource(raw) {
    if(!raw || typeof raw.url !== 'string' || raw.url.length > 1500 || /[\u0000-\u001f]/.test(raw.url)) return null;
    try {
      var origins = [location.origin], site = config().siteUrl;
      if(typeof site === 'string') {
        var configured = new URL(site);
        if(configured.protocol === 'https:' && !configured.username && !configured.password) origins.push(configured.origin);
      }
      var url = new URL(raw.url, site || location.origin);
      var external = raw.kind === 'web' || raw.kind === 'reference';
      if(url.username || url.password || !/^https?:$/.test(url.protocol)) return null;
      if(external) {
        if(url.protocol !== 'https:' || url.port || !/^[a-z\d.-]+\.[a-z]{2,}$/i.test(url.hostname)
          || /(?:^|\.)(?:localhost|local|internal|test|invalid)$/i.test(url.hostname)
          || /(?:token|key|secret|password|auth|signature)=/i.test(url.search)) return null;
      } else if(url.search || origins.indexOf(url.origin) < 0) return null;
      if(url.protocol !== 'https:' && url.origin !== location.origin) return null;
      return { title: String(raw.title || '阅读原文').slice(0, 160), url: url.href, kind: external ? raw.kind : 'blog',
        section: shortText(raw.section, 120), quote: shortText(raw.quote, 220), retrievedAt: shortText(raw.retrievedAt, 40) };
    } catch(error) { return null; }
  }
  function icon(name) {
    var node = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    node.setAttribute('viewBox', '0 0 24 24'); node.setAttribute('width', '24'); node.setAttribute('height', '24');
    node.setAttribute('fill', 'none'); node.setAttribute('stroke', 'currentColor'); node.setAttribute('stroke-width', '1.7');
    node.setAttribute('stroke-linecap', 'round'); node.setAttribute('stroke-linejoin', 'round'); node.setAttribute('aria-hidden', 'true');
    var paths = {
      spark: ['m12 3 2.6 6.4L21 12l-6.4 2.6L12 21l-2.6-6.4L3 12l6.4-2.6Z'],
      close: ['m6 6 12 12', 'M18 6 6 18'], send: ['m4 4 17 8-17 8 3-8-3-8Z', 'M7 12h14'],
      copy: ['M9 8h10v13H9z', 'M15 4H5v13'], stop: ['M6 6h12v12H6z'], arrow: ['M5 12h14', 'm14 7 5 5-5 5'],
      refresh: ['M20 7v5h-5', 'M4 17v-5h5', 'M6.1 7a7 7 0 0 1 11.8-1L20 9', 'M17.9 17a7 7 0 0 1-11.8 1L4 15'],
      expand: ['M8 3H3v5M16 3h5v5M3 16v5h5M21 16v5h-5']
    };
    (paths[name] || paths.spark).forEach(function(d) {
      var path = document.createElementNS('http://www.w3.org/2000/svg', 'path'); path.setAttribute('d', d); node.appendChild(path);
    }); return node;
  }
  function button(className, text, iconName) {
    var node = element('button', className); node.type = 'button';
    if(iconName) node.appendChild(icon(iconName)); node.appendChild(element('span', '', text)); return node;
  }
  function cleanContext(options) {
    return {
      mode: modes[options.mode] ? options.mode : 'ask',
      tour: options.tour === true,
      path: typeof options.path === 'string' && /^\/(?!\/)/.test(options.path) && options.path.length <= 1000 ? options.path : '',
      text: typeof options.text === 'string' ? options.text.slice(0, 4000) : '',
      title: shortText(options.title, 200),
      article: options.article === true && !!shortText(options.title, 200),
      headings: options.article === true && Array.isArray(options.headings)
        ? Array.from(new Set(options.headings.slice(0, 8).map(function(heading) { return shortText(heading, 80); }).filter(Boolean))) : [],
      question: typeof options.question === 'string' ? options.question.slice(0, 1000) : ''
    };
  }
  function contextKey(context) {
    return context.mode + (context.mode === 'guide' ? '|' + context.path : context.mode === 'explain' ? '|' + context.path + '|' + context.text
      : context.article ? '|article|' + context.path + '|' + context.title : '|global');
  }
  function attachPageContext(payload, context, service) {
    if(!payload || (context.mode !== 'ask' && context.mode !== 'chat') || payload.control || context.tour || !context.path) return payload;
    if(service && service.features && service.features.pageContext === true) payload.currentPath = context.path;
    else if(/(?:本文|本篇|本页|这篇|这个页面|当前(?:文章|页面|网页)|this (?:article|post|page))/iu.test(payload.question) && context.title) {
      // Older deployments reject unknown fields. Identify the public page using
      // a short title prefix only when the original question fits in full.
      var prefix = '当前公开页面：' + shortText(context.title, 200) + '\n';
      if(prefix.length + payload.question.length <= 1000) payload.question = prefix + payload.question;
    }
    return payload;
  }
  var captchaScript = null;
  function loadCaptchaScript() {
    if(typeof window.TencentCaptcha === 'function') return Promise.resolve();
    if(captchaScript) return captchaScript;
    captchaScript = new Promise(function(resolve, reject) {
      var script = document.createElement('script'), done = false;
      var timeout = setTimeout(function() { finish(false); }, 10000);
      function finish(ok) {
        if(done) return; done = true; clearTimeout(timeout);
        script.onload = script.onerror = null;
        if(ok && typeof window.TencentCaptcha === 'function') resolve();
        else { script.remove(); captchaScript = null; reject(new Error('安全验证暂时加载失败，请稍后重试。')); }
      }
      // Fixed official URL; never accept an executable URL from an API response.
      script.src = 'https://turing.captcha.qcloud.com/TJCaptcha.js'; script.async = true;
      script.onload = function() { finish(true); }; script.onerror = function() { finish(false); };
      document.head.appendChild(script);
    });
    return captchaScript;
  }
  function validChallenge(value) {
    return value && value.provider === 'tencent' && typeof value.appId === 'string' && /^[1-9][0-9]{5,11}$/.test(value.appId)
      && typeof value.challenge === 'string' && /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(value.challenge) && value.challenge.length <= 1200;
  }
  async function solveCaptcha(challenge, signal) {
    await loadCaptchaScript();
    if(signal.aborted) throw new DOMException('Cancelled', 'AbortError');
    return new Promise(function(resolve, reject) {
      var widget, finished = false, timeout;
      function finish(error, result) {
        if(finished) return; finished = true; clearTimeout(timeout); signal.removeEventListener('abort', abort);
        if(widget && typeof widget.destroy === 'function') widget.destroy();
        if(error) reject(error); else resolve(result);
      }
      function abort() { finish(new DOMException('Cancelled', 'AbortError')); }
      signal.addEventListener('abort', abort, { once: true });
      timeout = setTimeout(function() { finish(new Error('验证已超时，请重新发送。')); }, 120000);
      try {
        widget = new window.TencentCaptcha(challenge.appId, function(result) {
          if(result && result.ret === 0 && typeof result.ticket === 'string' && !result.ticket.startsWith('trerror')
            && /^[!-~]{10,2048}$/.test(result.ticket) && typeof result.randstr === 'string' && /^[!-~]{1,128}$/.test(result.randstr)) {
            finish(null, { challenge: challenge.challenge, ticket: result.ticket, randstr: result.randstr });
          } else finish(new Error('安全验证未完成，没有调用 AI。请重新验证。'));
        }, { userLanguage: 'zh-cn', enableDarkMode: document.documentElement.dataset.theme === 'dark' });
        widget.show();
      } catch(error) { finish(new Error('安全验证暂时不可用，请稍后再试。')); }
    });
  }
  function errorMessage(code) {
    var messages = {
      SEARCH_NOT_CONFIGURED: '联网检索尚未在服务器启用，可关闭联网选项继续使用博客资料与通用问答。',
      RATE_LIMITED: '请求有点频繁，请稍等片刻再试。', RATE_LIMIT: '请求有点频繁，请稍等片刻再试。',
      IP_RATE_LIMIT: '当前网络请求过于频繁，请等一分钟再试。', IP_CONCURRENT_LIMIT: '当前网络已有一个回答正在生成，请等它结束后再试。',
      ABUSE_COOLDOWN: '检测到频繁或异常请求，请稍后再试；此次没有调用 AI。', ABUSE_CAPACITY: '安全防护正在处理较多请求，请稍后再试。',
      GLOBAL_RATE_LIMIT: '全站 AI 请求暂时较密集，请等待后重试；此次未调用模型，也未扣每日额度。常用本地操作仍可使用。',
      CAPTCHA_INVALID: '安全验证已失效，请重新发送并验证。', CAPTCHA_UNAVAILABLE: '验证服务暂不可用，请稍后再试；此次没有调用 AI。', CAPTCHA_BUSY: '安全验证请求较多，请稍后再试。',
      DAILY_LIMIT: '今天的 AI 额度已用完，明天再来看看吧。', DAILY_QUOTA_EXCEEDED: '今天的 AI 额度已用完，明天再来看看吧。', QUOTA_EXCEEDED: '今天的 AI 额度已用完，明天再来看看吧。',
      IP_DAILY_LIMIT: '你今天的 AI 使用额度已用完，明天再来看看吧。', BUSY: '当前使用人数较多，请稍后再试。', CONCURRENCY_LIMIT: '当前使用人数较多，请稍后再试。', CONCURRENT_LIMIT: '当前使用人数较多，请稍后再试。',
      PAID_DISABLED: 'AI 服务尚未开放，暂时不能生成回答。', PUBLIC_DISABLED: 'AI 服务尚未开放，暂时不能生成回答。', AI_DISABLED: 'AI 服务尚未开放，暂时不能生成回答。', SERVICE_DISABLED: 'AI 服务尚未开放，暂时不能生成回答。',
      PUBLIC_EXPIRED: '本次 AI 试用已结束，请等待博主再次开放。', AI_NOT_CONFIGURED: 'AI 服务正在配置中，请稍后再试。', KNOWLEDGE_NOT_READY: '本站文章索引还在准备中，请稍后再试。',
      ARTICLE_NOT_FOUND: '这篇文章尚未加入 AI 索引，请稍后再试。', NOT_FOUND: '尚未找到这篇文章，请从文章内打开导读。', INPUT_TOO_LONG: '内容太长了，请缩短后再试。',
      INVALID_INPUT: '请检查输入内容，或重新选择文章中的文字。', INVALID_FIELDS: '请检查输入内容，或重新选择文章中的文字。', UPSTREAM_TIMEOUT: '模型响应超时，请稍后手动重试。', UPSTREAM_ERROR: '模型服务暂时不可用，请稍后手动重试。',
      ORIGIN_NOT_ALLOWED: '当前站点还没有获得 AI 服务访问权限。', FORBIDDEN: '当前站点还没有获得 AI 服务访问权限。'
    }; return messages[code] || '这次没有顺利完成，请稍后手动重试。';
  }

  function createInstance(host, options, context) {
    var key = contextKey(context), mode = context.mode, spec = context.tour
      ? { name: '宇宙 AI 导游', hint: '说说你想逛的主题，回答完成后点亮相关的文章星点。也可以聊博客之外的话题。', placeholder: '想逛逛音乐、视觉设计或博客背后的故事…', label: '今天往哪里漫游', send: '发现航线' } : modes[mode], prefix = 'blog-ai-' + (++serial);
    var base = endpoint(), service = null, statusText = base ? '正在检查连接…' : '尚未启用 · 不会发送内容';
    var connection = base ? 'checking' : 'offline', checkedAt = 0;
    var ui = {}, life = new AbortController(), controller = null, statusController = null, timer = null, statusTimer = null;
    var token = 0, dead = false, turns = [], callbackOptions = options, activeState = 'idle', verificationPending = null, continuationAvailable = false;
    var followingOutput = false, lastScrollTop = 0, touchStartY = null, outputFrame = null;
    var playground = null, experience = '', playgroundLoading = false, drafts = Object.create(null);
    var actionMode = false, actionsAPI = null, siteActions = null, actionsLoading = false, actionsRequest = null;
    var root = element('section', 'blog-ai blog-ai--embedded'); root.dataset.mode = mode;
    if(context.tour) root.dataset.tour = 'true';
    root.setAttribute('aria-labelledby', prefix + '-title');
    function signalState(value) {
      activeState = value; root.dataset.state = value;
    }
    function announce(message, tone) {
      if(dead) return;
      if(ui.notice.textContent !== message) ui.notice.textContent = message; ui.notice.dataset.tone = tone || '';
    }
    function unavailable() {
      return !base || connection !== 'connected';
    }
    function actionScope() { return !experience && !context.tour && (mode === 'chat' || mode === 'ask'); }
    function localRequest() { return actionScope() && actionsAPI ? actionsAPI.localPlan(ui.question.value.trim()) : null; }
    function prepareLocalInput() {
      // Keep ordinary online Q&A light. Only intent/offline typing loads the
      // local controller; this never requests a model or waits for AI status.
      if(dead || !actionScope() || !window.ShokaFeatures || actionsLoading || siteActions || !ui.question.value.trim() || (!actionMode && !unavailable())) return;
      void loadActions().catch(function() { if(!dead && actionMode) announce('本地操作组件暂时加载失败，请重新点击站内操作重试。', 'error'); });
    }
    function currentStatus() {
      if(service && service.available !== false && service.features && service.features[mode] === false) return mode === 'chat' || mode === 'ask' ? '对话功能尚未开放' : '本站文章索引正在准备 · 当前功能暂不可用';
      return statusText + (connection === 'offline' && actionScope() ? ' · 本地操作仍可用' : '');
    }
    function updateControls() {
      if(dead) return;
      var missing = (mode === 'guide' && !context.path) || (mode === 'explain' && !ui.selection.value.trim()) || ((mode === 'ask' || mode === 'chat') && !ui.question.value.trim());
      var local = localRequest(), localAllowed = actionScope() && (actionMode || !!local);
      ui.send.disabled = !!controller || actionsLoading || !!missing || (unavailable() && !localAllowed); ui.send.hidden = !!controller || !!verificationPending; ui.stop.hidden = !controller;
      if(!experience) ui.send.querySelector('span').textContent = local && unavailable() ? '生成本地操作卡片' : actionMode ? '生成操作卡片' : spec.send;
      if(ui.controlHint) ui.controlHint.textContent = unavailable()
        ? 'AI 暂不可用：常用音乐、导航和显示操作仍可本地识别，不消耗额度。自由表述和复杂组合需重新连接 AI。'
        : '可以自然描述想做什么，含义相近也能由 AI 理解。常用指令优先本地识别；操作先生成卡片，确认后才生效。';
      ui.verify.hidden = !verificationPending || !!controller;
      ui.question.disabled = !!controller || actionsLoading; ui.selection.disabled = !!controller;
      ui.form.setAttribute('aria-busy', controller ? 'true' : 'false'); ui.service.textContent = currentStatus();
      root.dataset.connection = connection;
      ui.retry.hidden = connection === 'connected'; ui.retry.disabled = !!controller || !!statusController || !base;
      root.querySelectorAll('.blog-ai__suggestion, .blog-ai__suggestion-refresh').forEach(function(node) { node.disabled = !!controller || actionsLoading; });
      if(ui.webSearch) {
        var searchReady = !!(service && service.features && service.features.webSearch === true);
        ui.webSearch.disabled = !!controller || !searchReady;
        if(!searchReady) ui.webSearch.checked = false;
        ui.webHint.textContent = searchReady ? '同时检索外部资料' : '联网检索待服务器启用';
      }
      turns.forEach(function(turn) {
        turn.copy.disabled = !turn.answer || !!controller;
        turn.resume.hidden = !continuationAvailable || !turn.answer || turn.completed || !!turn.experience || !!turn.control;
        turn.resume.disabled = !!controller || !!unavailable();
      });
      if(ui.playEntry) ui.playEntry.disabled = !!controller || playgroundLoading || actionsLoading;
      if(ui.actionEntry) ui.actionEntry.disabled = !!controller || actionsLoading || playgroundLoading;
      if(playground) playground.setBusy(!!controller);
    }
    function scrollOutput() {
      if(dead || mode === 'guide' || !followingOutput) return;
      // Keep the reply and composer in this panel visible; never scroll the page.
      ui.scroller.scrollTop = ui.scroller.scrollHeight;
      lastScrollTop = ui.scroller.scrollTop;
    }
    function scheduleOutputScroll() {
      if(dead || outputFrame !== null) return;
      outputFrame = requestAnimationFrame(function() { outputFrame = null; scrollOutput(); });
    }
    function cancelOutputScroll() {
      if(outputFrame !== null) { cancelAnimationFrame(outputFrame); outputFrame = null; }
    }
    function sourceLink(source, number, className) {
      var link = element('a', className); link.href = source.url; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.referrerPolicy = 'no-referrer';
      if(source.kind === 'blog') {
        var url = new URL(source.url), anchor = url.hash.slice(1);
        // Keep the conversation open in this tab; other articles open alongside it.
        link.href = location.origin + url.pathname + '#ai-source=' + anchor;
        link.addEventListener('click', function(event) {
          if(event.ctrlKey || event.metaKey || event.shiftKey || event.altKey || url.pathname !== location.pathname) return;
          event.preventDefault(); event.stopPropagation();
          if(window.BlogAIReference) window.BlogAIReference(anchor);
        }, { signal: life.signal });
      }
      link.setAttribute('aria-label', source.kind === 'blog' ? '定位原文：' + (source.section || source.title) : '打开外部来源：' + source.title);
      if(number) link.textContent = '[' + number + ']';
      return link;
    }
    function renderAnswer(turn) {
      if(window.ShokaAIMarkdown) {
        window.ShokaAIMarkdown.render(turn.answerNode, turn.answer, { citation: function(number) {
          var source = turn.sources.find(function(item) { return item.number === number; });
          return source ? sourceLink(source, source.number, 'blog-ai__citation') : null;
        } });
        turn.answerText = null; return;
      }
      if(window.ShokaFeatures) window.ShokaFeatures.load('ai_markdown').then(function() {
        if(!dead && turn.answerNode.isConnected) renderAnswer(turn);
      }).catch(function() { /* The complete source text below remains readable/copyable offline. */ });
      // Parse only server-authorized numeric citations. All other model text stays inert.
      var fragment = document.createDocumentFragment(), pattern = /\[(\d{1,2})\]/g, match, start = 0;
      while((match = pattern.exec(turn.answer))) {
        fragment.appendChild(document.createTextNode(turn.answer.slice(start, match.index)));
        var source = turn.sources.find(function(item) { return item.number === Number(match[1]); });
        fragment.appendChild(source ? sourceLink(source, source.number, 'blog-ai__citation') : document.createTextNode(match[0]));
        start = pattern.lastIndex;
      }
      fragment.appendChild(document.createTextNode(turn.answer.slice(start))); turn.answerNode.replaceChildren(fragment); turn.answerText = null;
    }
    function renderSources(turn) {
      turn.sourcesNode.replaceChildren(); turn.sourceWrap.hidden = !turn.sources.length;
      turn.sourcesLabel.textContent = turn.sources.some(function(source) { return source.kind === 'web'; }) ? '回答参考资料 · 点击核对来源' : '相关博客资料 · 阅读原文核对';
      turn.sources.forEach(function(source) {
        var link = sourceLink(source, null, 'blog-ai__source'), copy = element('span', 'blog-ai__source-title', source.title);
        copy.appendChild(element('small', 'blog-ai__source-meta', source.kind === 'web' ? '联网搜索摘要 · ' + new URL(source.url).hostname + (Number.isFinite(Date.parse(source.retrievedAt)) ? ' · ' + new Date(source.retrievedAt).toLocaleDateString('zh-CN') : '')
          : source.section ? '定位章节 · ' + source.section : '博客原文'));
        if(source.quote) copy.appendChild(element('small', 'blog-ai__source-quote', source.quote));
        link.append(element('span', 'blog-ai__source-number', String(source.number).padStart(2, '0')), copy, icon('arrow')); turn.sourcesNode.appendChild(link);
      });
    }
    async function copyTurn(turn) {
      if(!turn.answer || !navigator.clipboard || !navigator.clipboard.writeText) { announce('当前浏览器无法自动复制，可选中回答后手动复制。'); return; }
      try { await navigator.clipboard.writeText(turn.answer); if(!dead) announce('回答已复制。', 'success'); }
      catch(error) { if(!dead) announce('复制失败，可选中回答后手动复制。'); }
    }
    function appendTurn(question, control) {
      if(mode === 'guide' || mode === 'explain') { turns = []; ui.thread.replaceChildren(); }
      var turn = { question: question, answer: '', sources: [], completed: false, experience: experience, control: control === true };
      turn.node = element('section', 'blog-ai__turn'); turn.node.dataset.turnState = 'thinking';
      if(mode === 'chat' || mode === 'ask') {
        var userMessage = element('div', 'blog-ai__user-message'); userMessage.append(element('span', 'blog-ai__speaker', '你'), element('p', '', question)); turn.node.appendChild(userMessage);
      }
      var answerBlock = element('div', 'blog-ai__assistant-message'), resultHead = element('div', 'blog-ai__result-head');
      turn.label = element('h4', 'blog-ai__answer-label', '正在整理…'); turn.copy = button('blog-ai__copy', '复制', 'copy'); turn.copy.disabled = true;
      turn.copy.setAttribute('aria-label', '复制这条回答'); turn.copy.addEventListener('click', function() { copyTurn(turn); }, { signal: life.signal }); resultHead.append(turn.label, turn.copy);
      turn.answerNode = element('div', 'blog-ai__answer'); turn.answerNode.tabIndex = 0; turn.answerNode.setAttribute('aria-label', 'AI 回答内容');
      turn.resume = button('blog-ai__resume', '继续生成（计入一次额度）', 'refresh'); turn.resume.hidden = true;
      turn.resume.addEventListener('click', function() { if(turn.answer && !turn.completed) void submit(null, turn); }, { signal: life.signal });
      turn.sourceWrap = element('div', 'blog-ai__source-wrap'); turn.sourceWrap.hidden = true; turn.sourcesNode = element('div', 'blog-ai__sources');
      turn.sourcesLabel = element('p', 'blog-ai__label', '相关博客资料 · 阅读原文核对');
      turn.sourceWrap.append(turn.sourcesLabel, turn.sourcesNode);
      turn.referencesNode = element('div', 'blog-ai__references'); turn.referencesNode.hidden = true;
      turn.searchState = element('p', 'blog-ai__field-hint'); turn.searchState.hidden = true;
      answerBlock.append(resultHead, turn.answerNode, turn.resume, turn.searchState, turn.sourceWrap, turn.referencesNode); turn.node.appendChild(answerBlock);
      ui.thread.hidden = false; ui.thread.appendChild(turn.node); turns.push(turn);
      var retained = experience ? 2 : mode === 'chat' ? 12 : mode === 'ask' ? 4 : 1;
      // Tools have their own bounded history and must not evict normal Q&A.
      while(turns.filter(function(item) { return item.experience === experience && item.control === turn.control; }).length > retained) {
        var oldest = turns.findIndex(function(item) { return item.experience === experience && item.control === turn.control; });
        turns.splice(oldest, 1)[0].node.remove();
      }
      return turn;
    }
    function chatHistory() {
      var pairs = turns.filter(function(turn) { return !turn.experience && !turn.control && turn.completed && turn.answer.trim(); }).slice(-3).map(function(turn) {
        return [{ role: 'user', content: turn.question.slice(0, 2000) }, { role: 'assistant', content: turn.answer.slice(0, 2000) }];
      });
      while(pairs.reduce(function(total, pair) { return total + pair[0].content.length + pair[1].content.length; }, 0) > 6000) pairs.shift();
      return pairs.reduce(function(all, pair) { return all.concat(pair); }, []);
    }
    function stop(message) {
      if(controller) { controller.abort(); controller = null; ++token; }
      if(timer) { clearTimeout(timer); timer = null; }
      cancelOutputScroll();
      followingOutput = false;
      var last = turns[turns.length - 1];
      if(last && !last.completed) {
        last.label.textContent = last.answer ? '回答已停止 · 内容可能不完整' : '已停止生成'; last.node.dataset.turnState = 'stopped';
        if(last.experience || last.control) last.answerNode.textContent = '已停止生成，没有执行操作。';
        else if(last.answer) renderAnswer(last);
      }
      if(!dead) { signalState('idle'); if(message) announce(message); updateControls(); }
    }
    function focus() {
      if(dead || !host.isConnected) return;
      var target = mode === 'guide' ? ui.send : mode === 'explain' ? ui.selection : ui.question;
      if(target.disabled) target = ui.close; target.focus({ preventScroll: true });
    }
    function close() {
      stop();
      if(typeof callbackOptions.onClose === 'function') { try { callbackOptions.onClose(); } catch(error) { destroy(); } }
      else destroy();
    }
    function destroy() {
      if(dead) return;
      stop(); dead = true; verificationPending = null;
      if(playground) playground.destroy();
      if(siteActions) siteActions.destroy();
      if(statusController) statusController.abort(); clearTimeout(statusTimer); life.abort(); root.remove(); turns = [];
      if(instances.get(host) === handle) instances.delete(host);
    }

    var header = element('header', 'blog-ai__head'), brand = element('div', 'blog-ai__brand'), mark = element('span', 'blog-ai__mark'); mark.appendChild(icon('spark'));
    var titles = element('div', 'blog-ai__titles'), title = element('h3', 'blog-ai__title', spec.name); title.id = prefix + '-title';
    ui.service = element('p', 'blog-ai__service', statusText); titles.append(title, ui.service); brand.append(mark, titles);
    ui.service.setAttribute('role', 'status');
    var headActions = element('div', 'blog-ai__head-actions');
    ui.retry = button('blog-ai__retry', '重新连接', 'refresh');
    ui.retry.setAttribute('aria-label', '重新连接 AI'); ui.retry.title = '重新连接 AI';
    ui.retry.addEventListener('click', function() { void checkStatus(); }, { signal: life.signal });
    headActions.append(ui.retry);
    if(mode === 'explain' && typeof options.onExpand === 'function') {
      ui.expand = button('blog-ai__expand', '放大', 'expand'); ui.expand.setAttribute('aria-label', '放大选区解释');
      ui.expand.title = '放大选区解释';
      ui.expand.setAttribute('aria-expanded', 'false');
      ui.expand.addEventListener('click', function() { callbackOptions.onExpand(); }, { signal: life.signal }); headActions.append(ui.expand);
    }
    ui.close = button('blog-ai__close', '关闭', 'close'); ui.close.setAttribute('aria-label', '关闭' + spec.name); ui.close.addEventListener('click', close, { signal: life.signal }); headActions.append(ui.close); header.append(brand, headActions);
    ui.scroll = element('div', 'blog-ai__scroll');
    ui.thread = element('div', 'blog-ai__thread'); ui.thread.hidden = true; ui.thread.setAttribute('aria-label', mode === 'chat' || mode === 'ask' ? '问答记录' : 'AI 解读');
    ui.scroller = context.tour ? ui.thread : ui.scroll;
    ui.scroller.addEventListener('scroll', function() {
      var top = ui.scroller.scrollTop;
      if(controller && top < lastScrollTop - 2) followingOutput = false;
      else if(controller && top > lastScrollTop && ui.scroller.scrollHeight - top - ui.scroller.clientHeight < 4) followingOutput = true;
      lastScrollTop = top;
    }, { passive: true, signal: life.signal });
    ui.scroller.addEventListener('wheel', function(event) { if(controller && event.deltaY < 0) followingOutput = false; }, { passive: true, signal: life.signal });
    ui.scroller.addEventListener('touchstart', function(event) { touchStartY = event.touches.length ? event.touches[0].clientY : null; }, { passive: true, signal: life.signal });
    ui.scroller.addEventListener('touchmove', function(event) {
      if(controller && touchStartY !== null && event.touches.length && event.touches[0].clientY > touchStartY + 4) followingOutput = false;
    }, { passive: true, signal: life.signal });
    ui.scroller.addEventListener('keydown', function(event) {
      if(controller && !event.target.matches('textarea,input') && (event.key === 'ArrowUp' || event.key === 'PageUp' || event.key === 'Home')) followingOutput = false;
    }, { signal: life.signal });
    var intro = element('div', 'blog-ai__intro'); intro.appendChild(element('p', 'blog-ai__hint', spec.hint));
    if(mode === 'guide') {
      intro.appendChild(element('p', 'blog-ai__article', context.title || '当前文章'));
      if(!context.path) intro.appendChild(element('p', 'blog-ai__field-hint', '请从一篇文章的开头打开导读。'));
    }
    ui.form = element('form', 'blog-ai__form');
    var questionWrap = element('div', 'blog-ai__field blog-ai__field--question'); questionWrap.hidden = mode !== 'ask' && mode !== 'chat';
    var questionLabel = element('label', 'blog-ai__label', spec.label || '问题'); questionLabel.htmlFor = prefix + '-question';
    ui.question = element('textarea', 'blog-ai__input'); ui.question.id = prefix + '-question'; ui.question.rows = mode === 'chat' || context.tour ? 2 : 3; ui.question.maxLength = 1000;
    ui.question.value = context.question; ui.question.placeholder = spec.placeholder || ''; ui.question.autocomplete = 'off'; ui.question.addEventListener('input', function() { updateControls(); prepareLocalInput(); }, { signal: life.signal });
    ui.question.addEventListener('keydown', function(event) {
      if(event.key === 'Enter' && (event.ctrlKey || event.metaKey) && !event.isComposing) { event.preventDefault(); if(!ui.send.disabled) submit(); }
    }, { signal: life.signal }); questionWrap.append(questionLabel, ui.question);
    var selectionWrap = element('div', 'blog-ai__field'); selectionWrap.hidden = mode !== 'explain';
    var selectionLabel = element('label', 'blog-ai__label', '待解释的文字'); selectionLabel.htmlFor = prefix + '-selection';
    ui.selection = element('textarea', 'blog-ai__input blog-ai__input--selection'); ui.selection.id = prefix + '-selection'; ui.selection.rows = 4; ui.selection.maxLength = 4000;
    ui.selection.value = context.text; ui.selection.autocomplete = 'off'; ui.selection.addEventListener('input', updateControls, { signal: life.signal });
    selectionWrap.append(selectionLabel, ui.selection, element('p', 'blog-ai__field-hint', context.text ? '可删去不想发送的内容，最多 4000 字。' : '请选中正文，或在这里粘贴要解释的文字。'));
    ui.suggestions = element('div', 'blog-ai__suggestions');
    if(mode === 'ask' || mode === 'chat') {
      var suggestionHead = element('div', 'blog-ai__suggestion-head');
      var suggestionLabel = element('span', 'blog-ai__suggestion-label', context.tour ? '选一个漫游方向' : context.article ? '围绕本文提问' : '随便问问博客');
      suggestionLabel.title = context.article ? context.title : '从博客相关问题中随机推荐';
      ui.refreshSuggestions = button('blog-ai__suggestion-refresh', '换一组', 'refresh');
      ui.refreshSuggestions.setAttribute('aria-label', context.article ? '换一组本文相关问题' : '换一组博客相关问题');
      var suggestionList = element('div', 'blog-ai__suggestion-list');
      suggestionList.setAttribute('role', 'group'); suggestionList.setAttribute('aria-label', context.article ? '本文推荐问题' : '博客推荐问题');
      function refreshSuggestions() {
        if(dead || controller) return;
        suggestionList.replaceChildren();
        nextSuggestions(context).forEach(function(item) {
          var suggestion = button('blog-ai__suggestion', item.label);
          suggestion.title = item.question;
          suggestion.dataset.question = item.question;
          suggestionList.appendChild(suggestion);
        });
      }
      // One delegated listener avoids accumulating handlers when recommendations are refreshed.
      suggestionList.addEventListener('click', function(event) {
        var suggestion = event.target.closest && event.target.closest('.blog-ai__suggestion');
        if(dead || controller || !suggestion || !suggestionList.contains(suggestion)) return;
        ui.question.value = suggestion.dataset.question; verificationPending = null;
        updateControls(); ui.question.focus({ preventScroll: true });
      }, { signal: life.signal });
      ui.refreshSuggestions.addEventListener('click', refreshSuggestions, { signal: life.signal });
      suggestionHead.append(suggestionLabel, ui.refreshSuggestions);
      ui.suggestions.append(suggestionHead, suggestionList); refreshSuggestions();
    }
    var actions = element('div', 'blog-ai__actions'); ui.notice = element('p', 'blog-ai__notice'); ui.notice.setAttribute('role', 'status'); ui.notice.setAttribute('aria-live', 'polite');
    ui.send = button('blog-ai__send', spec.send, 'send'); ui.send.type = 'submit'; ui.stop = button('blog-ai__stop', '停止生成', 'stop'); ui.stop.hidden = true;
    ui.verify = button('blog-ai__verify', '安全验证并继续', 'spark'); ui.verify.hidden = true;
    ui.verify.addEventListener('click', async function() {
      if(!verificationPending || controller || dead) return;
      var pending = verificationPending, check = new AbortController(); controller = check; updateControls(); announce('请完成人机验证…');
      var proof;
      try { proof = await solveCaptcha(pending.challenge, check.signal); }
      catch(error) { if(!dead && !check.signal.aborted) announce(error.message, 'error'); }
      finally { if(controller === check) controller = null; if(!dead) updateControls(); }
      if(proof && !dead && !check.signal.aborted && verificationPending === pending) submit(proof);
    }, { signal: life.signal });
    ui.form.addEventListener('input', function() { verificationPending = null; updateControls(); }, { signal: life.signal });
    ui.stop.addEventListener('click', function() { stop('已停止生成，已收到的内容会保留。'); }, { signal: life.signal }); actions.append(ui.notice, ui.stop, ui.verify, ui.send);
    ui.form.append(selectionWrap, questionWrap, ui.suggestions, actions); ui.form.addEventListener('submit', function(event) { event.preventDefault(); submit(); }, { signal: life.signal });
    if(context.tour) {
      // The primary action must not sit below suggestions or a growing reply history.
      ui.form.insertBefore(actions, ui.suggestions);
      ui.form.insertBefore(ui.notice, ui.suggestions);
    }
    if(mode === 'chat' || mode === 'ask') {
      var webToggle = element('label', 'blog-ai__web-toggle'); ui.webSearch = element('input'); ui.webSearch.type = 'checkbox';
      ui.webSearch.setAttribute('aria-label', '联网检索'); ui.webHint = element('span', '', '联网检索待服务器启用');
      webToggle.append(ui.webSearch, ui.webHint); ui.form.insertBefore(webToggle, context.tour ? ui.suggestions : actions);
    }
    if((mode === 'chat' || mode === 'ask') && !context.tour) ui.scroll.append(intro, ui.thread, ui.form); else ui.scroll.append(intro, ui.form, ui.thread);
    root.append(header, ui.scroll); host.replaceChildren(root); updateControls();

    if((mode === 'chat' || mode === 'ask') && !context.tour) {
      ui.actionEntry = button('blog-ai__play-entry', '站内操作 · 音乐 / 设置 / 数据', 'spark');
      ui.actionEntry.setAttribute('aria-pressed', 'false'); intro.appendChild(ui.actionEntry);
      var controlHelp = element('div', 'blog-ai__control-help'); controlHelp.hidden = true;
      ui.controlHint = element('p', 'blog-ai__field-hint'); controlHelp.appendChild(ui.controlHint);
      ['播放音乐', '音量调到30%', '查看当前页面浏览量', '打开关于本站'].forEach(function(text) {
        var example = button('blog-ai__suggestion', text);
        example.addEventListener('click', function() { if(!controller && !actionsLoading) { ui.question.value = text; updateControls(); prepareLocalInput(); ui.question.focus({ preventScroll: true }); } }, { signal: life.signal });
        controlHelp.appendChild(example);
      }); intro.appendChild(controlHelp);
      ui.actionEntry.addEventListener('click', function() {
        if(controller || actionsLoading || dead) return;
        if(experience) chooseExperience('', null);
        actionMode = !actionMode; verificationPending = null; root.dataset.controls = String(actionMode);
        ui.actionEntry.setAttribute('aria-pressed', String(actionMode));
        ui.actionEntry.querySelector('span').textContent = actionMode ? '返回自由问答' : '站内操作 · 音乐 / 设置 / 数据';
        controlHelp.hidden = !actionMode; ui.suggestions.hidden = actionMode;
        if(ui.webSearch) ui.webSearch.parentElement.hidden = actionMode;
        ui.playEntry.hidden = actionMode;
        ui.question.placeholder = actionMode ? '例如：播放 Girl In the Mirror；把背景改为简洁主题色；查看本文评论数…' : spec.placeholder;
        ui.send.querySelector('span').textContent = actionMode ? '生成操作卡片' : spec.send;
        questionLabel.textContent = actionMode ? '你想做什么' : spec.label || '问题';
        announce(actionMode ? '可自然描述你的需求，按钮确认后才会执行；本地控制不依赖 AI 连接。' : '已回到自由问答。'); updateControls();
        if(actionMode) void loadActions().catch(function() { if(!dead) announce('站内操作暂时加载失败，请再点一次重试。', 'error'); });
      }, { signal: life.signal });
      ui.playEntry = button('blog-ai__play-entry', '站内玩法 · 导航 / 漫游', 'spark');
      var playSlot = element('div', 'blog-ai__play-slot'); playSlot.hidden = true;
      intro.appendChild(ui.playEntry); ui.scroll.insertBefore(playSlot, ui.thread);
      function chooseExperience(next, settings) {
        if(dead || controller) return;
        drafts[experience] = ui.question.value;
        experience = next; verificationPending = null; root.dataset.experience = next;
        ui.question.value = drafts[next] || '';
        ui.question.maxLength = next ? 240 : 1000;
        ui.question.placeholder = settings ? settings.placeholder : spec.placeholder;
        questionLabel.textContent = settings ? settings.label : spec.label || '问题';
        ui.send.querySelector('span').textContent = settings ? settings.send : spec.send;
        ui.suggestions.hidden = !!next;
        if(ui.webSearch) ui.webSearch.parentElement.hidden = !!next;
        turns.forEach(function(turn) { turn.node.hidden = turn.experience !== next; });
        ui.thread.hidden = !turns.some(function(turn) { return turn.experience === next; });
        playSlot.hidden = !next;
        ui.playEntry.textContent = next ? '返回自由问答' : '站内玩法 · 导航 / 漫游';
        // Intent UI before the reply thread keeps the next action discoverable on phones.
        if(next) ui.scroll.insertBefore(ui.form, ui.thread); else ui.scroll.appendChild(ui.form);
        announce(next ? '先描述想法，再生成建议；不会自动执行。' : '已回到自由问答。');
        updateControls(); ui.scroller.scrollTop = 0;
      }
      ui.playEntry.addEventListener('click', async function() {
        if(dead || controller || playgroundLoading) return;
        if(experience) { chooseExperience('', null); return; }
        if(playground) { playground.select('navigate'); return; }
        playgroundLoading = true; updateControls();
        try {
          var api = await window.ShokaFeatures.load('ai_playground');
          if(dead) return;
          playground = api.mount(playSlot, { choose: chooseExperience, signal: life.signal,
            example: function(text) { if(!controller) { ui.question.value = text; updateControls(); ui.question.focus({ preventScroll: true }); } },
            edit: function() { if(!controller && !dead) { ui.scroller.scrollTop = 0; ui.question.focus({ preventScroll: true }); } }
          });
          playground.select('navigate');
        } catch(error) { if(!dead) announce('玩法暂时加载失败，请再点一次重试；自由问答仍可使用。', 'error'); }
        finally { playgroundLoading = false; if(!dead) updateControls(); }
      }, { signal: life.signal });
    }

    async function loadActions() {
      if(siteActions) return;
      if(actionsRequest) return actionsRequest;
      actionsLoading = true; updateControls();
      actionsRequest = (async function() {
        try {
          actionsAPI = await window.ShokaFeatures.load('ai_actions');
          if(dead) return;
          siteActions = actionsAPI.create({ signal: life.signal, leave: function() {
            if(callbackOptions.onControlLeave) callbackOptions.onControlLeave(); else close();
          } });
        } finally { actionsRequest = null; actionsLoading = false; if(!dead) updateControls(); }
      }());
      return actionsRequest;
    }
    async function checkStatus() {
      if(!base || dead || statusController) return;
      var check = new AbortController(); statusController = check;
      connection = 'checking'; service = null; statusText = '正在检查连接…'; updateControls();
      var checkTimer = setTimeout(function() { check.abort(); }, 7000); statusTimer = checkTimer;
      try {
        var response = await fetch(base + '/api/public/status', { signal: check.signal, credentials: 'omit', cache: 'no-store', referrerPolicy: 'no-referrer', redirect: 'error', headers: { Accept: 'application/json' } });
        if(!response.ok) throw new Error('unavailable'); var data = await response.json();
        if(dead || statusController !== check) return;
        if(!data || typeof data !== 'object' || typeof data.enabled !== 'boolean' || typeof data.available !== 'boolean'
          || !data.features || typeof data.features[mode] !== 'boolean') throw new Error('invalid-status');
        service = data; checkedAt = Date.now(); continuationAvailable = data.continuation === true;
        connection = data.enabled && data.available && data.features[mode] && data.paidEnabled !== false ? 'connected' : 'offline';
        statusText = connection === 'connected' ? '已连接 · 发送后才会调用 AI'
          : !data.enabled ? 'AI 服务已关闭 · 暂时无法连接' : !data.features[mode] ? '当前 AI 功能暂不可用' : 'AI 服务暂不可用 · 请稍后重新连接';
      } catch(error) {
        if(dead || statusController !== check) return; service = null; connection = 'offline'; statusText = '连接 AI 失败 · 请重新连接';
      } finally {
        clearTimeout(checkTimer); if(statusTimer === checkTimer) statusTimer = null; if(statusController === check) statusController = null; if(!dead) { updateControls(); prepareLocalInput(); }
      }
    }
    async function submit(proof, resumeTurn) {
      updateControls(); if(dead || controller || (resumeTurn ? (!continuationAvailable || !resumeTurn.answer || resumeTurn.completed || unavailable()) : ui.send.disabled)) return;
      var question = ui.question.value.trim(), payload, controlRequest = !!(proof && verificationPending && verificationPending.turn.control);
      var actionIntent = actionMode || actionsAPI || /^(?:请|麻烦)?(?:帮我|给我)?(?:播放|暂停|停止|继续播放|上一首|下一首|静音|取消静音|打开|前往|进入|搜索|查找|查看|查询|开启|切换|恢复|回到|滚动到|到页面|跳到|减弱|减少|关闭动效|把(?:音量|背景|主色|辅色|纹理|文章|正文)|音量|背景|纹理|字号|行高|段落间距|正文宽度|主色|辅色|首页(?:排列|布局)|文章(?:字号|行高)|正文(?:字号|行高)|列表播放|随机播放|单曲循环|友链)/.test(question)
        || /(?:浏览量|访问量|评论数|评论者|文章统计|访问统计)[？?]?$/.test(question)
        || /(?:音乐|音量|声音|页面|模式|放歌|换首|想听|刺眼|带我去|去看看)/.test(question);
      if(!actionMode && !actionsAPI && /(?:如何|怎么|怎样|为什么|示例|代码)/.test(question)) actionIntent = false;
      if(!proof && !resumeTurn && !experience && !context.tour && actionIntent && (mode === 'chat' || mode === 'ask') && window.ShokaFeatures) {
        try { await loadActions(); } catch(error) { if(!dead) announce('站内操作暂时加载失败，请重试。', 'error'); if(actionMode) return; }
        if(dead || controller || ui.question.value.trim() !== question) return;
        var local = actionsAPI && actionsAPI.localPlan(question);
        if(local) {
          var localTurn = appendTurn(question, true); localTurn.completed = true;
          localTurn.answer = local.summary + '\n' + local.actions.map(function(action) { return actionsAPI.describe(action); }).join('\n');
          localTurn.label.textContent = '本地识别 · 未调用模型'; localTurn.node.dataset.turnState = 'complete';
          siteActions.render(local, localTurn.answerNode); ui.question.value = ''; announce('已准备操作卡片，点击确认后生效。', 'success'); updateControls();
          followingOutput = true; scrollOutput(); return;
        }
        if(actionMode || actionsAPI && actionsAPI.commandIntent(question)) {
          controlRequest = true;
        }
      }
      // Local plans above must not depend on the server switch. Actual model
      // requests retain the original explicit connection and stale-status gate.
      if(unavailable()) { announce(controlRequest ? '这句话需要 AI 理解，但当前服务不可用。可先用“声音小一点”“换首歌”等常用本地操作，或重新连接后再试。' : 'AI 尚未连接，暂时不能生成回答；站内常用操作仍可本地使用。', 'error'); updateControls(); return; }
      if(Date.now() - checkedAt > 10000) {
        await checkStatus(); updateControls();
        if(dead || controller || unavailable() || (!resumeTurn && ui.question.value.trim() !== question)) return;
      }
      if(controlRequest && (!service || !service.features || service.features.control !== true)) { announce('当前 AI 后端还未启用自然语言操作解析，可先使用常用本地指令。后端更新后会自动支持。'); return; }
      if(resumeTurn) payload = Object.assign({}, resumeTurn.payload, { continueFrom: resumeTurn.answer.slice(-1800) });
      else {
        if(mode === 'chat' || mode === 'ask') payload = { question: question };
        if(controlRequest) payload.control = true;
        if(!experience && (mode === 'ask' || mode === 'chat')) attachPageContext(payload, context, service);
        if(experience && playground) payload.question = playground.prompt(experience, question);
        if(context.tour && service && service.features && service.features.tour === true) payload.tour = true;
        if(!experience && !controlRequest && (mode === 'chat' || mode === 'ask')) { var history = chatHistory(); if(history.length) payload.history = history; }
        if(!experience && !controlRequest && ui.webSearch && ui.webSearch.checked && !ui.webSearch.disabled) payload.webSearch = true;
        if(mode === 'guide') payload = { path: context.path };
        if(mode === 'explain') { payload = { text: ui.selection.value.trim() }; if(context.path) payload.path = context.path; }
      }
      var pending = verificationPending;
      if(proof && (!pending || JSON.stringify(payload) !== pending.body)) { verificationPending = null; announce('内容已变化，请重新发送。'); updateControls(); return; }
      if(proof) payload.verification = proof;
      verificationPending = null;
      var request = new AbortController(), id = ++token, timedOut = false, failed = false, settled = false, reader = null;
      var limits = transportLimits(service && service.transport), startedAt = Date.now();
      function scheduleTimeout() {
        clearTimeout(timer);
        // Meta can update stale status limits, but must never restart the total request clock.
        timer = setTimeout(function() { timedOut = true; request.abort(); }, Math.max(0, startedAt + limits.timeoutMs - Date.now()));
      }
      followingOutput = mode !== 'guide' && (mode === 'chat' || mode === 'ask' || ui.scroll.scrollHeight - ui.scroll.scrollTop - ui.scroll.clientHeight < 120);
      controller = request; var turn = resumeTurn || (proof && pending ? pending.turn : appendTurn(question, controlRequest));
      if(!turn.payload) turn.payload = Object.assign({}, payload);
      var answerAtStart = turn.answer.length;
      turn.resume.hidden = true;
      signalState('thinking'); announce('正在连接，请稍候…'); updateControls(); scrollOutput(); scheduleTimeout();
      try {
        var response = await fetch(base + '/api/public/' + mode, { method: 'POST', credentials: 'omit', cache: 'no-store', referrerPolicy: 'no-referrer', redirect: 'error', signal: request.signal, headers: { 'Content-Type': 'application/json', Accept: 'text/event-stream' }, body: JSON.stringify(payload) });
        if(!response.ok) {
          var problem = {}; try { problem = await response.json(); } catch(error) { /* Never display raw provider errors. */ }
          var code = problem.code || (problem.error && problem.error.code) || problem.error;
          if(response.status === 403 && code === 'CAPTCHA_REQUIRED' && validChallenge(problem.error.challenge)) {
            delete payload.verification;
            verificationPending = { challenge: problem.error.challenge, body: JSON.stringify(payload), turn: turn };
            turn.label.textContent = '等待安全验证'; turn.node.dataset.turnState = 'challenge';
            announce('请求较频繁，请先完成安全验证；验证前不会调用 AI。'); return;
          }
          if(response.status === 429 && !code) code = 'RATE_LIMITED';
          if(['PAID_DISABLED', 'PUBLIC_DISABLED', 'AI_DISABLED', 'SERVICE_DISABLED', 'PUBLIC_EXPIRED', 'AI_NOT_CONFIGURED', 'KNOWLEDGE_NOT_READY'].includes(code)) {
            connection = 'offline'; service = null; statusText = errorMessage(code);
          }
          var wait = response.headers.get('Retry-After');
          var waitText = response.status === 429 && typeof wait === 'string' && /^\d{1,5}$/.test(wait) && +wait >= 1 && +wait <= 3600
            ? ' 请至少等待 ' + wait + ' 秒后再试。' : '';
          throw new Error(errorMessage(code) + waitText);
        }
        if(!response.body || !/text\/event-stream/i.test(response.headers.get('Content-Type') || '')) throw new Error('服务器没有返回有效的流式回答，请稍后重试。');
        reader = response.body.getReader(); var decoder = new TextDecoder('utf-8'), buffer = '', bytes = 0;
        function frame(text) {
          var event = 'message', lines = [];
          text.split('\n').forEach(function(line) { if(line.indexOf('event:') === 0) event = line.slice(6).trim(); else if(line.indexOf('data:') === 0) lines.push(line.slice(5).replace(/^ /, '')); });
          if(!lines.length) return; var data;
          try { data = JSON.parse(lines.join('\n')); } catch(error) { throw new Error('回答数据不完整，请稍后手动重试。'); }
          if(!data || typeof data !== 'object') return;
          if(event === 'meta') { limits = transportLimits(data.transport, limits); scheduleTimeout(); }
          if(bytes > limits.maxResponseBytes) throw new Error('回答数据过大，已停止接收。');
          if(event === 'meta' && !turn.experience && !turn.control && Array.isArray(data.sources)) {
            turn.sources = data.sources.slice(0, 12).map(function(raw, index) { var source = safeSource(raw); if(source) source.number = index + 1; return source; }).filter(Boolean);
            renderSources(turn);
            if(Array.isArray(data.references)) {
              var references = data.references.slice(0, 8).map(function(raw) { return safeSource(Object.assign({}, raw, { kind: 'reference' })); }).filter(Boolean);
              turn.referencesNode.hidden = !references.length; turn.referencesNode.replaceChildren();
              if(references.length) turn.referencesNode.appendChild(element('p', 'blog-ai__label', '原文外部参考 · 未实时读取全文'));
              references.forEach(function(source) { var link = sourceLink(source, null, 'blog-ai__reference'); link.textContent = source.title; turn.referencesNode.appendChild(link); });
            }
            if(data.webSearch && data.webSearch !== 'off') {
              turn.searchState.hidden = false;
              turn.searchState.textContent = data.webSearch === 'ok' ? '已实时搜索外部摘要 · 不代表已阅读全文' : '外部检索未获得可用结果 · 以下未完成实时核实';
            }
            scrollOutput();
          }
          if(event === 'delta' && typeof data.text === 'string') {
            if(turn.answer.length - answerAtStart + data.text.length > limits.maxAnswerChars) throw new Error('回答已达到本次显示上限，可点击继续生成。');
            turn.answer += data.text;
            // Model output stays inert text. Never parse it as HTML or executable links.
            if(turn.control) turn.answerNode.textContent = '正在整理操作建议，不会自动执行…';
            else if(turn.experience) turn.answerNode.textContent = '正在构思你的站内玩法…';
            else {
              if(!turn.answerText) { turn.answerText = document.createTextNode(turn.answer.slice(0, -data.text.length)); turn.answerNode.replaceChildren(turn.answerText); }
              turn.answerText.appendData(data.text);
            }
            turn.label.textContent = '正在回答'; turn.node.dataset.turnState = 'answering';
            if(activeState !== 'answering') signalState('answering'); announce('正在回答…');
            scheduleOutputScroll();
          }
          if(event === 'error') throw new Error(errorMessage(data.code));
          if(event === 'done') {
            if(data.ok === false) throw new Error(errorMessage(data.code)); settled = true; turn.completed = data.truncated !== true; turn.node.dataset.turnState = turn.completed ? 'complete' : 'partial';
            if(turn.control) {
              var plan = !data.truncated && actionsAPI && actionsAPI.parse(turn.answer);
              if(!plan || !siteActions.render(plan, turn.answerNode)) turn.answerNode.textContent = '没有收到完整、受支持的操作方案，未执行任何操作。请换个描述后重试。';
            } else if(turn.experience && playground) {
              if(data.truncated || !playground.render(turn.experience, turn.answer, turn.answerNode)) {
                turn.answerNode.textContent = '这次没有收到完整、可用的方案。没有执行操作；可以换个描述后手动重试。';
              }
            } else renderAnswer(turn);
            if(context.tour && typeof callbackOptions.onTour === 'function') callbackOptions.onTour(turn.sources.filter(function(source) { return source.kind === 'blog'; }));
            turn.label.textContent = turn.control ? '操作建议 · 尚未执行' : data.truncated ? 'AI 回答 · 尚未写完' : 'AI 回答';
            announce(turn.control ? '只有完整、受支持的方案会显示按钮；点击后才执行。' : data.truncated ? '回答已达到本次长度上限，可点击“继续生成”补全；续写会计入一次 AI 额度。' : mode === 'chat' || mode === 'ask' ? '回答已完成，请核对重要信息。' : '回答已完成，请结合原文核对。', data.truncated ? '' : 'success');
          }
        }
        while(!settled) {
          var chunk = await reader.read(); if(dead || id !== token) return;
          if(chunk.done) { buffer += decoder.decode(); break; }
          bytes += chunk.value.byteLength; if(bytes > 25165824) throw new Error('回答数据过大，已停止接收。');
          buffer += decoder.decode(chunk.value, { stream: true }); buffer = buffer.replace(/\r\n/g, '\n'); var boundary;
          while((boundary = buffer.indexOf('\n\n')) !== -1 && !settled) { var part = buffer.slice(0, boundary); buffer = buffer.slice(boundary + 2); frame(part); }
          // A coalesced first chunk may contain meta plus the answer: negotiate before checking its total.
          if(bytes > limits.maxResponseBytes) throw new Error('回答数据过大，已停止接收。');
        }
        if(!settled) throw new Error('连接提前结束，下面的回答可能不完整。请稍后手动重试。');
        if(!turn.answer.trim()) throw new Error('没有收到有效回答，请稍后手动重试。');
        if(mode === 'chat' || mode === 'ask') ui.question.value = '';
      } catch(error) {
        if(dead || id !== token) return; failed = true;
        if(error instanceof TypeError || timedOut) { connection = 'offline'; service = null; statusText = '连接 AI 失败 · 请重新连接'; }
        turn.completed = false; turn.node.dataset.turnState = 'error';
        if(turn.experience || turn.control) turn.answerNode.textContent = '未获得完整方案，没有执行操作。';
        else if(turn.answer) renderAnswer(turn);
        turn.label.textContent = turn.answer ? '回答中断 · 内容可能不完整' : '未能生成回答'; signalState('error');
        announce(timedOut ? '等待超时，已停止请求。请稍后手动重试。' : error.name === 'AbortError' ? '已停止生成。' : error instanceof TypeError ? '网络连接失败，请稍后重试。' : error.message, 'error');
      } finally {
        if(reader) { try { await reader.cancel(); } catch(error) { /* Best-effort cancellation; never retry a paid request. */ } }
        if(id === token) { clearTimeout(timer); timer = null; cancelOutputScroll(); controller = null; if(!dead) { if(!failed) signalState('idle'); updateControls(); scrollOutput(); } }
      }
    }
    var handle = {
      destroy: destroy, focus: focus,
      // A parent may hide and stop one panel without losing its existing answers.
      close: function() { stop(); }, key: key,
      update: function(next) {
        callbackOptions = next || {};
        if(typeof callbackOptions.question === 'string' && !ui.question.value && !controller) ui.question.value = callbackOptions.question.slice(0, 1000);
        updateControls(); signalState(activeState);
      }
    };
    signalState('idle');
    window.addEventListener('focus', function() { if(!dead && !controller && Date.now() - checkedAt > 30000) void checkStatus(); }, { signal: life.signal });
    if(mode === 'explain' && typeof options.text === 'string' && options.text.length > 4000) announce('选区较长，仅保留前 4000 字，请确认要发送的内容。');
    checkStatus(); return handle;
  }
  function mountEmbedded(host, options) {
    if(!host || host.nodeType !== 1 || !host.isConnected) return null;
    options = options || {}; var context = cleanContext(options), existing = instances.get(host);
    if(existing && existing.key === contextKey(context)) { existing.update(options); existing.focus(); return existing; }
    if(existing) existing.destroy(); var handle = createInstance(host, options, context); instances.set(host, handle);
    // Inline guides never steal focus or move the document when first mounted.
    if(context.mode !== 'guide') requestAnimationFrame(function() { if(instances.get(host) === handle) handle.focus(); }); return handle;
  }
  function destroyHost(host) { var instance = instances.get(host); if(instance) instance.destroy(); }
  function destroy() { Array.from(instances.values()).forEach(function(instance) { instance.destroy(); }); }
  window.addEventListener('pjax:send', destroy); window.addEventListener('pagehide', destroy);
  window.ShokaBlogAI = {
    mountEmbedded: mountEmbedded, destroyHost: destroyHost,
    destroyEmbedded: function(host) { if(host) destroyHost(host); }, destroy: destroy,
    open: function(options) { return options && options.host ? mountEmbedded(options.host, options) : null; },
    close: function(host) { var instance = instances.get(host); if(instance) instance.close(); }
  };
}());
