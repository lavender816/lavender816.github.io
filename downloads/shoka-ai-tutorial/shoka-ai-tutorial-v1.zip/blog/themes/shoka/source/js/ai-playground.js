(function() {
  'use strict';
  // No requests here. The existing AI panel owns streaming, quotas, cancellation and CAPTCHA.
  // Model output can select an ID, never a URL, selector or command.
  var destinations = [
    ['home', '博客首页', '/', '从最新文章开始'],
    ['archives', '时光归档', '/archives/', '沿着时间翻阅文章'],
    ['categories', '文章分类', '/categories/', '按主题找文章'],
    ['tags', '标签索引', '/tags/', '从一个关键词出发'],
    ['gallery', '个人图集', '/gallery/', '看看风景与封面图集'],
    ['talking', '个人随笔', '/talking/', '读一些日常片段'],
    ['music', '黑胶播放室', '/about/#about-gramophone', '挑一张唱片，手动开始播放'],
    ['universe', '博客宇宙', '/universe/', '探索三维星系与数据艺术'],
    ['resources', '实用工具', '/resources/', '逛逛工具和资源导航'],
    ['writer', '文章写作', '/writer/', '在本地草稿里写点东西'],
    ['about', '关于博主', '/about/', '认识这座博客的主人'],
    ['aboutsite', '关于本站', '/aboutsite/', '看看博客的成长记录'],
    ['friends', '友情链接', '/friends/', '去其他博客串门'],
    ['statistics', '创作统计', '/statistics/', '从图表看文章与创作'],
    ['pageviews', '访问统计', '/pageviews/', '看看公开的访问趋势']
  ];
  var settings = [
    ['dark', '切换夜间模式', 'theme', 'dark'], ['light', '切换日间模式', 'theme', 'light'],
    ['reduce', '减弱全站动效', 'motion', 'reduce'], ['motion', '动效跟随系统', 'motion', 'system'],
    ['plain', '简洁主题色背景', 'background', 'plain'], ['banner', '恢复图片横幅', 'background', 'banner'],
    ['grid', '首页双列排列', 'layout', 'grid'], ['list', '首页单列排列', 'layout', 'list']
  ];
  var specs = {
    navigate: { title: '自然语言导航', label: '你想去哪里，或调整什么？', send: '找到入口',
      placeholder: '如：带我去看图片，顺便减弱动效',
      hint: '说一句话，找到页面或显示设置。只提供确认按钮，不替你执行。',
      examples: ['想看看博客里能玩的东西', '打开图集，切到夜间并减弱动效'] },
    mood: { title: '心情漫游', label: '此刻的心情，想怎么逛？', send: '生成漫游路线',
      placeholder: '如：忙了一天，想花十分钟放空一下',
      hint: '用几个站内角落串起一段小旅行，不安排课程，也不自动播放音乐。',
      examples: ['想放松十分钟，听音乐看看风景', '有点无聊，想发现博客里的新奇玩法'] }
  };
  function clean(value, size) {
    return typeof value === 'string' ? value.replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, size) : '';
  }
  function prompt(kind, question) {
    if(!Object.hasOwn(specs, kind)) throw new Error('Unknown playground');
    var start = '请为博客的站内玩法生成一个建议，不声称已执行。只输出一个JSON对象，不要Markdown、引文编号、网址或代码。';
    var catalog = destinations.map(function(d) { return d[0] + '=' + d[1]; }).join('，');
    if(kind === 'navigate') start += '任务NAV。页面ID：' + catalog + '。设置ID：' + settings.map(function(s) { return s[0] + '=' + s[1]; }).join('，') + '。格式{"title":"一句标题","reason":"简短说明","pages":["页面ID"],"settings":["设置ID"]}。按明确意图给1至3个页面，或设置；未要求的设置不推荐，不存在的能力不编造。不匹配可返回空数组。';
    if(kind === 'mood') start += '任务MOOD。可用地点：' + catalog + '。格式{"title":"旅程名字","reason":"开场白","stops":[{"id":"地点ID","reason":"为什么适合此刻","minutes":3}]}。选2至4个不同地点，每站1至20分钟；音乐只代表留声机入口，不编造歌单和具体歌曲；不要安排测验或课程。';
    var value = start + '\n用户想法：' + clean(question, 240);
    if(value.length > 1000) throw new Error('Playground prompt too long');
    return value;
  }
  function parse(kind, text) {
    if(!Object.hasOwn(specs, kind) || typeof text !== 'string' || text.length > 8000) return null;
    var value;
    try { value = JSON.parse(text.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '')); } catch(error) { return null; }
    if(!value || Array.isArray(value) || typeof value !== 'object') return null;
    var result = { title: clean(value.title, 48), reason: clean(value.reason, 180) };
    if(!result.title) return null;
    function ids(list, catalog, limit) {
      return Array.isArray(list) ? Array.from(new Set(list.filter(function(id) { return typeof id === 'string' && catalog.some(function(row) { return row[0] === id; }); }))).slice(0, limit) : [];
    }
    if(kind === 'navigate') {
      result.pages = ids(value.pages, destinations, 3); result.settings = ids(value.settings, settings, 4);
      // Reject conflicting values for the same setting rather than silently choosing one.
      var groups = new Set();
      result.settings = result.settings.filter(function(id) {
        var group = settings.find(function(s) { return s[0] === id; })[2];
        if(groups.has(group)) return false; groups.add(group); return true;
      });
    }
    if(kind === 'mood') {
      var seen = new Set();
      result.stops = (Array.isArray(value.stops) ? value.stops : []).filter(function(stop) {
        if(!stop || !destinations.some(function(d) { return d[0] === stop.id; }) || seen.has(stop.id)) return false;
        seen.add(stop.id); return true;
      }).slice(0, 4).map(function(stop) { return { id: stop.id, reason: clean(stop.reason, 110), minutes: Number.isFinite(stop.minutes) ? Math.max(1, Math.min(20, Math.round(stop.minutes))) : 3 }; });
      if(result.stops.length < 2) return null;
    }
    return result;
  }
  function el(tag, cls, text) { var node = document.createElement(tag); if(cls) node.className = cls; if(text) node.textContent = text; return node; }
  function btn(text, cls) { var node = el('button', cls || 'ai-play__button', text); node.type = 'button'; return node; }
  function mount(host, options) {
    var selected = 'navigate', busy = false, dead = false;
    var life = new AbortController(), signal = life.signal;
    var root = el('div', 'ai-play'), tabs = el('div', 'ai-play__tabs'), hint = el('p', 'ai-play__hint'), samples = el('div', 'ai-play__examples');
    tabs.setAttribute('role', 'group'); tabs.setAttribute('aria-label', '选择站内玩法');
    var buttons = Object.keys(specs).map(function(key, index) {
      var node = btn('', 'ai-play__tab'); node.dataset.play = key;
      node.title = specs[key].title;
      node.append(el('span', 'ai-play__tab-number', '0' + (index + 1)), el('span', '', { navigate: '自然导航', mood: '心情漫游' }[key]));
      node.addEventListener('click', function() { if(!busy) select(key); }, { signal: signal }); tabs.appendChild(node); return node;
    });
    function select(key) {
      if(dead || busy || !Object.hasOwn(specs, key)) return;
      selected = key; var spec = specs[key]; hint.textContent = spec.hint;
      buttons.forEach(function(node) { node.setAttribute('aria-pressed', String(node.dataset.play === key)); });
      samples.replaceChildren(); spec.examples.forEach(function(text) {
        var sample = btn(text, 'ai-play__example'); sample.addEventListener('click', function() { if(!busy) options.example(text); }, { signal: signal }); samples.appendChild(sample);
      });
      options.choose(key, spec);
    }
    root.append(tabs, hint, samples); host.replaceChildren(root);
    function render(kind, answer, target) {
      var plan = parse(kind, answer); if(!plan || dead) return false;
      var card = el('div', 'ai-play__result'); card.append(el('h4', 'ai-play__result-title', plan.title), el('p', 'ai-play__reason', plan.reason));
      function destination(id, reason, number, minutes) {
        var d = destinations.find(function(row) { return row[0] === id; }), row = el('div', 'ai-play__destination');
        if(number) row.appendChild(el('span', 'ai-play__number', String(number).padStart(2, '0')));
        var content = el('div', 'ai-play__destination-copy'), link = el('a', 'ai-play__link', d[1] + ' ↗');
        link.href = d[2];
        if(kind === 'mood') { link.target = '_blank'; link.rel = 'noopener noreferrer'; link.setAttribute('aria-label', d[1] + '，在新页面打开'); }
        content.append(link, el('p', '', reason || d[3]));
        if(minutes) content.appendChild(el('small', '', '建议停留 ' + minutes + ' 分钟'));
        row.appendChild(content); card.appendChild(row);
      }
      if(kind === 'navigate') {
        plan.pages.forEach(function(id) { destination(id); });
        if(!plan.pages.length && !plan.settings.length) card.appendChild(el('p', 'ai-play__reason', '没有匹配到已支持的操作，请换一种说法；暂不支持站外操作。'));
        var actions = el('div', 'ai-play__setting-actions');
        plan.settings.forEach(function(id) {
          var item = settings.find(function(s) { return s[0] === id; }), action = btn(item[1] + ' · 确认');
          action.addEventListener('click', async function() {
            if(busy || dead || action.disabled) return; action.disabled = true;
            try {
              if(item[2] === 'theme') window.ShokaFeatures.setTheme(item[3]);
              else {
                var api = await window.ShokaFeatures.load('display_preferences');
                if(dead || !action.isConnected) return;
                var patch = {}; patch[item[2]] = item[3]; api.update(patch);
              }
              if(!dead) { action.textContent = item[1] + ' · 已应用'; action.setAttribute('aria-label', action.textContent); }
            } catch(error) { if(!dead) { action.textContent = item[1] + ' · 重试'; action.disabled = false; } }
          }, { signal: signal }); actions.appendChild(action);
        }); card.appendChild(actions);
        card.appendChild(el('small', 'ai-play__footnote', '仅支持这些站内入口与显示设置；点击后才生效。'));
      }
      if(kind === 'mood') {
        card.appendChild(el('p', 'ai-play__route-meta', plan.stops.length + ' 站 · 约 ' + plan.stops.reduce(function(n, stop) { return n + stop.minutes; }, 0) + ' 分钟'));
        plan.stops.forEach(function(stop, i) { destination(stop.id, stop.reason, i + 1, stop.minutes); });
        card.appendChild(el('small', 'ai-play__footnote', '每站在新页面打开，路线留在这里；音乐由你手动播放。建议时长仅供参考。'));
      }
      var edit = btn('换个想法 / 切换玩法', 'ai-play__edit');
      edit.addEventListener('click', function() { if(!dead && !busy && options.edit) options.edit(); }, { signal: signal });
      card.appendChild(edit); target.replaceChildren(card); return true;
    }
    function destroy() { dead = true; life.abort(); root.remove(); }
    if(options.signal) options.signal.addEventListener('abort', destroy, { once: true, signal: signal });
    return { select: select, prompt: prompt, render: render, destroy: destroy,
      setBusy: function(value) { busy = value; root.querySelectorAll('button').forEach(function(node) { node.disabled = value; }); }
    };
  }
  if(typeof module === 'object' && module.exports) module.exports = { prompt: prompt, parse: parse, destinations: destinations };
  if(typeof window !== 'undefined') window.BlogAIPlayground = { mount: mount };
}());
