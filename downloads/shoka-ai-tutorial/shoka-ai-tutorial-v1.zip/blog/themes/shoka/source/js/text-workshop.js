(function(global) {
  'use strict';
  // A page-local workspace: no model/status/catalog request until explicit intent.
  // Model content stays source text in drafts; optional Markdown rendering only
  // creates safe DOM, never executes model HTML or loads its embedded resources.
  var VERSION = 1, MAX_NODES = 24, MAX_BYTES = 1600000, MAX_INPUT = 3000, MAX_REQUEST_INPUT = 3200, MAX_ANSWER = 3145728, prefix = 'shoka-text-workshop-v1:';
  function transportLimits(value) {
    var valid = plain(value);
    function integer(name, min, max) { return valid && Number.isSafeInteger(value[name]) && value[name] >= min && value[name] <= max; }
    return {
      maxResponseBytes: integer('maxResponseBytes', 65536, 25165824) ? Math.max(1048576, value.maxResponseBytes) : 1048576,
      maxAnswerChars: integer('maxAnswerChars', 65536, MAX_ANSWER) ? value.maxAnswerChars : 131072,
      timeoutMs: integer('timeoutMs', 1000, 120000) ? Math.max(90000, value.timeoutMs + 5000) : 125000
    };
  }
  var specs = {
    story: { name: '文字分岔剧场', label: '写下开场，或者你接下来的行动', send: '生成这一幕',
      placeholder: '凌晨两点，一家已经关门的唱片店里，突然传出了音乐。',
      sample: '凌晨两点，一家已经关门的唱片店里，突然传出了音乐。我停在门口，发现橱窗里多了一张没有名字的唱片。',
      hint: '每次生成都是一个新分支。回到旧节点再行动，原来的故事不会被覆盖。所有情节均为虚构。',
      options: ['温柔奇幻', '城市悬疑', '轻松日常', '科幻冒险'], optionLabel: '故事气质' },
    phrasing: { name: '措辞试衣间', label: '想表达什么？给谁说？', send: '试穿几种表达',
      placeholder: '想拒绝朋友的周末邀请，但希望表达得亲切、明确。',
      sample: '朋友邀请我周末聚会，但我想独处休息。请帮我真诚地拒绝，表达感谢，不编造借口，也不留下不确定的承诺。',
      hint: '挑选一个版本，可以锁住喜欢的句子再调整，也能模拟后续对话。模拟不代表对方真实的想法。',
      options: ['亲切而明确', '简洁直接', '正式礼貌', '轻松自然'], optionLabel: '希望的语气' },
    roundtable: { name: '观点圆桌', label: '把一个有取舍的问题放到桌上', send: '开始这一轮圆桌',
      placeholder: '个人网站该追求功能丰富，还是尽量保持简单？',
      sample: '个人网站应该追求功能丰富，还是保持极简？我希望兼顾创作乐趣、访客体验和长期维护。',
      hint: '由 AI 模拟不同观察角度，不冒充真实专家。点击某个观点继续追问，所有轮次都可以回看。',
      options: ['平衡看待', '重视体验', '重视可维护性', '重视创作自由'], optionLabel: '本轮重心' },
    clues: { name: '线索工作台', label: '这次想理清什么？', send: '整理线索与依据',
      placeholder: '区分这些材料中的事实、推断、矛盾与尚待确认的信息。',
      sample: '请梳理下面材料：哪些是原文明确记载的，哪些是判断，哪些存在冲突，还有什么需要确认？',
      hint: '依据来自你主动添加的材料。点开引文回看原句，也可以手动纠正卡片的分类。判断不等于事实。', materials: true,
      options: ['事实与判断', '事件脉络', '矛盾与缺口'], optionLabel: '整理重点',
      samples: [{ title: '记录 A', date: '', text: '周一的会议记录写着：暂定周五发布，测试结果出来后再确认。' }, { title: '记录 B', date: '', text: '周三有人在群里说：我以为已经决定周五发布，但还没看到最终确认。' }] },
    memoir: { name: '回忆编织机', label: '想把这些回忆织成什么？', send: '编织这段回忆',
      placeholder: '把这些片段写成一段朴素的随笔，保留不确定的地方。',
      sample: '把下面的真实回忆碎片整理成一段朴素温暖的随笔。不要添加我没有提到的经历，记不清的地方就保留留白。',
      hint: '只使用你提供的经历，不补写不存在的事实。生成后可先回答补充问题，再继续编织。', materials: true,
      options: ['随笔', '不必寄出的信', '回忆片段', '当时与现在'], optionLabel: '文字形式',
      samples: [{ title: '回忆片段（示例为虚构）', date: '', text: '放学后的雨天。我和朋友在面馆等雨停。记得热汤的雾气，不记得那天聊了什么。' }] },
    world: { name: '平行世界档案馆', label: '这个世界有什么不同？或想查阅哪条线索？', send: '打开一份新档案',
      placeholder: '如果城市里的植物会记录人们说过的话……',
      sample: '建立一个虚构城市：植物会记住附近人说过的话，但只在下雨时复述。通过报纸、居民留言、失物招领等文档展示这个世界。',
      hint: '报纸、信件和城市记录都是虚构档案。选择一条线索继续探索，之前的档案仍留在分支里。',
      options: ['温柔奇幻', '复古悬疑', '未来都市', '荒诞日常'], optionLabel: '世界气质' },
    archaeology: { name: '思想考古', label: '想追溯哪个想法的变化？', send: '对照文字与时间',
      placeholder: '从选中的文章里，看看对个人网站的看法有哪些变化、哪些没变。',
      sample: '只根据下面选中的文字与日期，比较其中对个人网站的看法。展示原句，区分明确变化与无法确认的部分，不推断作者人格或未记录的经历。',
      hint: '主动选择公开文章摘录，或添加自己的笔记。只发送所选材料；日期未知时不虚构时间顺序。', materials: true,
      options: ['变化与不变', '同一词语的不同含义', '语气与观点的区别'], optionLabel: '对照角度' }
  };
  function plain(value) { return value && typeof value === 'object' && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value)); }
  function fields(value, names) { return plain(value) && Object.keys(value).every(function(name) { return names.includes(name); }); }
  function text(value, max) { return typeof value === 'string' && value.length <= max && !value.includes('\0'); }
  function clean(value, max) { return typeof value === 'string' ? value.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').slice(0, max).replace(/[\uD800-\uDBFF]$/, '') : ''; }
  function editorInput(value) {
    if(typeof value !== 'string') throw new Error('输入内容格式不正确，原输入已保留。');
    var normalized = clean(value, MAX_INPUT + 2);
    if(normalized.length > MAX_INPUT) throw new Error('内容超过 ' + MAX_INPUT + ' 字符，未截断或替换原输入。请复制片段后分段编辑。');
    return normalized;
  }
  function date(value) {
    if(value === '') return true;
    if(typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    var parsed = new Date(value + 'T00:00:00Z'); return Number.isFinite(+parsed) && parsed.toISOString().slice(0, 10) === value;
  }
  function safePath(value) {
    if(typeof value !== 'string' || !/^\/posts\/[\w%.-]+\/$/.test(value) || /%(?:2f|5c|00|0a|0d)/i.test(value)) return '';
    try { return new URL(value, 'https://blog.example.com').pathname === value ? value : ''; } catch(_) { return ''; }
  }
  function materialList(value) {
    if(!Array.isArray(value) || value.length > 6) throw new Error('MATERIALS');
    var seen = new Set();
    return value.map(function(item) {
      if(!plain(item) || !/^m[1-6]$/.test(item.id) || seen.has(item.id) || !text(item.title, 120) || !date(item.date) || !text(item.text, 2000)) throw new Error('MATERIALS');
      seen.add(item.id);
      return { id: item.id, title: item.title, date: item.date, text: item.text, path: safePath(item.path), catalogId: clean(item.catalogId, 100) };
    });
  }
  function result(value, materials, maxChars) {
    maxChars = Number.isSafeInteger(maxChars) && maxChars >= 65536 && maxChars <= MAX_ANSWER ? maxChars : MAX_ANSWER;
    // Keep presentation safety/size bounds, not a second layer of content review.
    // Unexpected layouts become inert plain text instead of losing the answer.
    var raw;
    if(plain(value) && typeof value.rawText === 'string') {
      if(value.rawText.length > maxChars) throw new Error('OUTPUT_LIMIT');
      return { title: clean(value.title, 120) || 'AI 回答', summary: clean(value.summary, 1600), memory: '', cards: [], actions: [], rawText: value.rawText, ...(value.truncated === true ? { truncated: true } : {}) };
    }
    try {
    if(!fields(value, ['title', 'summary', 'memory', 'cards', 'actions', 'truncated']) || !text(value.title, 120) || !value.title.trim() || !text(value.summary, 1600) || !text(value.memory, 1800) || !Array.isArray(value.cards) || value.cards.length > 8 || !Array.isArray(value.actions) || value.actions.length > 4) throw new Error('RESULT');
    var cards = value.cards.map(function(card) {
      if(!fields(card, ['title', 'text', 'tag', 'sourceIds', 'quotes']) || !text(card.title, 120) || !card.title.trim() || !text(card.text, 2400) || !card.text.trim() || !text(card.tag, 32) || !Array.isArray(card.sourceIds) || card.sourceIds.length > 6 || card.sourceIds.some(function(id) { return !text(id, 120); }) || !Array.isArray(card.quotes) || card.quotes.length > 6) throw new Error('RESULT');
      var quotes = card.quotes.map(function(quote) {
        if(!fields(quote, ['sourceId', 'quote']) || !text(quote.sourceId, 120) || !text(quote.quote, 300)) throw new Error('RESULT');
        return { sourceId: quote.sourceId, quote: quote.quote };
      });
      return { title: card.title, text: card.text, tag: card.tag, sourceIds: Array.from(new Set(card.sourceIds)), quotes: quotes };
    });
    var actions = value.actions.map(function(action) {
      if(!fields(action, ['label', 'instruction']) || !text(action.label, 60) || !action.label.trim() || !text(action.instruction, 600) || !action.instruction.trim()) throw new Error('RESULT');
      return { label: action.label, instruction: action.instruction };
    });
    return { title: value.title, summary: value.summary, memory: value.memory, cards: cards, actions: actions, ...(value.truncated === true ? { truncated: true } : {}) };
    } catch(_) {
      raw = typeof value === 'string' ? value : JSON.stringify(value);
      if(typeof raw !== 'string' || raw.length > maxChars) throw new Error('OUTPUT_LIMIT');
      return { title: 'AI 回答', summary: '按普通文本展示模型回答。', memory: '', cards: [], actions: [], rawText: raw, ...(value && value.truncated === true ? { truncated: true } : {}) };
    }
  }
  function fresh(kind) { return { version: VERSION, kind: kind, input: '', option: specs[kind].options[0], locked: '', materials: [], nodes: [], selected: '', updatedAt: 0 }; }
  function restore(raw, kind) {
    if(!raw) return fresh(kind);
    if(typeof raw !== 'string' || raw.length > MAX_BYTES) throw new Error('DRAFT');
    var data = JSON.parse(raw);
    if(!plain(data) || data.version !== VERSION || data.kind !== kind || !text(data.input, MAX_INPUT) || !text(data.locked, 240) || !specs[kind].options.includes(data.option) || !Array.isArray(data.nodes) || data.nodes.length > MAX_NODES) throw new Error('DRAFT');
    var state = fresh(kind), ids = new Set(); state.input = data.input; state.option = data.option; state.locked = data.locked; state.materials = materialList(data.materials);
    state.nodes = data.nodes.map(function(node) {
      if(!plain(node) || !/^n[a-z0-9_-]{1,65}$/.test(node.id) || ids.has(node.id) || (node.parent && !ids.has(node.parent)) || !text(node.input, MAX_INPUT) || !Number.isFinite(node.time)) throw new Error('DRAFT');
      var materials = materialList(node.materials), response = result(node.result, materials); ids.add(node.id);
      var annotations = {};
      if(plain(node.annotations)) Object.keys(node.annotations).forEach(function(index) {
        if(/^\d$/.test(index) && response.cards[+index] && ['原文记载', '个人判断', '存在矛盾', '尚待确认'].includes(node.annotations[index])) annotations[index] = node.annotations[index];
      });
      return { id: node.id, parent: node.parent || '', input: node.input, time: node.time, materials: materials, result: response, annotations: annotations };
    });
    state.selected = ids.has(data.selected) ? data.selected : ''; state.updatedAt = Number.isFinite(data.updatedAt) ? data.updatedAt : 0; return state;
  }
  function selectedNode(state) { return state.nodes.find(function(node) { return node.id === state.selected; }); }
  function makeRequest(state) {
    var input = editorInput(state.input).trim(); if(!input) throw new Error('请输入这次想生成或探索的内容。');
    var materials = materialList(state.materials).filter(function(item) { return item.text.trim(); });
    if(materials.reduce(function(sum, item) { return sum + item.text.length; }, 0) > 6000) throw new Error('材料正文合计超过 6000 字符。草稿仍可保存，请删减片段后再生成。');
    var node = selectedNode(state), continuity = node ? node.result.memory || (node.result.rawText || node.result.cards.map(function(card) { return card.text; }).join('\n')).slice(-1600) : '';
    var context = node ? '当前分支记录（不代表真实事实）：\n' + continuity + '\n上一节点：' + node.result.title + '\n' + node.result.summary : '';
    if(state.kind === 'phrasing' && state.locked.trim()) context = '用户锁定的原句，改写中请原样保留：' + state.locked.trim() + '\n' + context;
    var request = { kind: state.kind, input: '【' + specs[state.kind].optionLabel + '：' + state.option + '】\n' + input, context: clean(context, 2400), materials: materials.map(function(item) { return { id: item.id, title: item.title.trim() || '未命名材料', date: item.date, text: item.text }; }) };
    if(request.input.length > MAX_REQUEST_INPUT || request.input.length + request.context.length + request.materials.reduce(function(sum, item) { return sum + item.text.length; }, 0) > 8000) throw new Error('本次资料偏长，请缩短材料，或回到开场后重新分析（总量最多约 8000 字符）。');
    return request;
  }
  function key(kind) { if(!Object.hasOwn(specs, kind)) throw new Error('KIND'); return prefix + kind; }
  function createStore(storage, kind) {
    var name = key(kind), baseline = storage.getItem(name);
    return {
      state: restore(baseline, kind),
      save: function(state) {
        if(storage.getItem(name) !== baseline) throw new Error('CONFLICT');
        var raw = JSON.stringify(state); if(raw.length > MAX_BYTES) throw new Error('FULL');
        storage.setItem(name, raw); baseline = raw;
      },
      clear: function() { if(storage.getItem(name) !== baseline) throw new Error('CONFLICT'); storage.removeItem(name); baseline = null; }
    };
  }
  function parseEvents(onEvent, maxBytes) {
    maxBytes = Number.isSafeInteger(maxBytes) && maxBytes >= 65536 && maxBytes <= 25165824 ? maxBytes : 1048576;
    var pending = '', current = '', lines = [];
    function line(value) {
      if(value === '') {
        if(lines.length) { var packet; try { packet = JSON.parse(lines.join('\n')); } catch(_) { throw new Error('PROTOCOL'); } onEvent(current || 'message', packet); }
        current = ''; lines = []; return;
      }
      if(value.startsWith('event:')) current = value.slice(6).trim();
      if(value.startsWith('data:')) lines.push(value.slice(5).replace(/^ /, ''));
    }
    return { push: function(chunk) {
      pending += chunk; if(pending.length > maxBytes) throw new Error('PROTOCOL');
      var index; while((index = pending.indexOf('\n')) >= 0) { var part = pending.slice(0, index); pending = pending.slice(index + 1); line(part.replace(/\r$/, '')); }
    }, finish: function() { if(pending.trim() || lines.length || current) throw new Error('INCOMPLETE'); } };
  }
  var api = { specs: specs, fresh: fresh, restore: restore, makeRequest: makeRequest, editorInput: editorInput, result: result, materialList: materialList, createStore: createStore, parseEvents: parseEvents, safePath: safePath, transportLimits: transportLimits };
  if(typeof module !== 'undefined' && module.exports) { module.exports = api; return; }
  if(!global || !global.document || global.ShokaTextWorkshop) return;
  var cleanup = function() {}, serial = 0;
  function el(tag, cls, value) { var node = document.createElement(tag); if(cls) node.className = cls; if(value !== undefined) node.textContent = value; return node; }
  function markdown(value, cls) {
    var node = el('div', 'tw-card-text ' + (cls || ''), value);
    function show(api) { if(node.isConnected && api && api.render) api.render(node, value); }
    if(global.ShokaAIMarkdown) global.ShokaAIMarkdown.render(node, value);
    else if(global.ShokaFeatures) global.ShokaFeatures.load('ai_markdown').then(show).catch(function() {
      if(node.isConnected) node.title = '排版资源暂未加载，已保留原始文字；复制功能仍可使用。';
    });
    return node;
  }
  function btn(value, cls) { var node = el('button', 'tw-button ' + (cls || ''), value); node.type = 'button'; return node; }
  function field(label, control, hint) {
    var box = el('div', 'tw-field'), name = el('label', 'tw-label', label); control.id = 'tw-control-' + (++serial); name.htmlFor = control.id; box.append(name, control); if(hint) box.append(el('p', 'tw-hint', hint)); return box;
  }
  function input(tag, max, value) { var node = el(tag, tag === 'textarea' ? 'tw-textarea' : 'tw-input'); node.maxLength = max; node.value = value || ''; if(tag === 'textarea') node.rows = 5; return node; }
  function select(options, value, cls) {
    var node = el('select', cls || 'tw-select'); options.forEach(function(item) { var option = el('option', '', item); option.value = item; node.append(option); }); node.value = value; return node;
  }
  function errorText(error) {
    var code = error && (error.code || error.message), messages = {
      PUBLIC_DISABLED: 'AI 服务当前已关闭。你的草稿和已有结果仍在。', AI_NOT_CONFIGURED: 'AI 服务暂未配置，请稍后再试。',
      NOT_FOUND: '后台尚未部署文字工坊接口，草稿已保留。', UNSUPPORTED: '后台尚未启用文字工坊，部署新版本后即可生成。',
      RATE_LIMIT: '请求有些频繁，请稍后再试。', ABUSE_COOLDOWN: '请求暂时进入冷却，请等待后再试。',
      GLOBAL_RATE_LIMIT: '全站 AI 请求暂时较密集，请等待后重试。输入和旧结果已保留，此次未调用模型，也未扣每日额度。',
      IP_DAILY_LIMIT: '当前网络的今日 AI 额度已用完，请明天再来。', PER_IP_LIMIT: '当前网络的今日 AI 额度已用完。', DAILY_LIMIT: '今日 AI 额度已用完，请明天再来。',
      IP_CONCURRENT_LIMIT: '当前网络还有一个 AI 请求正在处理，请等它结束后再生成。', IP_RATE_LIMIT: '当前网络请求有些频繁，请稍后再试。',
      CONCURRENT_LIMIT: 'AI 正在处理其他请求，请稍后再试。', CAPTCHA_REQUIRED: '服务要求人机验证；此工坊尚不支持验证，请稍后再试，不会自动重发请求。',
      WORKSHOP_INPUT_LIMIT: '当前服务器尚不支持这段长输入，或单次输入上限偏小；请更新 AI 后端或调整输入上限。全文及草稿已保留，没有截断，也未调用模型。',
      UPSTREAM_TIMEOUT: '这次等待超时了，旧结果和输入已保留；可以手动再试。', UPSTREAM_UNAVAILABLE: '模型暂时连接不上，请稍后手动重试。',
      UPSTREAM_REJECTED: '模型暂时无法接收请求，请稍后重试。', INVALID_FIELDS: '材料格式或长度不符合服务器要求，请缩短后重试。',
      UPSTREAM_BLOCKED: '模型服务未完成这次回答，输入和旧记录仍在。', UPSTREAM_EMPTY: '模型没有返回文字，输入和旧记录仍在。', OUTPUT_LIMIT: '本次回答超过安全传输大小，输入和旧记录仍在。',
      WORKSHOP_OUTPUT_INVALID: 'AI 回答格式不完整，原输入和已有记录已保留。可以手动重试。', WORKSHOP_INVALID_RESULT: 'AI 返回的格式或引用未通过核对，不是输入内容被拒绝；原输入和已有记录已保留。', WORKSHOP_INCOMPLETE: '回答被截断或未完整结束，已有记录未改动。可要求更短的续写后手动重试。', RESULT: '回答格式不完整，未替换已有内容。',
      WORKSHOP_FORMAT_INVALID: 'AI 未返回完整的卡片格式，原输入和已有记录已保留。请手动重试，不必删除草稿。',
      WORKSHOP_SOURCE_INVALID: 'AI 引用了本次没有提供的材料，未保存这次结果。原输入和已有记录仍在，可手动重试。',
      WORKSHOP_QUOTE_MISMATCH: 'AI 的引文与所选材料原文不一致，未保存为可靠结果。原输入和已有记录已保留。',
      WORKSHOP_DATE_UNSUPPORTED: 'AI 加入了材料中没有的日期，未保存为可靠结果。请补充实际日期或要求不推测日期。',
      EVIDENCE: '回答的引文无法与材料核对，未保存为可靠结果。', PROTOCOL: '回答传输格式异常，未替换已有内容。',
      INCOMPLETE: '回答传输中断，未替换已有内容。', UPSTREAM_TRUNCATED: '回答过长被截断，请缩小要求后重试。',
      ORIGIN_NOT_ALLOWED: '当前站点未获 AI 服务授权。本地测试需由管理员配置允许来源。'
    };
    return messages[code] || '这次生成未完成，输入和旧结果已保留。请检查网络后手动重试。';
  }
  function endpoint() {
    var config = global.BlogAIConfig || {};
    if(config.enabled !== true || typeof config.endpoint !== 'string') return '';
    try {
      var url = new URL(config.endpoint, location.href), local = ['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname);
      if((url.protocol !== 'https:' && !(local && url.protocol === 'http:')) || url.username || url.password || url.search || url.hash) return '';
      return url.href.replace(/\/+$/, '');
    } catch(_) { return ''; }
  }
  async function readLimited(response, limit) {
    var reader = response.body.getReader(), decoder = new TextDecoder(), output = '', count = 0;
    try { while(true) { var chunk = await reader.read(); if(chunk.done) break; count += chunk.value.byteLength; if(count > limit) throw new Error('PROTOCOL'); output += decoder.decode(chunk.value, { stream: true }); } return output + decoder.decode(); }
    finally { await reader.cancel().catch(function() {}); }
  }
  async function copy(value, feedback) {
    try { await navigator.clipboard.writeText(value); feedback('已复制，可粘贴保存。'); }
    catch(_) { feedback('浏览器未允许复制，请选中文字手动复制。', true); }
  }
  function mount(scope) {
    cleanup();
    var root = scope.querySelector('[data-text-workshop]'), kind = root && root.dataset.textWorkshop;
    if(!Object.hasOwn(specs, kind)) return;
    var host = root.querySelector('[data-tw-runtime]'); if(!host) return;
    var spec = specs[kind], life = new AbortController(), dead = false, pending = null, timer = 0, saveTimer = 0, catalogPending = null, store = null, state = fresh(kind), saveFailure = '', catalog = null;
    try { store = createStore(global.localStorage, kind); state = store.state; } catch(error) { saveFailure = error instanceof SyntaxError || ['DRAFT', 'MATERIALS', 'RESULT', 'EVIDENCE'].includes(error.message) ? '现有草稿格式无法读取，未覆盖旧记录。可先复制新内容备份，再清理此功能的浏览器存储。' : '浏览器未允许本地存储，本次内容仅在当前页面保留。'; }
    var grid = el('div', 'tw-grid'), editor = el('section', 'tw-panel tw-editor'), output = el('section', 'tw-panel tw-output');
    editor.setAttribute('aria-label', '输入与材料'); output.setAttribute('aria-label', '生成结果与分支记录');
    var title = el('div', 'tw-panel-head'); title.append(el('h2', '', '从你的文字开始'), el('span', 'tw-badge', '私有草稿'));
    var prompt = input('textarea', MAX_INPUT, state.input); prompt.placeholder = spec.placeholder; prompt.rows = 6; prompt.dataset.twInput = '';
    var counter = el('span', 'tw-hint'), option = select(spec.options, state.option), locked = input('textarea', 240, state.locked); locked.rows = 2;
    var materialBox = el('div', 'tw-materials'), history = el('div', 'tw-history'), results = el('div', 'tw-results'), actions = el('div', 'tw-actions');
    var submit = btn(spec.send, 'is-primary'), stop = btn('停止生成'), sample = btn('填入示例'), restart = btn('回到开场'), clear = btn('清空此工作台', 'is-danger'), backup = btn('下载工作台笔记'), showResult = btn('查看当前结果');
    submit.dataset.twGenerate = ''; stop.dataset.twStop = ''; sample.dataset.twSample = ''; stop.hidden = true;
    var status = el('p', 'tw-status'), draft = el('p', 'tw-draft'), disclosure = el('p', 'tw-hint', '草稿只存此浏览器。点击生成时，当前输入、所选材料及当前分支摘要会发送至 AI 服务与 DeepSeek；不会自动发布，也不会读取其他工作台。请勿填写密码、密钥或未经同意的私人资料。');
    status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite'); draft.setAttribute('role', 'status'); draft.setAttribute('aria-live', 'polite');
    var intro = el('p', 'tw-hint', spec.hint);
    editor.append(title, intro, field(spec.label, prompt), counter, field(spec.optionLabel, option));
    if(kind === 'phrasing') editor.append(field('锁住这句话（可选）', locked, '继续调整表达时保留这句话；新结果仍请自己核对。'));
    if(spec.materials) editor.append(materialBox);
    actions.append(submit, stop, sample, showResult); editor.append(actions, status, draft, disclosure);
    var outputHead = el('div', 'tw-panel-head'); outputHead.append(el('h2', '', '文字在这里展开'), el('span', 'tw-badge', kind === 'story' || kind === 'world' ? '虚构创作' : 'AI 辅助 · 请核对'));
    var toolbar = el('div', 'tw-toolbar'); toolbar.append(restart, backup, clear); output.append(outputHead, toolbar, history, results); grid.append(editor, output); host.replaceChildren(grid);
    function on(node, name, fn) { node.addEventListener(name, fn, { signal: life.signal }); }
    function feedback(message, error) { if(dead) return; status.textContent = message; status.classList.toggle('is-error', !!error); }
    function syncCount() { counter.textContent = prompt.value.length + ' / ' + MAX_INPUT + ' 字符 · ' + state.nodes.length + ' / ' + MAX_NODES + ' 个记录节点'; }
    function save() {
      clearTimeout(saveTimer); if(dead || !store) { draft.textContent = saveFailure || '当前页面临时保存，建议复制备份。'; return; }
      state.updatedAt = Date.now();
      try { store.save(state); draft.textContent = '已保存在此浏览器 · ' + new Date(state.updatedAt).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }); }
      catch(error) { saveFailure = error.message === 'CONFLICT' ? '另一标签页已修改此工作台，当前内容未覆盖它。请复制当前内容备份，再刷新。' : '本地保存失败，内容仍在当前页面。请复制备份，避免刷新丢失。'; draft.textContent = saveFailure; store = null; }
    }
    function scheduleSave() { clearTimeout(saveTimer); saveTimer = setTimeout(save, 350); }
    function setInput(value, focus) {
      try { state.input = editorInput(value); } catch(error) { feedback(error.message, true); return false; }
      prompt.value = state.input; syncCount(); scheduleSave(); if(focus) prompt.focus({ preventScroll: true }); return true;
    }
    function busy(value) {
      root.setAttribute('aria-busy', String(value));
      host.querySelectorAll('button,input,textarea,select').forEach(function(node) { if(node !== stop) node.disabled = value; });
      stop.hidden = !value; stop.disabled = false; submit.textContent = value ? '正在编织，请稍候…' : spec.send;
      if(!value && state.nodes.length >= MAX_NODES) submit.disabled = true;
    }
    function sourceDetail(parent, sources, ids, quotes) {
      ids = Array.from(new Set(ids.concat(quotes.map(function(item) { return item.sourceId; }))));
      ids.forEach(function(id) {
        var source = sources.find(function(item) { return item.id === id; });
        var details = el('details', 'tw-source'), heading = el('summary', '', source ? source.title + ' · ' + (source.date || '日期未提供') : 'AI 标注的来源：' + id);
        details.append(heading);
        details.append(el('small', 'tw-hint', '引用由 AI 标注，本站未核实内容。'));
        quotes.filter(function(item) { return item.sourceId === id; }).forEach(function(item) { details.append(el('blockquote', 'tw-source-quote', item.quote)); });
        if(source) details.append(el('p', 'tw-preview', source.text));
        if(source && safePath(source.path)) { var link = el('a', 'tw-button', '打开博客原文 ↗'); link.href = source.path; link.target = '_blank'; link.rel = 'noopener'; details.append(link); }
        parent.append(details);
      });
    }
    function resultText(node) {
      if(typeof node.result.rawText === 'string') return node.result.rawText;
      return node.result.title + '\n\n' + node.result.summary + '\n\n' + node.result.cards.map(function(card, index) {
        return (node.annotations[index] || card.tag) + ' · ' + card.title + '\n' + card.text + (card.quotes.length ? '\nAI 标注的引用（未核实）：' + card.quotes.map(function(q) { var source = node.materials.find(function(s) { return s.id === q.sourceId; }); return (source ? source.title : q.sourceId) + '「' + q.quote + '」'; }).join('\n') : '');
      }).join('\n\n');
    }
    function renderHistory() {
      history.replaceChildren(); history.hidden = !state.nodes.length;
      if(!state.nodes.length) return;
      var head = el('details', 'tw-details'); head.open = true; head.append(el('summary', '', '记录与分支 · ' + state.nodes.length));
      var tree = el('div', 'tw-timeline');
      state.nodes.forEach(function(node, index) {
        var parentIndex = state.nodes.findIndex(function(n) { return n.id === node.parent; });
        var row = btn(String(index + 1).padStart(2, '0') + '  ' + node.result.title, 'tw-node' + (state.selected === node.id ? ' is-active' : ''));
        row.setAttribute('aria-pressed', String(state.selected === node.id)); row.title = '从' + (parentIndex < 0 ? '开场' : '记录 ' + (parentIndex + 1)) + '分岔 · ' + node.input;
        row.append(el('small', 'tw-branch', parentIndex < 0 ? '起点' : '来自 ' + (parentIndex + 1)));
        on(row, 'click', function() { state.selected = node.id; renderResults(); renderHistory(); save(); feedback('已回到记录 ' + (index + 1) + '。输入新想法后生成，会保留原记录并建立新分支。'); }); tree.append(row);
      }); head.append(tree); history.append(head);
    }
    function renderResults() {
      results.replaceChildren(); var node = selectedNode(state);
      if(!node) {
        var empty = el('div', 'tw-empty'); empty.append(el('span', 'tw-empty-mark', '✦'), el('h3', '', '留一点空白，等一个想法'), el('p', '', state.nodes.length ? '已回到开场。下一次生成会成为一个独立分支，原记录都在上方。' : '先写下想法，或填入一个示例。只有点击生成才会调用 AI。'));
        results.append(empty); return;
      }
      var card = el('article', 'tw-result'), heading = el('div', 'tw-result-header'), copyAll = btn('复制这份结果');
      heading.append(el('h3', '', node.result.title), copyAll); on(copyAll, 'click', function() { void copy(resultText(node), feedback); });
      card.append(heading, markdown(node.result.summary));
      if(node.result.truncated) card.append(el('p', 'tw-result-notice', '回答达到本次长度上限，已保留返回的内容。你可以输入“继续”接着生成，不会自动追加请求。'));
      if(typeof node.result.rawText === 'string') card.append(markdown(node.result.rawText, 'tw-plain-answer'));
      var cards = el('div', 'tw-cards');
      node.result.cards.forEach(function(item, index) {
        var box = el('section', 'tw-card'), badge = el('span', 'tw-card-tag', node.annotations[index] || item.tag || '文字片段');
        box.append(badge, el('h4', 'tw-card-title', item.title), markdown(item.text));
        if(node.annotations[index]) box.append(el('small', 'tw-hint', '此分类由你手动调整，未重新调用 AI。'));
        if(kind === 'archaeology' && item.sourceIds.length) {
          var dates = item.sourceIds.map(function(id) { var source = node.materials.find(function(s) { return s.id === id; }); return source && source.date ? source.date : '日期未知'; });
          box.append(el('p', 'tw-hint', '材料日期：' + Array.from(new Set(dates)).join(' / ')));
        }
        sourceDetail(box, node.materials, item.sourceIds, item.quotes);
        var controls = el('div', 'tw-card-actions'), copyOne = btn('复制片段'); on(copyOne, 'click', function() { void copy(item.text, feedback); }); controls.append(copyOne);
        if(kind === 'phrasing') {
          var use = btn('选用这个版本'); on(use, 'click', function() { if(setInput('请继续调整这个表达版本：\n' + item.text + '\n希望调整的地方：', true)) feedback('已放入编辑区，补充希望调整的地方后再生成。'); }); controls.append(use);
          var lock = btn('锁住一句话'); on(lock, 'click', function() { var selection = String(global.getSelection() || '').trim(); state.locked = clean(selection && item.text.includes(selection) ? selection : item.text.split(/[。！？\n]/)[0], 240); locked.value = state.locked; save(); feedback('已填入锁定句，可以在左侧继续编辑。'); }); controls.append(lock);
          var simulate = btn('试试对方可能怎么接'); on(simulate, 'click', function() { setInput('请把以下表达当作假设，模拟对方可能的一种回应，并给出温和的后续表达。明确这是可能情境而非预测：\n' + item.text, true); }); controls.append(simulate);
        } else if(kind === 'roundtable') {
          var challenge = btn('回应这个角度'); on(challenge, 'click', function() { setInput('针对「' + item.title + '」这个角度：' + item.text + '\n我想补充或反驳的是：', true); }); controls.append(challenge);
        } else if(kind === 'world') {
          var inspect = btn('沿这份档案继续'); on(inspect, 'click', function() { setInput('沿虚构档案「' + item.title + '」继续：' + item.text + '\n请展开其中一条线索，补充相互关联的新档案。', true); }); controls.append(inspect);
        } else if(kind === 'clues') {
          var category = select(['原文记载', '个人判断', '存在矛盾', '尚待确认'], node.annotations[index] || (['原文记载', '个人判断', '存在矛盾', '尚待确认'].includes(item.tag) ? item.tag : '尚待确认'));
          category.setAttribute('aria-label', '纠正「' + item.title + '」的分类'); on(category, 'change', function() { node.annotations[index] = category.value; save(); renderResults(); feedback('分类已按你的判断调整。原引文仍保留。'); }); controls.append(category);
        }
        box.append(controls); cards.append(box);
      }); card.append(cards);
      if(node.result.actions.length) {
        var choices = el('div', 'tw-choices'); choices.append(el('p', 'tw-hint', '选择下一步会填入编辑区；检查后点击生成，才会调用 AI。'));
        node.result.actions.forEach(function(action) { var choice = btn(action.label, 'tw-choice'); on(choice, 'click', function() { if(setInput(action.instruction, true)) feedback('下一步已填入，点击生成继续。'); }); choices.append(choice); }); card.append(choices);
      }
      results.append(card);
    }
    function addMaterial(item) {
      if(state.materials.length >= 6) { feedback('最多添加六份材料，请先移除一份。', true); return; }
      if(item && item.catalogId && state.materials.some(function(m) { return m.catalogId === item.catalogId; })) { feedback('这篇文章已在材料中。'); return; }
      var id = [1, 2, 3, 4, 5, 6].map(function(n) { return 'm' + n; }).find(function(value) { return !state.materials.some(function(m) { return m.id === value; }); });
      state.materials.push({ id: id, title: clean(item && item.title || '材料 ' + id.slice(1), 120), date: item && date(item.date) ? item.date : '', text: clean(item && item.text || '', 2000), path: safePath(item && item.path), catalogId: clean(item && item.catalogId, 100) });
      renderMaterials(); scheduleSave();
    }
    function renderMaterials() {
      materialBox.replaceChildren(); var header = el('div', 'tw-panel-head'); header.append(el('h3', '', kind === 'archaeology' ? '选择对照材料' : '你提供的材料'), el('span', 'tw-badge', state.materials.length + ' / 6'));
      var add = btn('＋ 添加文字材料'), list = el('div', 'tw-sources'); on(add, 'click', function() { addMaterial(); }); header.append(add); materialBox.append(header);
      if(kind === 'archaeology') { var open = btn('从博客文章中选择'); open.dataset.twCatalogOpen = ''; on(open, 'click', function() { void openCatalog(); }); materialBox.append(open); }
      state.materials.forEach(function(item) {
        var box = el('details', 'tw-material'); box.open = !item.text || state.materials.length < 3; box.dataset.twMaterial = item.id;
        var summary = el('summary', '', item.title + (item.date ? ' · ' + item.date : ''));
        var name = input('input', 120, item.title), when = input('input', 10, item.date), prose = input('textarea', 2000, item.text); when.type = 'date'; prose.rows = 6;
        var remove = btn('移除此材料');
        on(name, 'input', function() { item.title = name.value; summary.textContent = item.title || '未命名材料'; scheduleSave(); });
        on(when, 'change', function() { item.date = when.value; scheduleSave(); }); on(prose, 'input', function() { item.text = prose.value; scheduleSave(); });
        on(remove, 'click', function() { if(item.text.trim() && !global.confirm('移除这份输入材料？已有结果里的引文副本会保留。')) return; state.materials = state.materials.filter(function(m) { return m !== item; }); renderMaterials(); save(); });
        box.append(summary, field('材料标题', name), field('原文日期（不知道可留空）', when), field('原文片段', prose, '最多 2000 字符；六份材料正文合计最多 6000 字符。'), remove); list.append(box);
      }); materialBox.append(list);
    }
    var catalogBox = el('section', 'tw-catalog'); catalogBox.hidden = true; editor.insertBefore(catalogBox, actions);
    async function openCatalog() {
      if(pending || dead) return; catalogBox.hidden = false; catalogBox.replaceChildren(el('p', 'tw-hint', '正在读取公开文章目录…'));
      if(!catalog) {
        if(catalogPending) return;
        catalogPending = new AbortController(); var controller = catalogPending, timeout = setTimeout(function() { controller.abort(); }, 18000);
        try {
          var original = root.dataset.twCatalog || '/text-workshop-catalog.json', fallback = root.dataset.twCatalogFallback || '/text-workshop-catalog.json';
          var urls = Array.from(new Set([original, fallback].map(function(url) { return global.ShokaFeatures && global.ShokaFeatures.asset ? global.ShokaFeatures.asset(url) : url; })));
          var response, parsed;
          for(var u = 0; u < urls.length; u++) {
            try { response = await fetch(urls[u], { credentials: 'omit', signal: controller.signal, cache: 'force-cache' }); if(!response.ok) throw new Error(); parsed = JSON.parse(await readLimited(response, 8388608)); break; }
            catch(error) { if(controller.signal.aborted || u === urls.length - 1) throw error; }
          }
          if(!plain(parsed) || parsed.version !== 1 || !Array.isArray(parsed.items) || parsed.items.length > 5000) throw new Error();
          catalog = parsed.items.filter(function(item) { return plain(item) && text(item.id, 100) && text(item.title, 200) && safePath(item.path) && date(item.date) && text(item.excerpt, 1600); });
        } catch(error) { if(!dead) { catalogBox.replaceChildren(el('p', 'tw-message is-error', '公开文章目录暂未加载成功。可再次点击重试，或直接粘贴自己的材料。')); } return; }
        finally { clearTimeout(timeout); if(catalogPending === controller) catalogPending = null; }
      }
      if(dead) return;
      catalogBox.replaceChildren(); var query = input('input', 120), close = btn('收起目录'), list = el('div', 'tw-catalog-list'); query.placeholder = '按标题或内容搜索公开文章';
      catalogBox.append(field('查找公开文章', query), close, el('p', 'tw-hint', '只收录已公开文章的脱敏文字摘录，不是全文。选择后可先检查、删减材料，再发送给 AI。'), list);
      function filter() {
        list.replaceChildren(); var term = query.value.trim().toLowerCase();
        var matches = catalog.filter(function(item) { return !term || (item.title + item.excerpt).toLowerCase().includes(term); });
        list.append(el('p', 'tw-hint', '找到 ' + matches.length + ' 篇' + (matches.length > 20 ? '，先显示前 20 篇，请缩小关键词' : '')));
        matches.slice(0, 20).forEach(function(item) {
          var node = btn(item.title + ' · ' + (item.date || '日期未知'), 'tw-catalog-item'); on(node, 'click', function() { addMaterial({ title: item.title, date: item.date, text: item.excerpt, path: item.path, catalogId: item.id }); feedback('已添加「' + item.title + '」的公开摘录；尚未发送给 AI。'); }); list.append(node);
        });
      }
      on(query, 'input', filter); on(close, 'click', function() { catalogBox.hidden = true; }); filter();
    }
    async function generate() {
      if(pending || dead) return;
      if(state.nodes.length >= MAX_NODES) { feedback('此工作台已保留 24 个记录。请复制需要的内容，再清空开始新一组；不会自动删除旧分支。', true); return; }
      var payload; try { payload = makeRequest(state); } catch(error) { feedback(error.message, true); return; }
      var base = endpoint(); if(!base) { feedback('AI 入口当前未启用。你仍可编辑和保存草稿。', true); return; }
      // Freeze sources and parent BEFORE any asynchronous work; edits cannot retarget citations.
      var snapshot = materialList(state.materials).filter(function(item) { return item.text.trim(); }), parent = state.selected, controller = new AbortController(); pending = controller;
      var limitExpired = false, limits = transportLimits(), startedAt = Date.now();
      function scheduleTimeout() { clearTimeout(timer); timer = setTimeout(function() { limitExpired = true; controller.abort(); }, Math.max(0, startedAt + limits.timeoutMs - Date.now())); }
      scheduleTimeout();
      save(); busy(true); feedback('正在检查服务并生成，本次只发送当前工作台的必要内容…');
      try {
        var check = await fetch(base + '/api/public/status', { signal: controller.signal, credentials: 'omit', cache: 'no-store' });
        if(!check.ok) throw new Error('UNSUPPORTED');
        var availability = JSON.parse(await readLimited(check, 32768));
        if(availability.enabled !== true || availability.available !== true) throw new Error('PUBLIC_DISABLED');
        if(!availability.features || availability.features.workshop !== true) throw new Error('UNSUPPORTED');
        limits = transportLimits(availability.transport); scheduleTimeout();
        var inputLimit = availability.transport && availability.transport.workshopInputChars;
        if(!Number.isSafeInteger(inputLimit) || inputLimit < 1 || inputLimit > MAX_REQUEST_INPUT) inputLimit = 1000;
        if(payload.input.length > inputLimit) throw new Error('WORKSHOP_INPUT_LIMIT');
        if(controller.signal.aborted) throw new Error('INCOMPLETE');
        var response = await fetch(base + '/api/public/workshop', { method: 'POST', credentials: 'omit', signal: controller.signal,
          headers: { 'Content-Type': 'application/json', Accept: 'text/event-stream' }, body: JSON.stringify(payload) });
        if(!response.ok) { var failure; try { failure = JSON.parse(await readLimited(response, 32768)); } catch(_) {} var fail = new Error(failure && failure.error && failure.error.code || 'PROTOCOL'); fail.retryAfter = response.headers.get('Retry-After'); throw fail; }
        if(!/text\/event-stream/i.test(response.headers.get('content-type') || '')) throw new Error('PROTOCOL');
        var done = false, generated = null, received = 0, meta = false;
        var stream = parseEvents(function(name, packet) {
          if(done || !plain(packet) || !['meta', 'error', 'result', 'done'].includes(name)) throw new Error('PROTOCOL');
          if(name === 'error') throw new Error(packet.code || 'PROTOCOL');
          if(name === 'meta') { if(meta || packet.kind !== kind || packet.mode !== 'workshop') throw new Error('PROTOCOL'); meta = true; }
          if(name === 'result') { if(generated || !meta) throw new Error('PROTOCOL'); generated = result(packet, snapshot, limits.maxAnswerChars); }
          if(name === 'done') { if(packet.ok !== true || !generated) throw new Error('INCOMPLETE'); if(packet.truncated === true) generated.truncated = true; done = true; }
        }, limits.maxResponseBytes);
        var reader = response.body.getReader(), decoder = new TextDecoder();
        try { while(true) { var chunk = await reader.read(); if(chunk.done) break; received += chunk.value.byteLength; if(received > limits.maxResponseBytes) throw new Error('OUTPUT_LIMIT'); stream.push(decoder.decode(chunk.value, { stream: true })); } stream.push(decoder.decode()); stream.finish(); }
        finally { await reader.cancel().catch(function() {}); }
        if(!done || !generated) throw new Error('INCOMPLETE'); if(dead || controller.signal.aborted) return;
        var node = { id: 'n' + Date.now().toString(36) + '_' + (++serial).toString(36), parent: parent, input: state.input, time: Date.now(), materials: snapshot, result: generated, annotations: {} };
        state.nodes.push(node); state.selected = node.id; renderHistory(); renderResults(); save(); syncCount(); feedback(generated.truncated ? '已保留本次返回内容；回答达到长度上限，可输入“继续”后手动生成。' : '已生成并保留这份记录。可以选择下一步，或回到任意旧分支。');
      } catch(error) {
        if(!dead) feedback(controller.signal.aborted ? (limitExpired ? '等待超时，旧结果和输入仍保留。请稍后手动重试。' : '已停止生成，未覆盖已有结果。已开始的模型请求可能仍计入额度。') : errorText(error) + (error.retryAfter && /^\d+$/.test(error.retryAfter) ? ' 请至少等待 ' + error.retryAfter + ' 秒。' : ''), true);
      } finally { clearTimeout(timer); if(pending === controller) pending = null; if(!dead) busy(false); }
    }
    on(prompt, 'input', function() { state.input = prompt.value; syncCount(); scheduleSave(); });
    on(option, 'change', function() { state.option = option.value; scheduleSave(); }); on(locked, 'input', function() { state.locked = locked.value; scheduleSave(); });
    on(submit, 'click', function() { void generate(); }); on(stop, 'click', function() { if(pending) pending.abort(); });
    on(showResult, 'click', function() { output.scrollIntoView({ block: 'start', behavior: document.documentElement.dataset.motion === 'reduce' || global.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' }); });
    on(backup, 'click', function() {
      var content = spec.name + '\n本地工作台笔记 · ' + new Date().toLocaleString('zh-CN') + '\n\n当前输入：\n' + state.input + '\n\n当前材料：\n' + state.materials.map(function(item) { return item.title + ' · ' + (item.date || '日期未知') + '\n' + item.text; }).join('\n\n')
        + '\n\n全部记录：\n' + state.nodes.map(function(node, index) { var parent = state.nodes.findIndex(function(item) { return item.id === node.parent; }); return '【记录 ' + (index + 1) + ' · 来自 ' + (parent < 0 ? '开场' : '记录 ' + (parent + 1)) + '】\n输入：' + node.input + '\n\n' + resultText(node); }).join('\n\n----------------\n\n');
      var url = URL.createObjectURL(new Blob([content], { type: 'text/plain;charset=utf-8' })), link = el('a'); link.href = url; link.download = '文字工坊-' + spec.name + '-' + new Date().toISOString().slice(0, 10) + '.txt'; link.hidden = true; root.append(link); link.click(); link.remove(); setTimeout(function() { URL.revokeObjectURL(url); }, 1000); feedback('已交给浏览器下载。本地备份包含你输入的材料，请妥善保管。');
    });
    on(prompt, 'keydown', function(event) { if((event.ctrlKey || event.metaKey) && event.key === 'Enter') { event.preventDefault(); void generate(); } });
    on(sample, 'click', function() {
      if(state.input.trim() && state.input !== spec.sample && !global.confirm('用示例替换当前输入？材料和已有结果不会删除。')) return;
      setInput(spec.sample); if(spec.samples && !state.materials.length) spec.samples.forEach(addMaterial); save(); feedback('示例已填入，尚未调用 AI。可以先修改再生成。');
    });
    on(restart, 'click', function() { state.selected = ''; renderHistory(); renderResults(); save(); feedback('下一次生成会从新起点开始，旧记录仍可回看。'); });
    on(clear, 'click', function() {
      if(!global.confirm('清空此工作台的输入、材料和所有记录？此操作无法撤销，不影响其他六个工作台。请先复制需要的内容。')) return;
      if(store) { try { store.clear(); } catch(_) { feedback('另一标签页修改了草稿，未执行清空。请先备份再刷新。', true); return; } }
      state = fresh(kind); prompt.value = ''; locked.value = ''; option.value = state.option; renderMaterials(); renderHistory(); renderResults(); syncCount(); save(); busy(false); feedback('已清空此工作台，其他工作台未改变。');
    });
    on(global, 'pagehide', save);
    on(global, 'storage', function(event) { if(event.key === key(kind)) { store = null; saveFailure = '另一标签页修改了此工作台。当前内容未覆盖它，请复制备份后刷新。'; draft.textContent = saveFailure; } });
    renderMaterials(); renderHistory(); renderResults(); syncCount();
    draft.textContent = saveFailure || (state.updatedAt ? '已恢复此浏览器保存的草稿与记录。' : '自动保存至当前浏览器；无痕模式或清理数据后可能丢失。');
    busy(false);
    cleanup = function() {
      if(dead) return; save(); dead = true; life.abort(); clearTimeout(timer); clearTimeout(saveTimer); if(pending) pending.abort(); if(catalogPending) catalogPending.abort();
    };
  }
  global.ShokaTextWorkshop = { mount: mount, destroy: function() { cleanup(); cleanup = function() {}; } };
}(typeof window === 'undefined' ? null : window));
