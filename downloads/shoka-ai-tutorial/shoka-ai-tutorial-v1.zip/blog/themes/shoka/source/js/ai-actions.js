(function() {
  'use strict';
  // Model output is a proposal, never a script. Only these bounded actions can
  // become user-clicked controls; ordinary answers and incomplete streams cannot.
  var enums = {
    music: ['play', 'pause', 'stop', 'next', 'previous', 'mute', 'unmute'],
    playback: ['order', 'random', 'loop'], theme: ['light', 'dark'],
    scroll: ['top', 'bottom', 'comments'], feed: ['rss', 'atom', 'json'],
    panel: ['display', 'reading'], query: ['views', 'comments', 'articles', 'visits', 'friends', 'player'],
    display: { motion: ['reduce', 'system'], background: ['plain', 'banner'], layout: ['grid', 'list'],
      texture: ['none', 'starlight', 'cyber-dots', 'topography', 'geometric', 'sakura'] },
    reading: { font: [16, 24], line: [1.6, 2.5], gap: [.6, 2.2], width: [34, 60] }
  };
  var labels = { play: '播放音乐', pause: '暂停音乐', stop: '停止音乐', next: '下一首', previous: '上一首', mute: '静音', unmute: '取消静音',
    order: '列表播放', random: '随机播放', loop: '单曲循环', light: '白天模式', dark: '夜间模式',
    top: '回到页面顶部', bottom: '到页面底部', comments: '跳到评论区', rss: 'RSS 订阅', atom: 'Atom 订阅', json: 'JSON Feed 订阅',
    views: '浏览量', articles: '文章统计', visits: '访问统计', friends: '友链名单', player: '当前音乐',
    motion: '动效', background: '页面背景', layout: '首页排列', texture: '背景纹理', textureOpacity: '纹理浓度',
    reduce: '减弱动效', system: '跟随系统', plain: '简洁主题色', banner: '顶部图片', grid: '双列', list: '单列',
    none: '无纹理', starlight: '星光', 'cyber-dots': '点阵', topography: '等高线', geometric: '几何', sakura: '樱花',
    font: '字号', line: '行高', gap: '段落间距', width: '正文宽度', focus: '专注阅读', spotlight: '段落聚焦', practice: '步骤跟读', tracking: '阅读记录' };
  var own = function(value, keys) {
    return value && typeof value === 'object' && !Array.isArray(value)
      && [Object.prototype, null].includes(Object.getPrototypeOf(value)) && Object.keys(value).every(function(key) { return keys.includes(key); });
  };
  var safeText = function(value, max) { return typeof value === 'string' && value.trim() && value.length <= max && !/[\u0000-\u001f\u007f]/.test(value); };
  var targetText = function(value) { return safeText(value, 200) && !/^(?:[a-z]+:|\/\/)/i.test(value.trim()) && !value.includes('\\'); };
  function validateAction(raw) {
    if(!own(raw, ['type', 'key', 'value', 'target', 'scope']) || typeof raw.type !== 'string') return null;
    var type = raw.type, allowed = ['type'], valid = false;
    if(['navigate', 'search', 'track'].includes(type)) { allowed.push('target'); valid = targetText(raw.target); }
    else if(type === 'volume' || type === 'volume.adjust') {
      allowed.push('value'); valid = Number.isInteger(raw.value) && (type === 'volume' ? raw.value >= 0 && raw.value <= 100 : raw.value !== 0 && Math.abs(raw.value) <= 100);
    }
    else if(type === 'display') {
      allowed.push('key', 'value');
      valid = raw.key === 'textureOpacity' ? Number.isInteger(raw.value) && raw.value >= 5 && raw.value <= 25
        : typeof raw.key === 'string' && Object.hasOwn(enums.display, raw.key) && enums.display[raw.key].includes(raw.value);
    } else if(type === 'palette') {
      allowed.push('key', 'value'); valid = ['primary', 'secondary'].includes(raw.key) && typeof raw.value === 'string' && /^#[0-9a-f]{6}$/i.test(raw.value);
    } else if(type === 'reading') {
      allowed.push('key', 'value');
      valid = Object.hasOwn(enums.reading, raw.key) ? typeof raw.value === 'number' && Number.isFinite(raw.value)
        && raw.value >= enums.reading[raw.key][0] && raw.value <= enums.reading[raw.key][1]
        : ['focus', 'spotlight', 'practice', 'tracking'].includes(raw.key) && typeof raw.value === 'boolean';
      if(Object.hasOwn(enums.reading, raw.key)) valid = valid && (raw.key === 'font' || raw.key === 'width'
        ? Number.isInteger(raw.value) : Math.abs(raw.value * 10 - Math.round(raw.value * 10)) < 1e-8);
      if(raw.scope !== undefined && Object.hasOwn(enums.reading, raw.key)) { allowed.push('scope'); valid = valid && ['article', 'defaults'].includes(raw.scope); }
    } else if(['display.reset', 'reading.reset', 'reading.defaults.reset', 'palette.reset'].includes(type)) valid = true;
    else if(Object.hasOwn(enums, type) && Array.isArray(enums[type])) {
      allowed.push('value'); valid = enums[type].includes(raw.value);
      if(type === 'query' && ['views', 'comments'].includes(raw.value) && raw.target !== undefined) { allowed.push('target'); valid = valid && targetText(raw.target); }
    }
    if(!valid || !own(raw, allowed)) return null;
    var result = {};
    allowed.forEach(function(key) { if(raw[key] !== undefined) result[key] = raw[key]; });
    return result;
  }
  function parse(answer) {
    if(typeof answer !== 'string' || answer.length > 10000) return null;
    var value;
    try { value = JSON.parse(answer.trim().replace(/^```(?:json)?\s*\n([\s\S]*?)\n```$/i, '$1')); } catch(error) { return null; }
    if(!own(value, ['summary', 'actions']) || !safeText(value.summary, 240) || !Array.isArray(value.actions) || value.actions.length > 4) return null;
    var actions = value.actions.map(validateAction);
    if(actions.some(function(action) { return !action; })) return null;
    return { summary: value.summary.trim(), actions: actions };
  }
  function localPlan(input) {
    if(!safeText(input, 1000)) return null;
    // Conservative full-string grammar: never interpret quoted prose, questions
    // about code or an AI answer as a command. No fuzzy script/URL execution.
    var text = input.trim().replace(/^(?:(?:请|麻烦)(?:帮我|给我)?|帮我|给我)/, '').replace(/(?:一下|吧)?[。！!]*$/, '').trim();
    var unquoted = text.replace(/[《「][^》」]*[》」]/g, '');
    if(/(?:然后|同时|并且|[，,;；]|并(?:把|将|开启|关闭|暂停|播放|切换|回到)|再(?:把|将|让|开启|关闭|播放|暂停|切换|回到))/.test(unquoted)) return null;
    var a, match;
    var music = { '播放音乐': 'play', '继续播放': 'play', '暂停音乐': 'pause', '停止音乐': 'stop', '上一首': 'previous', '下一首': 'next', '静音': 'mute', '取消静音': 'unmute' };
    if(Object.hasOwn(music, text)) a = { type: 'music', value: music[text] };
    else if(/^(?:切换到?|开启|设为|设置为)?(?:白天|浅色|日间)模式$/.test(text)) a = { type: 'theme', value: 'light' };
    else if(/^(?:切换到?|开启|设为|设置为)?(?:夜间|深色|黑夜)模式$/.test(text)) a = { type: 'theme', value: 'dark' };
    else if(/^(?:返回|回到|滚动到|到)(?:页面)?(?:最)?顶部$/.test(text)) a = { type: 'scroll', value: 'top' };
    else if(/^(?:滚动到|到|前往)(?:页面)?(?:最)?底部$/.test(text)) a = { type: 'scroll', value: 'bottom' };
    else if(/^(?:跳到|打开|前往)评论区$/.test(text)) a = { type: 'scroll', value: 'comments' };
    else if((match = /^(?:把)?音量(?:调到|调为|设为|设置为|改为|调成|\s*)\s*(\d{1,3})\s*(?:%|％)?$/.exec(text))) a = { type: 'volume', value: Number(match[1]) };
    else if((match = /^(?:打开|查看)?(RSS|ATOM|JSON(?:\s*FEED)?)(?:订阅)?$/i.exec(text))) a = { type: 'feed', value: /^rss$/i.test(match[1]) ? 'rss' : /^atom$/i.test(match[1]) ? 'atom' : 'json' };
    else if((match = /^(?:打开|前往|进入)(?:文章|页面)?\s*[《「]?(.+?)[》」]?$/.exec(text))) a = match[1] === '显示与阅读设置' ? { type: 'panel', value: 'display' }
      : match[1] === '本文阅读设置' ? { type: 'panel', value: 'reading' } : { type: 'navigate', target: match[1] };
    else if((match = /^(?:站内搜索|搜索|查找)\s*[:：]?\s*[《「]?(.+?)[》」]?$/.exec(text))) a = { type: 'search', target: match[1] };
    else if((match = /^(?:播放歌曲|播放指定音乐|播放)\s*[《「]?(.+?)[》」]?$/.exec(text))) a = { type: 'track', target: match[1] };
    else if((match = /^(列表播放|随机播放|单曲循环)$/.exec(text))) a = { type: 'playback', value: { '列表播放': 'order', '随机播放': 'random', '单曲循环': 'loop' }[match[1]] };
    else if(/^(?:减弱|减少|关闭)动效$/.test(text)) a = { type: 'display', key: 'motion', value: 'reduce' };
    else if(/^恢复(?:系统)?动效$/.test(text)) a = { type: 'display', key: 'motion', value: 'system' };
    else if((match = /^(?:把)?(?:首页|文章)?(?:排列|布局)(?:改为|设为|调成|切换为)?(单列|双列)$/.exec(text))) a = { type: 'display', key: 'layout', value: match[1] === '单列' ? 'list' : 'grid' };
    else if((match = /^(?:把)?(?:页面)?背景(?:改为|设为|调成)?(简洁主题色|顶部图片)$/.exec(text))) a = { type: 'display', key: 'background', value: match[1] === '简洁主题色' ? 'plain' : 'banner' };
    else if((match = /^(?:把)?(?:背景)?纹理(?:改为|设为|调成)?(无纹理|星光|点阵|等高线|几何|樱花)$/.exec(text))) a = { type: 'display', key: 'texture', value: { '无纹理': 'none', '星光': 'starlight', '点阵': 'cyber-dots', '等高线': 'topography', '几何': 'geometric', '樱花': 'sakura' }[match[1]] };
    else if((match = /^(?:把)?(?:文章|正文)?(字号|行高|段落间距|正文宽度)(?:改为|设为|调到|调成)\s*(\d+(?:\.\d+)?)(?:px|rem)?$/.exec(text))) a = { type: 'reading', key: { '字号': 'font', '行高': 'line', '段落间距': 'gap', '正文宽度': 'width' }[match[1]], value: Number(match[2]) };
    else if((match = /^(开启|关闭)(专注阅读|段落聚焦|步骤跟读|阅读记录)$/.exec(text))) a = { type: 'reading', key: { '专注阅读': 'focus', '段落聚焦': 'spotlight', '步骤跟读': 'practice', '阅读记录': 'tracking' }[match[2]], value: match[1] === '开启' };
    else if((match = /^(?:把)?(主色|辅色)(?:改为|设为|调成)\s*(#[0-9a-f]{6})$/i.exec(text))) a = { type: 'palette', key: match[1] === '主色' ? 'primary' : 'secondary', value: match[2] };
    else if(/^恢复(?:默认显示|主题默认|显示默认)(?:设置)?$/.test(text)) a = { type: 'display.reset' };
    else if(/^恢复(?:原文样式|原文排版)$/.test(text)) a = { type: 'reading.reset' };
    else if(/^重置文章默认排版$/.test(text)) a = { type: 'reading.defaults.reset' };
    else if(/^恢复默认配色$/.test(text)) a = { type: 'palette.reset' };
    else if(/^(?:查看|统计)?(?:本站|博客)?文章统计(?:数据)?$/.test(text)) a = { type: 'query', value: 'articles' };
    else if(/^(?:查看|统计)?(?:本站|博客)?访问统计(?:数据)?$/.test(text)) a = { type: 'query', value: 'visits' };
    else if(/^(?:查看)?(?:本站|博客)?友链(?:数量|名单|有哪些|有谁)?[？?]?$/.test(text)) a = { type: 'query', value: 'friends' };
    else if(/^(?:查看)?(?:现在|当前)(?:播放的)?音乐(?:信息|是什么)?[？?]?$/.test(text)) a = { type: 'query', value: 'player' };
    else if((match = /^(?:查看|查询)?(.+?)(?:的)?(?:浏览量|访问量)(?:是多少|多少)?[？?]?$/.exec(text))) a = { type: 'query', value: 'views', target: match[1].replace(/的$/, '') };
    else if((match = /^(?:查看|查询)?(.+?)(?:的)?(?:评论数|评论者|评论情况)(?:是多少|有哪些|多少)?[？?]?$/.exec(text))) a = { type: 'query', value: 'comments', target: match[1].replace(/的$/, '') };
    // Common conversational variants remain local. Unclear/negated/compound
    // language is left to the model, never guessed or silently executed.
    if(!a && !/(?:不要|不用|别|不想|如果|如何|为什么|怎么|示例|代码|[“”`])/.test(text)) {
      var natural = text.replace(/^(?:能不能|可以|能否)(?:帮我|给我)?/, '').replace(/^(?:先|现在)/, '').replace(/(?:一下|听听|好吗|可以吗|行吗|谢谢|吧|了)+[？?]*$/, '').trim();
      if(/^(?:把|让)?(?:音乐|歌曲|背景音乐)(?:先)?(?:暂停|停|停一停|停一下|歇会儿|休息一会儿)$/.test(natural) || /^(?:暂停|停一停)(?:播放|音乐)?$/.test(natural)) a = { type: 'music', value: 'pause' };
      else if(/^(?:把)?(?:音乐|歌曲|背景音乐)(?:停止|关掉|关闭)$/.test(natural) || /^(?:停止播放|关掉音乐|关闭音乐)$/.test(natural)) a = { type: 'music', value: 'stop' };
      else if(/^(?:(?:我想)?(?:听|放|来)(?:点|一些|一下)?(?:音乐|背景音乐)|继续(?:放歌|音乐)|恢复播放)$/.test(natural)) a = { type: 'music', value: 'play' };
      else if(/^(?:换(?:一)?首(?:歌|音乐)?|(?:来|放|切到)下一首)$/.test(natural)) a = { type: 'music', value: 'next' };
      else if(/^(?:回到|放|切到)上一首$/.test(natural)) a = { type: 'music', value: 'previous' };
      else if((match = /^(?:把)?(?:音量|声音)(?:调到|调成|改成|设为)?\s*(\d{1,3})\s*(%|％|成)?$/.exec(natural))) a = { type: 'volume', value: Number(match[1]) * (match[2] === '成' ? 10 : 1) };
      else if((match = /^(?:把)?(?:音量|声音)(?:调到|调成|改成|设为)([一二三四五六七八九十])成$/.exec(natural))) a = { type: 'volume', value: '一二三四五六七八九十'.indexOf(match[1]) * 10 + 10 };
      else if((match = /^(?:把)?(?:音量|声音)(?:调)?(小|低|轻|大|高)(?:一?点|一些)$/.exec(natural))) a = { type: 'volume.adjust', value: /小|低|轻/.test(match[1]) ? -10 : 10 };
      else if((match = /^(?:把)?(?:音量|声音)(调低|降低|减小|调高|提高|增大)\s*(\d{1,3})\s*(?:%|％|个百分点)?$/.exec(natural))) a = { type: 'volume.adjust', value: Number(match[2]) * (/调低|降低|减小/.test(match[1]) ? -1 : 1) };
      else if(/^(?:切到|换成|调成|开启)(?:夜间|深色|暗色|黑夜)(?:模式|主题)?$/.test(natural) || /^(?:把)?(?:页面|屏幕|背景)调暗(?:一?点|一些)$/.test(natural)) a = { type: 'theme', value: 'dark' };
      else if(/^(?:切到|换成|调成|开启)(?:白天|日间|浅色)(?:模式|主题)?$/.test(natural) || /^(?:把)?(?:页面|屏幕|背景)调亮(?:一?点|一些)$/.test(natural)) a = { type: 'theme', value: 'light' };
      else if(/^(?:打乱播放顺序|随便放歌|随机放歌)$/.test(natural)) a = { type: 'playback', value: 'random' };
      else if(/^(?:按顺序(?:放歌|播放)|顺序播放)$/.test(natural)) a = { type: 'playback', value: 'order' };
      else if(/^(?:这首(?:歌)?(?:一直)?循环|循环(?:这首|当前)(?:歌|歌曲)?)$/.test(natural)) a = { type: 'playback', value: 'loop' };
      else if((match = /^(?:我想听|放一首|来一首)\s*[《「]?(.+?)[》」]?$/.exec(natural))) a = { type: 'track', target: match[1] };
      else if((match = /^(?:带我去|去看看|带我看看)\s*[《「]?(.+?)[》」]?$/.exec(natural))) a = { type: 'navigate', target: match[1] };
    }
    if(!a || !validateAction(a)) return null;
    return { summary: '已识别你的站内操作，点击下面的按钮后生效。', actions: [a] };
  }
  function nameKey(value) { return String(value || '').normalize('NFKC').toLowerCase().replace(/[\s《》「」“”"'，。？！：:·/\-]/g, ''); }
  var aliases = { '留言板': 'message/', '留言': 'message/', '个人图集': 'gallery/', '相册': 'gallery/', '个人随笔': 'talking/', '随笔': 'talking/',
    '工具箱': 'resources/', '工具导航': 'resources/', '博客宇宙': 'universe/', '本站历史': 'aboutsite/', '关于本站': 'aboutsite/',
    '关于博主': 'about/', '访客统计': 'pageviews/', '访问统计': 'pageviews/', '文章统计': 'statistics/', '文字工坊': 'text-workshop/',
    '写作室': 'writer/', '文章写作室': 'writer/', '友链': 'friends/', '友情链接': 'friends/', '赞赏': 'sponsor/',
    '首页': '', '归档': 'archives/', '分类': 'categories/', '标签': 'tags/' };
  function resolveTarget(entries, target, current) {
    var key = nameKey(target);
    if(['当前页面', '当前文章', '这篇文章', '本文', '本页', '这里'].includes(target)) return entries.filter(function(item) { return item.href === current; });
    var exact = entries.filter(function(item) {
      return nameKey(item.title) === key || item.path.replace(/^\/+/, '') === target.replace(/^\/+/, '')
        || Object.hasOwn(aliases, target) && item.href.endsWith('/' + aliases[target]);
    });
    // Homepage is exact-only; an empty suffix must not match every page.
    if(target === '首页') return entries.filter(function(item) { return item.path === '' || item.title === '首页'; });
    if(exact.length) return exact;
    return entries.filter(function(item) { var name = nameKey(item.title); return key.length >= 2 && name.includes(key); }).slice(0, 12);
  }
  function describe(a) {
    if(a.type === 'navigate') return '打开：' + a.target;
    if(a.type === 'search') return '站内搜索：' + a.target;
    if(a.type === 'track') return '播放歌曲：' + a.target;
    if(a.type === 'volume') return '音量 → ' + a.value + '%';
    if(a.type === 'volume.adjust') return '音量' + (a.value < 0 ? '降低' : '提高') + Math.abs(a.value) + ' 个百分点（按执行时音量调整）';
    if(a.type === 'display' || a.type === 'reading') return (labels[a.key] || a.key) + ' → ' + (typeof a.value === 'boolean' ? a.value ? '开启' : '关闭' : labels[a.value] || a.value) + (a.scope === 'defaults' ? '（作为文章默认）' : a.type === 'reading' ? '（仅本文）' : '');
    if(a.type === 'palette') return (a.key === 'primary' ? '主色' : '辅色') + ' → ' + a.value;
    if(a.type === 'display.reset') return '恢复默认显示与配色';
    if(a.type === 'palette.reset') return '恢复默认配色';
    if(a.type === 'reading.reset') return '恢复原文样式';
    if(a.type === 'reading.defaults.reset') return '重置文章默认排版';
    if(a.type === 'query') return '查询' + (a.value === 'comments' ? '评论数与评论者' : labels[a.value]) + (a.target ? '：' + a.target : '');
    if(a.type === 'panel') return a.value === 'display' ? '打开显示与阅读设置' : '打开本文阅读设置';
    return labels[a.value] || '站内操作';
  }
  function element(tag, cls, text) { var node = document.createElement(tag); if(cls) node.className = cls; if(text !== undefined) node.textContent = text; return node; }
  function controlButton(text) { var node = element('button', 'ai-action__button', text); node.type = 'button'; return node; }
  function validHref(value, root) {
    if(typeof value !== 'string' || value.length > 500 || /[?#\\%\u0000-\u0020]/.test(value) || !value.startsWith(root) || value.startsWith('//') || value.split('/').some(function(part) { return part === '..' || part === '.'; })) return false;
    return new URL(value, location.origin).origin === location.origin;
  }
  async function readJson(url, signal) {
    var controller = new AbortController(), timer = setTimeout(function() { controller.abort(); }, 20000);
    function abort() { controller.abort(); }
    if(signal.aborted) { clearTimeout(timer); throw new DOMException('Cancelled', 'AbortError'); }
    signal.addEventListener('abort', abort, { once: true });
    try {
      var response = await fetch(url, { method: 'GET', signal: controller.signal, credentials: 'omit', cache: 'no-store', redirect: 'error', referrerPolicy: 'no-referrer' });
      if(!response.ok) throw new Error('公开数据暂时无法读取，请稍后重试。');
      var reader = response.body.getReader(), decoder = new TextDecoder(), bytes = 0, output = '';
      try { while(true) { var chunk = await reader.read(); if(chunk.done) break; bytes += chunk.value.byteLength;
        if(bytes > 2097152) throw new Error('数据超过本次读取上限，请打开原页面查看。'); output += decoder.decode(chunk.value, { stream: true }); }
        output += decoder.decode();
      } finally { await reader.cancel().catch(function() {}); }
      return JSON.parse(output);
    } finally { clearTimeout(timer); signal.removeEventListener('abort', abort); }
  }
  function create(options) {
    var life = new AbortController(), signal = life.signal, catalogRequest = null;
    var bridge = window.BlogSiteControl, root = bridge && bridge.root || '/';
    var page = location.pathname, generation = window.ShokaFeatures.generation();
    function alive() { return !signal.aborted && generation === window.ShokaFeatures.generation() && location.pathname === page; }
    function guard() { if(!alive()) throw new DOMException('Cancelled', 'AbortError'); }
    if(options.signal) options.signal.addEventListener('abort', function() { life.abort(); }, { once: true, signal: signal });
    async function catalog() {
      if(!catalogRequest) catalogRequest = readJson(root + 'ai-control-catalog.json', signal).then(function(data) {
        if(!own(data, ['version', 'entries', 'friends', 'feeds']) || data.version !== 1 || !Array.isArray(data.entries) || data.entries.length > 5000) throw new Error('站内目录暂时不可用。');
        var entries = data.entries.filter(function(item) { return item && safeText(item.title, 200) && validHref(item.href, root)
          && typeof item.path === 'string' && (item.path === item.href.replace(/^\/+/, '') || item.path === item.href.slice(root.length)) && ['post', 'page'].includes(item.kind); });
        return { entries: entries, friends: Array.isArray(data.friends) ? data.friends.slice(0, 1000) : [], feeds: Array.isArray(data.feeds) ? data.feeds : [] };
      }).catch(function(error) { catalogRequest = null; throw error; });
      return catalogRequest;
    }
    function leave() { if(options.leave) options.leave(); }
    async function waline(route) {
      if(!bridge || !bridge.waline) throw new Error('本站暂未配置公开评论统计。');
      var base = new URL(bridge.waline, location.href);
      if(base.username || base.password || base.search || base.hash || (base.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(base.hostname))) throw new Error('评论服务地址不可用。');
      var result = await readJson(base.href.replace(/\/?$/, '/') + 'api/' + route, signal);
      if(!result || result.errno !== 0) throw new Error('公开统计读取失败，没有将失败当成零。');
      return result.data;
    }
    async function choose(target, container, perform) {
      var data = await catalog(); guard();
      var matches = resolveTarget(data.entries, target || '当前页面', page);
      if(!matches.length) throw new Error('没有找到对应的本站页面或文章，请提供更完整的标题。');
      if(matches.length === 1) return perform(matches[0]);
      var list = element('div', 'ai-action__choices'); list.appendChild(element('p', '', '找到多个匹配，请选择具体目标：'));
      matches.forEach(function(item) {
        var button = controlButton(item.title);
        button.addEventListener('click', async function() {
          if(button.disabled || !alive()) return;
          list.querySelectorAll('button').forEach(function(node) { node.disabled = true; });
          try { await perform(item); if(alive()) { list.remove(); container.dispatchEvent(new CustomEvent('ai-action-complete')); } }
          catch(error) { if(alive()) { container.appendChild(element('p', 'ai-action__error', error.message)); list.querySelectorAll('button').forEach(function(node) { node.disabled = false; }); } }
        }, { signal: signal }); list.appendChild(button);
      }); container.appendChild(list); return '等待选择';
    }
    function result(container, lines) { container.appendChild(element('div', 'ai-action__data', lines.join('\n'))); }
    function count(value) { return Number.isSafeInteger(value) && value >= 0 ? value : null; }
    async function query(a, container) {
      // Local playback state must remain readable without downloading the site catalog.
      if(a.value === 'player') {
        guard();
        var music = bridge && bridge.music(), state = music && music.state();
        if(!state) throw new Error('当前页面没有可控制的音乐播放器。');
        result(container, ['曲目：' + (state.name || '尚未选择'), '歌手：' + (state.artist || '未知'),
          '状态：' + (state.paused ? '暂停' : '播放中') + ' · 音量 ' + state.volume + '%' + (state.muted ? '（静音）' : ''), '模式：' + labels[state.mode]]);
        return;
      }
      var data = await catalog(); guard();
      if(a.value === 'articles') {
        var posts = data.entries.filter(function(item) { return item.kind === 'post'; }), categories = new Set(), tags = new Set(), years = new Map();
        posts.forEach(function(item) {
          (item.categories || []).forEach(function(c) { if(typeof c === 'string') categories.add(c); });
          (item.tags || []).forEach(function(c) { if(typeof c === 'string') tags.add(c); });
          var year = typeof item.date === 'string' && /^\d{4}-/.test(item.date) ? item.date.slice(0, 4) : '日期未设置';
          years.set(year, (years.get(year) || 0) + 1);
        });
        result(container, ['公开文章：' + posts.length + ' 篇', '正文总字数：' + posts.reduce(function(n, item) { return n + (count(item.wordCount) || 0); }, 0).toLocaleString() + ' 字',
          '分类：' + categories.size + ' 个 · 标签：' + tags.size + ' 个', '按文章发布日期：' + Array.from(years).sort().map(function(row) { return row[0] + ' 年 ' + row[1] + ' 篇'; }).join('、'),
          '篇幅最长的文章：', posts.slice().sort(function(a, b) { return (count(b.wordCount) || 0) - (count(a.wordCount) || 0); }).slice(0, 3).map(function(item) { return item.title + ' · ' + item.wordCount.toLocaleString() + ' 字'; }).join('\n'),
          '统计来自本次博客生成的公开目录，不包含未发布文章。']);
      } else if(a.value === 'friends') {
        var friends = data.friends.filter(function(item) { return item && safeText(item.name, 180) && safeText(item.owner, 180); });
        result(container, ['友情链接：' + friends.length + ' 位', friends.map(function(item) { return item.name + (item.owner !== item.name ? '（' + item.owner + '）' : ''); }).join('、')]);
      } else if(a.value === 'visits') {
        var rows = [], entries = data.entries.filter(function(item) { return item.counted; });
        for(var offset = 0; offset < entries.length; offset += 40) {
          var batch = entries.slice(offset, offset + 40), values = await waline('article?type=time&path=' + encodeURIComponent(batch.map(function(item) { return item.path; }).join(','))); guard();
          if(!Array.isArray(values) || values.length !== batch.length || values.some(function(value) { return !value || count(value.time) === null; })) throw new Error('浏览量数据不完整，请打开访问统计页查看。');
          values.forEach(function(value, i) { rows.push({ title: batch[i].title, time: value.time }); });
        }
        result(container, ['已计数页面与文章的累计浏览量：' + rows.reduce(function(n, row) { return n + row.time; }, 0).toLocaleString(),
          '浏览量不是独立访客人数；不包含首页、归档、分类、标签、分页及写作室。', '浏览量排行：',
          rows.sort(function(a, b) { return b.time - a.time; }).slice(0, 5).map(function(row, i) { return (i + 1) + '. ' + row.title + ' · ' + row.time; }).join('\n')]);
        try {
          var history = await waline('pageview-history'); guard();
          var days = history && history.dailyTotals && Array.isArray(history.dailyTotals.calendar) ? history.dailyTotals.calendar : [];
          var latest = days.filter(function(day) { return day.status === 'complete' && count(day.views) !== null; }).slice(-7);
          result(container, latest.length ? ['最近完整日的访问量（北京时间）：', latest.map(function(day) { return String(day.date).slice(0, 10) + '：' + day.views; }).join('\n'), '缺口与不满整日的数据未按零访问补齐。'] : ['暂无可用的整日访问记录。']);
          if(Array.isArray(history.growth)) result(container, ['近期采集区间的浏览量增长（不是整日访问量）：', history.growth.slice(0, 5).map(function(row) {
            var item = data.entries.find(function(item) { return item.path === String(row.path || '').replace(/^\/+/, ''); });
            return item && count(row.views) !== null ? item.title + '：+' + row.views + '（' + String(row.from).slice(0, 10) + '～' + String(row.to).slice(0, 10) + '，缺口 ' + (count(row.missingDays) || 0) + ' 天）' : '';
          }).filter(Boolean).join('\n')]);
        } catch(error) { if(alive()) result(container, ['整日访问记录暂时无法读取；上面的累计浏览量仍可参考。']); }
      } else {
        return choose(a.target, container, async function(item) {
          if(a.value === 'views') {
            if(!item.counted) { result(container, [item.title + '：此页面按站点设置不统计浏览量。']); return; }
            var views = await waline('article?type=time&path=' + encodeURIComponent(item.path)); guard();
            if(!Array.isArray(views) || !views[0] || count(views[0].time) === null) throw new Error('浏览量数据不完整。');
            result(container, [item.title, '累计浏览量：' + views[0].time]);
          } else {
            var comments = await waline('comment?path=' + encodeURIComponent(item.path) + '&page=1&pageSize=10&sortBy=insertedAt_desc'); guard();
            if(!comments || count(comments.count) === null || !Array.isArray(comments.data)) throw new Error('评论数据不完整。');
            var names = new Set();
            comments.data.slice(0, 10).forEach(function(row) { [row].concat(Array.isArray(row.children) ? row.children.slice(0, 100) : []).forEach(function(c) { if(c && safeText(c.nick, 180)) names.add(c.nick); }); });
            result(container, [item.title, '公开评论：' + comments.count + ' 条', '最近一页的评论者：' + (Array.from(names).join('、') || '暂无'),
              '这里只展示公开昵称，不展示邮箱、IP、登录信息；完整评论请到原页面查看。']);
          }
        });
      }
    }
    async function execute(a, container, button) {
      guard();
      if(a.type === 'query') return query(a, container);
      if(a.type === 'navigate') return choose(a.target, container, function(item) { guard(); leave();
        if(!bridge || !bridge.navigate || !bridge.navigate(item.href)) location.assign(item.href);
      });
      if(a.type === 'feed') {
        var data = await catalog(); guard(); var file = { rss: 'rss.xml', atom: 'atom.xml', json: 'feed.json' }[a.value];
        var feed = data.feeds.find(function(item) { return item && item.file === file && validHref(item.href, root); });
        if(!feed) throw new Error('这个订阅源尚未生成。');
        // Use a visible real link after async loading, avoiding popup blocking.
        var link = element('a', 'ai-action__button', '打开 ' + labels[a.value]); link.href = feed.href; link.target = '_blank'; link.rel = 'noopener noreferrer'; container.appendChild(link); return '订阅链接已就绪';
      }
      if(a.type === 'search') { if(!window.ShokaSearch) throw new Error('站内搜索暂未启用。'); leave(); window.ShokaSearch.open(a.target); return; }
      if(a.type === 'scroll') {
        var target = a.value === 'comments' ? document.getElementById('comments') : null;
        if(a.value === 'comments' && !target) throw new Error('当前页面没有评论区。');
        var top = a.value === 'top' ? 0 : a.value === 'bottom' ? document.documentElement.scrollHeight - innerHeight : target.getBoundingClientRect().top + scrollY - 80;
        var reduce = document.documentElement.dataset.motion === 'reduce' || window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        leave(); window.scrollTo({ top: top, behavior: reduce ? 'instant' : 'smooth' }); return;
      }
      if(a.type === 'theme') { window.ShokaFeatures.setTheme(a.value); return; }
      if(['music', 'volume', 'volume.adjust', 'track', 'playback'].includes(a.type)) {
        var music = bridge && bridge.music(); if(!music) throw new Error('没有可控制的音乐播放器。');
        if(a.type === 'music' && ['pause', 'stop'].includes(a.value)) { music[a.value](); return; }
        // Volume/mode/mute do not need to fetch a playlist or contact AI.
        if(a.type === 'volume' || a.type === 'volume.adjust') {
          var value = a.type === 'volume' ? a.value : Math.max(0, Math.min(100, music.state().volume + a.value));
          music.volume(value); return '音量已调至 ' + music.state().volume + '%';
        }
        if(a.type === 'playback') { music.mode(a.value); return; }
        if(a.type === 'music' && ['mute', 'unmute'].includes(a.value)) { music.mute(a.value === 'mute'); return; }
        await music.prepare(); guard();
        if(!music.tracks().length) throw new Error('歌单未加载成功，请稍后重试。');
        if(a.type === 'music') { if(a.value === 'play') await music.play(); else music[a.value](); }
        else {
          var matches = music.tracks().filter(function(item) { return nameKey(item.name) === nameKey(a.target); });
          if(!matches.length) matches = music.tracks().filter(function(item) { return nameKey(item.name).includes(nameKey(a.target)) || nameKey(item.name + ' ' + item.artist).includes(nameKey(a.target)); }).slice(0, 12);
          if(!matches.length) throw new Error('已加载的歌单里没有找到这首歌；不会下载或绕过音源权限。');
          if(matches.length === 1) { music.track(matches[0].index); await music.play(); }
          else {
            var choices = element('div', 'ai-action__choices'); choices.appendChild(element('p', '', '请选择曲目：'));
            matches.forEach(function(item) { var pick = controlButton(item.name + ' · ' + item.artist + (item.group ? ' · ' + item.group : ''));
              pick.addEventListener('click', async function() { if(!alive() || pick.disabled) return;
                choices.querySelectorAll('button').forEach(function(node) { node.disabled = true; });
                try {
                  var current = music.tracks().find(function(track) { return track.index === item.index; });
                  if(!current || current.name !== item.name || current.artist !== item.artist || current.group !== item.group) throw new Error('歌单已变化，请重新生成歌曲选择。');
                  music.track(item.index); await music.play();
                  if(alive()) { choices.remove(); result(container, ['正在播放：' + item.name]); container.dispatchEvent(new CustomEvent('ai-action-complete')); }
                } catch(error) { if(alive()) { choices.querySelectorAll('button').forEach(function(node) { node.disabled = false; }); result(container, [error.message || '播放未成功，请再次点击或使用音乐按钮播放。']); } }
              }, { signal: signal }); choices.appendChild(pick); }); container.appendChild(choices); return '等待选择';
          }
        } return;
      }
      if(a.type === 'display' || a.type === 'display.reset' || a.type === 'panel' && a.value === 'display') {
        var display = await window.ShokaFeatures.load('display_preferences'); guard();
        if(a.type === 'panel') { leave(); display.open(); return; }
        var saved = a.type === 'display.reset' ? display.reset() : display.update(Object.fromEntries([[a.key, a.value]]));
        if(!saved) return '已应用；浏览器禁止保存，刷新后可能恢复'; return;
      }
      if(a.type === 'palette' || a.type === 'palette.reset') {
        var palette = window.ShokaPalette; if(!palette) throw new Error('主题调色盘暂不可用。');
        var colors = Object.assign({}, palette.read() || palette.defaults); colors[a.key] = a.value;
        if(!(a.type === 'palette.reset' ? palette.reset() : palette.save(colors))) return '已应用；浏览器禁止保存'; return;
      }
      if(a.type.startsWith('reading') || a.type === 'panel' && a.value === 'reading') {
        var session = window.ShokaReadingArticle && window.ShokaReadingArticle.current();
        if(!session || session.signal.aborted) throw new Error('此操作仅在文章正文可用。');
        if(a.type === 'panel') { var reader = await window.ShokaFeatures.load('article_reader'); guard(); leave(); reader.open(button, session); }
        else if(a.type === 'reading.reset') session.resetOriginal();
        else if(a.type === 'reading.defaults.reset') session.setTypography({}, true);
        else if(['focus', 'spotlight', 'practice', 'tracking'].includes(a.key)) session['set' + a.key[0].toUpperCase() + a.key.slice(1)](a.value);
        else session.setTypography(Object.assign({}, session.prefs, Object.fromEntries([[a.key, a.value]])), a.scope === 'defaults');
        if(session.storageOK === false) return '已应用；当前浏览器限制保存，刷新后可能恢复';
      }
    }
    function render(plan, target) {
      var checked = parse(JSON.stringify(plan)); if(!checked || !alive()) return false;
      var card = element('section', 'ai-action'); card.setAttribute('aria-label', '站内操作建议');
      card.append(element('h4', 'ai-action__title', '站内操作'), element('p', 'ai-action__summary', checked.summary));
      if(!checked.actions.length) card.appendChild(element('p', '', '没有匹配到受支持的操作，可切回自由问答。'));
      checked.actions.forEach(function(a) {
        var row = element('div', 'ai-action__row'), title = element('strong', '', describe(a)), button = controlButton(a.type === 'query' ? '读取公开数据' : '确认执行');
        var status = element('p', 'ai-action__status'); status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite');
        var output = element('div', 'ai-action__output'); row.append(title, button, status, output); card.appendChild(row);
        var finished = false;
        output.addEventListener('ai-action-complete', function() {
          finished = a.type !== 'query'; status.textContent = a.type === 'query' ? '已读取公开数据' : '已执行';
          if(a.type === 'query') { button.disabled = false; button.textContent = '刷新数据'; }
        }, { signal: signal });
        button.addEventListener('click', async function() {
          if(finished || button.disabled || !alive()) return;
          button.disabled = true; status.textContent = '正在处理…'; output.replaceChildren();
          try { var message = await execute(a, output, button); if(!alive()) return;
            finished = message !== '等待选择'; status.textContent = message || (a.type === 'query' ? '已读取 · ' + new Date().toLocaleTimeString() : '已执行');
            if(a.type === 'query') { finished = false; button.disabled = false; button.textContent = '刷新数据'; }
          } catch(error) { if(!alive()) return; button.disabled = false; status.textContent = error.name === 'AbortError' ? '读取超时，请稍后重试。' : a.type === 'music' && a.value === 'play' ? '播放未成功，请再次点击；浏览器可能限制自动播放。' : error.message; }
        }, { signal: signal });
      });
      card.appendChild(element('small', 'ai-action__foot', '设置只影响当前浏览器。数据只读，按钮确认后才操作；不访问管理后台。'));
      target.replaceChildren(card); return true;
    }
    return { render: render, destroy: function() { life.abort(); catalogRequest = null; } };
  }
  function commandIntent(input) {
    if(!safeText(input, 1000)) return false;
    // A question about implementation is still normal Q&A. Explicit controls
    // and public data requests can opt into planning without toggling a mode.
    if(/(?:如何|怎么|怎样|为什么|是什么原理|什么意思|示例|代码)/.test(input)) return false;
    var text = input.trim().replace(/^(?:(?:请|麻烦)(?:帮我|给我)?|帮我|给我)/, '');
    return /^(?:播放|(?:暂停|停止|继续播放)(?:音乐|播放|歌曲|歌单|背景音乐)|切换(?:音乐|歌曲|歌单)|(?:把)?音量|(?:把)?(?:页面)?背景|(?:把)?(?:背景)?纹理|(?:把)?(?:主色|辅色)|(?:把)?(?:文章|正文)?(?:字号|行高|段落间距|正文宽度)|(?:首页|文章)?(?:布局|排列)|(?:开启|关闭)(?:专注阅读|段落聚焦|步骤跟读|阅读记录|减弱动效)|(?:打开|前往|进入)(?:页面|文章|关于|留言|个人|工具|博客|文字|友链|友情链接|RSS|ATOM|JSON|首页|归档|分类|标签|访问统计|文章统计)|(?:站内搜索|搜索)|(?:查看|查询)?(?:当前|本文|这篇|关于).*(?:浏览量|访问量|评论数|评论者)|(?:查看|统计)(?:本站|博客)?(?:文章统计|访问统计|友链))/.test(text)
      || /^(?:能不能|可以|能否)?(?:帮我|给我)?(?:先|现在)?(?:换首歌|换一首|我想听|放点音乐|来点音乐|带我去|去看看|把声音|声音|(?:让)?音乐(?:先)?(?:暂停|停|关|歇)|切到(?:深色|浅色|夜间|白天)|打乱播放顺序|按顺序放歌|这首歌循环)/.test(text)
      || /(?:太亮|刺眼|天黑了|有点暗).*(?:切|换|调).*(?:深色|浅色|夜间|白天|暗一点|亮一点|暗些|亮些)/.test(text);
  }
  if(typeof module === 'object' && module.exports) module.exports = { parse: parse, localPlan: localPlan, commandIntent: commandIntent, validateAction: validateAction, resolveTarget: resolveTarget, enums: enums, describe: describe };
  if(typeof window !== 'undefined') window.BlogAIActions = { create: create, parse: parse, localPlan: localPlan, commandIntent: commandIntent, describe: describe };
}());
