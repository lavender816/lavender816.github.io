
// Merge this field into the CONFIG object in the theme's app generator.
// Values are public. NEVER place apiKey/adminToken here.
blogAI: {
  enabled: theme.blog_ai && theme.blog_ai.enable === true,
  endpoint: 'https://ai.example.com',
  siteUrl: config.url
}
