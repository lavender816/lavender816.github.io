// No network or model work until a visitor opens an AI surface and explicitly submits.
window.BlogAIConfig = Object.freeze(Object.assign({}, CONFIG.blogAI));
var blogAIGeneration = 0, blogAISelection = '', blogAISelectionButton = null, blogAISelectionRange = null;
var blogAIHosts = Object.create(null), blogAIInitialized = false, blogAIToggle = null;
var blogAIPositionFrame = 0;
var blogAIReferenceTimer = 0;
window.BlogAIReference = function(anchor) {
  var body = document.querySelector('#main [data-blog-ai-content] .body[itemprop="articleBody"]');
  if(!body) return false;
  var id; try { id = decodeURIComponent(anchor || ''); } catch(error) { return false; }
  var target = id ? document.getElementById(id) : body;
  if(!target || (target !== body && !body.contains(target)) || target.closest('[hidden],[data-private],[data-ai="false"]')) target = body;
  document.querySelectorAll('.blog-ai-original-focus').forEach(function(node) { node.classList.remove('blog-ai-original-focus'); });
  clearTimeout(blogAIReferenceTimer); target.classList.add('blog-ai-original-focus');
  var reduced = document.documentElement.dataset.motion === 'reduce' || matchMedia('(prefers-reduced-motion: reduce)').matches;
  target.scrollIntoView({ block: 'center', behavior: reduced ? 'auto' : 'smooth' });
  blogAIReferenceTimer = setTimeout(function() { target.classList.remove('blog-ai-original-focus'); }, 6000);
  return true;
};
const visitBlogAIReference = function() {
  if((location.hash || '').indexOf('#ai-source=') === 0) requestAnimationFrame(function() { window.BlogAIReference(location.hash.slice(11)); });
};
const blogAIContext = function() {
  var info = document.querySelector('#main [data-reading-post]');
  var post = document.querySelector('#main .article .post[data-blog-ai-content]');
  var title = document.querySelector('#header h1'), headings = [];
  // Read only displayed article headings on intent, never comments, forms or a full article dump.
  var body = post && post.querySelector('.body[itemprop="articleBody"]');
  if(body) Array.from(body.querySelectorAll('h2,h3')).slice(0, 40).forEach(function(heading) {
    if(headings.length >= 8 || !heading.getClientRects().length
      || heading.closest('[hidden],[aria-hidden="true"],[data-private],[data-ai="false"],.blog-ai,.waline,.highlight,.smx-code-tree,.code-tree')) return;
    var text = heading.textContent.replace(/\s+/g, ' ').trim().slice(0, 80);
    if(text.length >= 2 && !headings.includes(text)) headings.push(text);
  });
  return { path: location.pathname, title: info ? info.dataset.title : title ? title.textContent.trim() : document.title.split(' | ')[0],
    article: !!post, headings: headings };
};
const blogAIIcon = function(kind) {
  var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 24 24'); svg.setAttribute('width', '20'); svg.setAttribute('height', '20');
  svg.setAttribute('fill', 'none'); svg.setAttribute('stroke', 'currentColor'); svg.setAttribute('stroke-width', '1.9');
  svg.setAttribute('stroke-linecap', 'round'); svg.setAttribute('stroke-linejoin', 'round'); svg.setAttribute('aria-hidden', 'true');
  var paths = kind === 'selection' ? ['M8 3H4v4M4 17v4h4M16 3h4v4M20 17v4h-4M8 10h8M8 14h5', 'm18 9 1.1 2.9L22 13l-2.9 1.1L18 17l-1.1-2.9L14 13l2.9-1.1Z']
    : kind === 'spark' ? ['m12 3 2.6 6.4L21 12l-6.4 2.6L12 21l-2.6-6.4L3 12l6.4-2.6Z']
    : kind === 'close' ? ['m6 6 12 12', 'M18 6 6 18']
    : kind === 'refresh' ? ['M20 7v5h-5', 'M4 17v-5h5', 'M6.1 7a7 7 0 0 1 11.8-1L20 9', 'M17.9 17a7 7 0 0 1-11.8 1L4 15']
    : kind === 'send' ? ['m4 4 17 8-17 8 3-8-3-8Z', 'M7 12h14']
    : ['M21 12a9 9 0 1 1-9-9', 'M8 9c-2 2-2 5 0 7M12 8c-2 3-2 6 0 9M16 10c-1 2-1 4 0 6', 'm19 1 1.1 2.9L23 5l-2.9 1.1L19 9l-1.1-2.9L15 5l2.9-1.1Z'];
  paths.forEach(function(d) { var path = document.createElementNS(svg.namespaceURI, 'path'); path.setAttribute('d', d); svg.appendChild(path); });
  return svg;
};
const syncBlogAIToggle = function() {
  if(!blogAIToggle) return;
  var opened = !!blogAIHosts.chat;
  blogAIToggle.setAttribute('aria-expanded', String(opened));
  blogAIToggle.setAttribute('aria-label', opened ? '关闭 AI 助手' : '打开 AI 助手');
  blogAIToggle.title = opened ? '关闭 AI 助手' : '打开 AI 助手';
  if(opened) blogAIToggle.setAttribute('aria-controls', 'blog-ai-chat');
  else blogAIToggle.removeAttribute('aria-controls');
};
const closeBlogAIHost = function(mode, focus) {
  var record = blogAIHosts[mode];
  if(!record) return;
  record.token++;
  if(window.ShokaBlogAI && window.ShokaBlogAI.destroyHost) window.ShokaBlogAI.destroyHost(record.host);
  record.host.hidden = true;
  if(mode !== 'guide' && mode !== 'tour') record.host.remove();
  if(record.opener) record.opener.setAttribute('aria-expanded', 'false');
  delete blogAIHosts[mode];
  if(mode === 'chat') syncBlogAIToggle();
  if(focus && record.opener && record.opener.isConnected) record.opener.focus({ preventScroll: true });
};
const positionBlogAIHost = function(mode) {
  var record = blogAIHosts[mode];
  if(!record || !record.host.isConnected || record.host.hidden) return;
  var view = window.visualViewport;
  var width = view ? view.width : window.innerWidth, height = view ? view.height : window.innerHeight;
  var offsetTop = view ? view.offsetTop : 0, offsetLeft = view ? view.offsetLeft : 0;
  var host = record.host;
  if(mode === 'explain') {
    if(host.classList.contains('is-expanded')) {
      host.style.setProperty('--ai-viewport-height', height + 'px');
      host.style.setProperty('--ai-viewport-width', width + 'px');
      host.style.left = offsetLeft + width / 2 + 'px'; host.style.top = offsetTop + height / 2 + 'px';
      return;
    }
    var rect = record.range && record.range.startContainer.isConnected ? record.range.getBoundingClientRect() : null;
    if(!rect) { closeBlogAIHost(mode, false); return; }
    var topEdge = offsetTop + 70, bottomEdge = offsetTop + height - 12;
    var availableHeight = Math.max(80, bottomEdge - topEdge);
    var below = Math.max(0, bottomEdge - rect.bottom - 12), above = Math.max(0, rect.top - topEdge - 12);
    var useBelow = below >= Math.min(360, availableHeight) || below >= above;
    var maxHeight = Math.min(540, availableHeight, Math.max(150, useBelow ? below : above));
    host.style.setProperty('--ai-popover-height', maxHeight + 'px');
    var boxWidth = Math.min(432, width - 24), top = useBelow ? rect.bottom + 12 : rect.top - maxHeight - 12;
    // Document coordinates keep the answer attached to its text while the page scrolls.
    host.style.left = window.scrollX + Math.max(offsetLeft + 12, Math.min(offsetLeft + width - boxWidth - 12, rect.left)) + 'px';
    host.style.top = window.scrollY + Math.max(topEdge, Math.min(bottomEdge - maxHeight, top)) + 'px';
  } else if(mode === 'ask' || mode === 'chat') {
    host.style.setProperty('--ai-viewport-height', height + 'px');
    host.style.setProperty('--ai-viewport-top', offsetTop + 'px');
    host.style.setProperty('--ai-viewport-width', width + 'px');
    host.style.setProperty('--ai-keyboard-offset', Math.max(0, window.innerHeight - offsetTop - height) + 'px');
  }
};
const expandBlogAIExplanation = function() {
  var record = blogAIHosts.explain;
  if(!record) return;
  var expanded = record.host.classList.toggle('is-expanded');
  var button = record.host.querySelector('.blog-ai__expand');
  if(button) { button.setAttribute('aria-expanded', String(expanded)); button.setAttribute('aria-label', expanded ? '恢复选区附近显示' : '放大选区解释'); button.title = button.getAttribute('aria-label'); }
  positionBlogAIHost('explain');
};
const renderBlogAIBoot = function(record, mode, selectedText, context) {
  // The deferred bundle only replaces content, not the dialog's silhouette.
  // Reuse the final component classes so a slow/failed connection never shows
  // a visually different interim panel. The primary action remains disabled.
  var shell = document.createElement('section'); shell.className = 'blog-ai blog-ai--embedded blog-ai--boot';
  shell.dataset.mode = mode; shell.dataset.connection = 'checking';
  var head = document.createElement('header'); head.className = 'blog-ai__head';
  var brand = document.createElement('div'); brand.className = 'blog-ai__brand';
  var mark = document.createElement('span'); mark.className = 'blog-ai__mark'; mark.appendChild(blogAIIcon('spark'));
  var titles = document.createElement('div'); titles.className = 'blog-ai__titles';
  var title = document.createElement('h3'); title.className = 'blog-ai__title';
  title.textContent = { ask: '问问本站', chat: 'Blog AI', explain: '选区解释', guide: '文章导读', tour: '宇宙 AI 导游' }[mode];
  var state = document.createElement('p'); state.className = 'blog-ai__service'; state.textContent = '正在检查连接…'; state.setAttribute('role', 'status');
  titles.append(title, state); brand.append(mark, titles);
  var headActions = document.createElement('div'); headActions.className = 'blog-ai__head-actions';
  var retry = document.createElement('button'); retry.type = 'button'; retry.className = 'blog-ai__retry'; retry.hidden = true;
  retry.setAttribute('aria-label', '重新加载 AI 界面'); retry.title = '重新加载 AI 界面'; retry.appendChild(blogAIIcon('refresh'));
  var close = document.createElement('button'); close.type = 'button'; close.className = 'blog-ai__close';
  close.setAttribute('aria-label', '关闭' + title.textContent); close.appendChild(blogAIIcon('close'));
  close.addEventListener('click', function() { closeBlogAIHost(mode, true); }); headActions.append(retry, close); head.append(brand, headActions);

  var scroll = document.createElement('div'); scroll.className = 'blog-ai__scroll';
  var intro = document.createElement('div'); intro.className = 'blog-ai__intro';
  var hint = document.createElement('p'); hint.className = 'blog-ai__hint';
  hint.textContent = { ask: '优先参考本站文章，没有相关资料时也能正常回答。', chat: '博客资料优先，也能聊知识、编程和灵感。', explain: '确认要解释的文字。只发送下面的选区，不会上传整篇文章。', guide: '先了解这篇文章的关键内容和阅读路线，再慢慢读。', tour: '说说你想逛的主题，回答完成后点亮相关的文章星点。也可以聊博客之外的话题。' }[mode];
  intro.appendChild(hint);
  if(mode === 'guide') {
    var article = document.createElement('p'); article.className = 'blog-ai__article'; article.textContent = blogAIContext().title; intro.appendChild(article);
  }
  if(mode === 'ask' || mode === 'chat') {
    var play = document.createElement('button'); play.type = 'button'; play.className = 'blog-ai__play-entry';
    play.textContent = '站内玩法 · 导航 / 漫游'; play.disabled = true; intro.appendChild(play);
  }
  scroll.appendChild(intro);
  var form = document.createElement('form'); form.className = 'blog-ai__form'; form.addEventListener('submit', function(event) { event.preventDefault(); });
  var field = document.createElement('div'); field.className = 'blog-ai__field';
  var label = document.createElement('label'); label.className = 'blog-ai__label';
  label.textContent = mode === 'explain' ? '待解释的文字' : mode === 'guide' ? '当前文章' : mode === 'tour' ? '今天往哪里漫游' : mode === 'ask' ? '你想了解什么' : '想问点什么';
  var input = document.createElement('textarea'); input.className = 'blog-ai__input'; input.rows = mode === 'explain' ? 4 : 2;
  input.maxLength = mode === 'explain' ? 4000 : 1000;
  input.placeholder = mode === 'ask' ? '博客文章、技术问题，或任何想聊的话题…' : mode === 'tour' ? '想逛逛音乐、视觉设计或博客背后的故事…' : '今天有什么想聊的？';
  input.value = mode === 'explain' ? selectedText.slice(0, 4000) : '';
  if(mode === 'guide') { input.hidden = true; field.hidden = true; }
  label.appendChild(input); field.appendChild(label); form.appendChild(field);
  if(mode === 'ask' || mode === 'chat') {
    var suggestions = document.createElement('div'); suggestions.className = 'blog-ai__suggestions';
    var suggestionHead = document.createElement('div'); suggestionHead.className = 'blog-ai__suggestion-head';
    var suggestionLabel = document.createElement('span'); suggestionLabel.className = 'blog-ai__suggestion-label';
    suggestionLabel.textContent = context.article ? '围绕本文提问' : '随便问问博客';
    var refresh = document.createElement('button'); refresh.type = 'button'; refresh.className = 'blog-ai__suggestion-refresh';
    refresh.disabled = true; refresh.setAttribute('aria-label', '推荐问题正在准备');
    var refreshText = document.createElement('span'); refreshText.textContent = '换一组'; refresh.append(blogAIIcon('refresh'), refreshText);
    suggestionHead.append(suggestionLabel, refresh);
    var suggestionList = document.createElement('div'); suggestionList.className = 'blog-ai__suggestion-list';
    var prompts = context.article ? ['概括本文的核心要点', '用小白能懂的话讲讲'] : ['第一次来，推荐先读哪些博客文章？', '本站有哪些 Markdown 扩展用法？'];
    prompts.forEach(function(prompt) {
      var suggestion = document.createElement('button'); suggestion.type = 'button'; suggestion.className = 'blog-ai__suggestion';
      suggestion.textContent = prompt; suggestion.disabled = true; suggestionList.appendChild(suggestion);
    });
    suggestions.append(suggestionHead, suggestionList); form.appendChild(suggestions);
  }
  if(mode === 'ask' || mode === 'chat') {
    var webToggle = document.createElement('label'); webToggle.className = 'blog-ai__web-toggle';
    var web = document.createElement('input'); web.type = 'checkbox'; web.disabled = true;
    var webText = document.createElement('span'); webText.textContent = '联网检索待服务器启用';
    webToggle.append(web, webText); form.appendChild(webToggle);
  }
  var actions = document.createElement('div'); actions.className = 'blog-ai__actions';
  var notice = document.createElement('p'); notice.className = 'blog-ai__notice';
  var send = document.createElement('button'); send.type = 'submit'; send.className = 'blog-ai__send'; send.disabled = true;
  send.appendChild(blogAIIcon('send'));
  var sendText = document.createElement('span'); sendText.textContent = { ask: '查找并回答', chat: '发送', explain: '解释这段文字', guide: '生成导读', tour: '发现航线' }[mode];
  send.appendChild(sendText); actions.append(notice, send); form.appendChild(actions);
  scroll.appendChild(form); shell.append(head, scroll); record.host.replaceChildren(shell);
  return { shell: shell, input: input, state: state, retry: retry, notice: notice };
};
const openBlogAI = function(mode, opener) {
  if(!CONFIG.blogAI || !CONFIG.blogAI.enabled || !['ask', 'guide', 'explain', 'chat', 'tour'].includes(mode)) return;
  if(mode === 'explain' && (!blogAISelection || !blogAISelectionRange || !blogAISelectionRange.startContainer.isConnected)) {
    showtip('请先选中文章或页面正文中想解释的文字。', true); return;
  }
  if((mode === 'ask' || mode === 'chat' || mode === 'tour') && blogAIHosts[mode]) { closeBlogAIHost(mode, true); return; }
  // Only one floating answer at a time; inline article guides retain their results.
  ['ask', 'chat', 'explain'].forEach(function(other) { if(other !== mode) closeBlogAIHost(other, false); });
  if(mode === 'explain' && blogAIHosts.explain) closeBlogAIHost('explain', false);
  var record = blogAIHosts[mode], context = blogAIContext();
  if(!record) {
    var host = mode === 'guide' || mode === 'tour' ? document.querySelector('#main [data-blog-ai-host="' + mode + '"]') : null;
    if(mode === 'tour' && !host) return;
    if(mode === 'guide' && !host) { showtip('请在文章页面中使用文章导读。', true); return; }
    if(!host) {
      host = document.createElement('aside'); host.className = 'blog-ai-host blog-ai-host--' + mode;
      host.dataset.blogAiHost = mode; host.setAttribute('aria-label', mode === 'ask' ? '问问本站' : mode === 'explain' ? '选区解释' : 'AI 助手');
      if(mode === 'chat') host.id = 'blog-ai-chat';
      document.body.appendChild(host);
    }
    record = blogAIHosts[mode] = { host: host, opener: opener, token: 0, range: mode === 'explain' ? blogAISelectionRange.cloneRange() : null };
  }
  record.host.hidden = false;
  if(opener) opener.setAttribute('aria-expanded', 'true');
  if(mode === 'chat') syncBlogAIToggle();
  if(record.handle) { record.handle.focus(); return; }
  var generation = blogAIGeneration, token = ++record.token, selectedText = blogAISelection;
  var boot = renderBlogAIBoot(record, mode, selectedText, context);
  record.host.setAttribute('aria-busy', 'true');
  positionBlogAIHost(mode);
  loadAI('blog_ai').then(function(api) {
    if(generation !== blogAIGeneration || !record.host.isConnected || record.host.hidden || record.token !== token) return;
    record.handle = api.mountEmbedded(record.host, Object.assign(context, {
      mode: mode === 'tour' ? 'ask' : mode, tour: mode === 'tour', text: mode === 'explain' ? boot.input.value : '', question: mode !== 'explain' ? boot.input.value : '', opener: opener,
      onExpand: expandBlogAIExplanation,
      onTour: function(sources) { if(mode === 'tour' && window.BlogUniverse) window.BlogUniverse.setAITour(sources); },
      onClose: function() { closeBlogAIHost(mode, true); },
      onControlLeave: function() { closeBlogAIHost(mode, false); }
    }));
    positionBlogAIHost(mode);
    if(mode === 'guide') record.host.scrollIntoView({ block: 'nearest', behavior: 'auto' });
    if(mode === 'tour') {
      var tourAction = record.host.querySelector('.blog-ai__send');
      if(tourAction) tourAction.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'auto' });
    }
  }).catch(function() {
    if(generation !== blogAIGeneration || record.token !== token || !record.host.isConnected) return;
    boot.shell.dataset.connection = 'offline';
    boot.state.textContent = 'AI 界面加载失败 · 请重新连接';
    boot.notice.textContent = '界面资源暂时无法加载，重试前不会发送内容。';
    boot.retry.hidden = false;
    boot.retry.addEventListener('click', function() {
      var pendingText = boot.input.value;
      closeBlogAIHost(mode, false); openBlogAI(mode, opener);
      var nextInput = blogAIHosts[mode] && blogAIHosts[mode].host.querySelector('.blog-ai--boot .blog-ai__input');
      if(nextInput) nextInput.value = pendingText;
    }, { once: true });
  }).finally(function() { record.host.removeAttribute('aria-busy'); });
};
const destroyBlogAI = function() {
  if(blogAIPositionFrame) { cancelAnimationFrame(blogAIPositionFrame); blogAIPositionFrame = 0; }
  blogAIGeneration++;
  Object.keys(blogAIHosts).forEach(function(mode) { closeBlogAIHost(mode, false); });
  blogAISelection = ''; blogAISelectionRange = null;
  if(blogAISelectionButton) blogAISelectionButton.hidden = true;
  if(window.ShokaBlogAI && window.ShokaBlogAI.destroy) window.ShokaBlogAI.destroy();
  syncBlogAIToggle();
};
const initBlogAI = function() {
  if(blogAIInitialized || !CONFIG.blogAI || !CONFIG.blogAI.enabled) return;
  blogAIInitialized = true;
  blogAISelectionButton = document.createElement('button');
  blogAISelectionButton.type = 'button'; blogAISelectionButton.className = 'blog-ai-selection'; blogAISelectionButton.hidden = true;
  blogAISelectionButton.dataset.blogAi = 'explain'; blogAISelectionButton.appendChild(blogAIIcon('selection'));
  var selectionLabel = document.createElement('span'); selectionLabel.textContent = '解释这段文字'; blogAISelectionButton.appendChild(selectionLabel);
  document.body.appendChild(blogAISelectionButton);
  blogAISelectionButton.addEventListener('pointerdown', function(event) { event.preventDefault(); });
  blogAIToggle = document.createElement('button'); blogAIToggle.type = 'button'; blogAIToggle.className = 'item blog-ai-toggle';
  blogAIToggle.dataset.blogAiToggle = ''; blogAIToggle.dataset.blogAi = 'chat';
  blogAIToggle.appendChild(blogAIIcon('assistant'));
  toolBtn.insertBefore(blogAIToggle, toolPlayer);
  syncBlogAIToggle();
  function capture() {
    if(document.querySelector('dialog[open]')) return;
    var body = document.querySelector('#main [data-blog-ai-content] .body[itemprop="articleBody"]');
    var selection = window.getSelection();
    if(!body || !selection || !selection.rangeCount || selection.isCollapsed) { blogAISelectionButton.hidden = true; return; }
    var range = selection.getRangeAt(0);
    if(!body.contains(range.startContainer) || !body.contains(range.endContainer)) { blogAISelectionButton.hidden = true; return; }
    var anchor = range.startContainer.nodeType === 1 ? range.startContainer : range.startContainer.parentElement;
    if(anchor && anchor.closest('textarea,input,[contenteditable],script,style,template,button,.blog-ai')) { blogAISelectionButton.hidden = true; return; }
    var text = selection.toString().trim();
    if(text.length < 2) { blogAISelectionButton.hidden = true; return; }
    blogAISelection = text.slice(0, 8000); blogAISelectionRange = range.cloneRange();
    var rects = Array.from(range.getClientRects()), rect = rects.find(function(box) { return box.width > 0 && box.bottom > 65 && box.top < innerHeight; }) || range.getBoundingClientRect();
    blogAISelectionButton.style.left = Math.max(10, Math.min(window.innerWidth - 164, rect.left)) + 'px';
    blogAISelectionButton.style.top = Math.max(65, Math.min(window.innerHeight - 55, rect.top - 44)) + 'px';
    blogAISelectionButton.hidden = false;
  }
  document.addEventListener('pointerup', function(event) {
    if(event.target.closest && event.target.closest('[data-blog-ai],.blog-ai-host,dialog')) return;
    setTimeout(capture, 0);
  });
  document.addEventListener('keyup', function(event) { if(event.key === 'Shift' || event.key.startsWith('Arrow')) capture(); });
  window.addEventListener('scroll', function() {
    blogAISelectionButton.hidden = true;
  }, { passive: true });
  function resized() {
    if(blogAIPositionFrame) return;
    blogAIPositionFrame = requestAnimationFrame(function() { blogAIPositionFrame = 0; ['ask', 'chat', 'explain'].forEach(positionBlogAIHost); });
  }
  window.addEventListener('resize', resized, { passive: true });
  if(window.visualViewport) {
    window.visualViewport.addEventListener('resize', resized, { passive: true });
    window.visualViewport.addEventListener('scroll', resized, { passive: true });
  }
  document.addEventListener('click', function(event) {
    var button = event.target.closest && event.target.closest('[data-blog-ai]');
    if(!button) return;
    event.preventDefault();
    if(button.dataset.blogAi === 'explain' && !blogAISelection) capture();
    openBlogAI(button.dataset.blogAi, button); blogAISelectionButton.hidden = true;
  });
  document.addEventListener('keydown', function(event) {
    if(event.key !== 'Escape' || event.defaultPrevented) return;
    var mode = ['explain', 'chat', 'ask'].find(function(key) { return !!blogAIHosts[key]; });
    if(mode) {
      event.preventDefault();
      if(mode === 'explain' && blogAIHosts[mode].host.classList.contains('is-expanded')) expandBlogAIExplanation();
      else closeBlogAIHost(mode, true);
    }
  });
  document.addEventListener('fullscreenchange', function() { ['ask', 'chat', 'explain'].forEach(function(mode) { closeBlogAIHost(mode, false); }); syncBlogAIToggle(); });
  window.addEventListener('pjax:send', destroyBlogAI);
  window.addEventListener('pjax:success', syncBlogAIToggle);
  window.addEventListener('pjax:success', visitBlogAIReference);
  window.addEventListener('hashchange', visitBlogAIReference);
  window.addEventListener('pagehide', destroyBlogAI);
  syncBlogAIToggle();
  visitBlogAIReference();
};
