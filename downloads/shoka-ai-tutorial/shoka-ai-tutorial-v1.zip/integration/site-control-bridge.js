window.BlogSiteControl = Object.freeze({
  root: CONFIG.root || '/',
  waline: CONFIG.waline && CONFIG.waline.serverURL || '',
  navigate: function(path) {
    if(typeof path !== 'string' || !path.startsWith(CONFIG.root || '/') || path.startsWith('//')
      || /[?#%\\\u0000-\u0020]/.test(path) || path.split('/').some(function(part) { return part === '.' || part === '..'; })) return false;
    if(pjax && typeof pjax.loadUrl === 'function') pjax.loadUrl(path);
    else window.location.assign(path);
    return true;
  },
  music: function() {
    var gramophone = document.querySelector('#about-gramophone-source .player');
    var target = NOWPLAYING && NOWPLAYING.player && NOWPLAYING.player.options.type === 'audio' ? NOWPLAYING : gramophone || toolPlayer;
    var api = target && target.player;
    if(!api || typeof api.tracks !== 'function') return null;
    return { prepare: function() { return api.fetch(); }, tracks: function() { return api.tracks(); },
      state: function() { return api.state(); }, play: function() { return api.playConfirmed(); },
      pause: function() { api.pause(); }, stop: function() { api.stop(); },
      next: function() { api.next(); }, previous: function() { api.previous(); },
      volume: function(value) { api.muted(); api.volume(value / 100); },
      mute: function(value) { api.muted(value ? 'muted' : ''); },
      track: function(index) { api.switch(index); }, mode: function(value) { return api.setMode(value); } };
  }
});
